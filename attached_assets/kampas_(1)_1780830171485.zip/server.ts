import express from "express";
import path from "path";
import { createServer as createViteServer } from "vite";
import http from "http";
import { Server } from "socket.io";
import { getDistance } from "geolib";
import { GoogleGenAI, Type } from "@google/genai";

// ── GEMINI INITIALIZATION ───────────────────────────────────────────────────────
const ai = new GoogleGenAI({
  apiKey: process.env.GEMINI_API_KEY,
  httpOptions: { headers: { 'User-Agent': 'aistudio-build' } }
});

// ── MOCK DATA STORE ─────────────────────────────────────────────────────────────
const datastore = {
  users: [
    { id: 'u1', name: 'Super Admin', email: 'admin@kampas.co.ke', role: 'ADMIN', isVerified: true, walletBalance: 1000000, campus: 'HQ', lat: -1.286389, lng: 36.817223, last_location_update: new Date().toISOString() },
    { id: 'u2', name: 'John Doe', email: 'john@gmail.com', role: 'BUYER', isVerified: true, walletBalance: 5000, campus: 'JKUAT Main', phone: '0712345678', lat: -1.0912, lng: 37.0117, last_location_update: new Date().toISOString() },
    { id: 'u3', name: 'Jane Seller', email: 'jane@shop.com', role: 'SELLER', isVerified: true, walletBalance: 12000, campus: 'UoN Main', phone: '0787654321', avatar: 'https://api.dicebear.com/7.x/avataaars/svg?seed=Jane', lat: -1.2805, lng: 36.8158, last_location_update: new Date().toISOString() },
  ],
  products: [
    { id: 'p1', name: 'Air Jordan 4 Retro', price: 4500, originalPrice: 6000, campus: 'UoN Main', condition: 'NEW', stock: 5, views: 120, rating: 4.8, reviewCount: 12, images: ['https://images.unsplash.com/photo-1595950653106-6c9ebd614d3a?w=400&q=80'], sellerId: 'u3', isActive: true, category: { name: 'Sneakers & Drip', slug: 'sneakers-drip' }, lat: -1.2805, lng: 36.8158 },
    { id: 'p2', name: 'MacBook Pro M1 (Used)', price: 95000, originalPrice: 110000, campus: 'Strathmore', condition: 'SLIGHTLY_USED', stock: 1, views: 340, rating: 4.9, reviewCount: 5, images: ['https://images.unsplash.com/photo-1517336714731-489689fd1ca8?w=400&q=80'], sellerId: 'u3', isActive: true, category: { name: 'Tech & Gadgets', slug: 'tech-gadgets' }, lat: -1.3090, lng: 36.8123 },
    { id: 'p3', name: 'PS5 DualSense Controller', price: 6000, originalPrice: null, campus: 'KU Main', condition: 'NEW', stock: 10, views: 80, rating: 4.5, reviewCount: 20, images: ['https://images.unsplash.com/photo-1606813907291-d86efa9b94db?w=400&q=80'], sellerId: 'u3', isActive: true, category: { name: 'Electronics', slug: 'electronics' }, lat: -1.1812, lng: 36.9312 },
    { id: 'p4', name: 'Calculus Early Transcendentals', price: 1200, originalPrice: 1800, campus: 'JKUAT Main', condition: 'USED', stock: 2, views: 50, rating: 4.2, reviewCount: 8, images: ['https://images.unsplash.com/photo-1544947950-fa07a98d237f?w=400&q=80'], sellerId: 'u3', isActive: true, category: { name: 'Textbooks', slug: 'textbooks' }, lat: -1.0912, lng: 37.0117 },
  ],
  properties: [
    { id: 'h1', title: 'Modern Studio Bedsitter', type: 'BEDSITTER', price: 12000, deposit: 12000, rooms: '1', campus: 'JKUAT Main', address: 'Juja, Gate A', lat: -1.0950, lng: 37.0150, images: [{url: 'https://images.unsplash.com/photo-1522708323590-d24dbb6b0267?w=400&q=80'}, {url: 'https://images.unsplash.com/photo-1502672260266-1c1ef2d93688?w=400&q=80'}], verified: true, description: 'Newly built with modern finishes.', email: 'landlord@gmail.com', phone: '0711223344', availabilityStatus: 'AVAILABLE', createdBy: 'u1' },
    { id: 'h2', title: 'Luxury 2-Bedroom Apartment', type: 'APARTMENT', price: 35000, deposit: 35000, rooms: '2', campus: 'UoN Main', address: 'Nairobi, State House Rd', lat: -1.2750, lng: 36.8100, images: [{url: 'https://images.unsplash.com/photo-1502672260266-1c1ef2d93688?w=400&q=80'}], verified: true, description: 'Quiet environment, 5 min walk to campus.', email: 'admin@kampas.co.ke', phone: '0722334455', availabilityStatus: 'AVAILABLE', createdBy: 'u1' },
    { id: 'h3', title: 'Executive Hostels (Male)', type: 'HOSTEL', price: 8500, deposit: 4000, rooms: '60', campus: 'KU Main', address: 'Kahawa Sukari', lat: -1.1750, lng: 36.9200, images: [{url: 'https://images.unsplash.com/photo-1555854877-bab0e564b8d5?w=400&q=80'}], verified: false, description: 'Affordable hostels for 1st year students.', availabilityStatus: 'AVAILABLE', createdBy: 'u3' },
    { id: 'h4', title: 'Cozy Student Residence', type: 'RESIDENCE', price: 15000, deposit: 10000, rooms: '1', campus: 'Strathmore', address: 'Madaraka Estate', lat: -1.3050, lng: 36.8150, images: [{url: 'https://images.unsplash.com/photo-1536376074432-cd22998a4d46?w=400&q=80'}], verified: true, description: 'Gated community with high security.', availabilityStatus: 'AVAILABLE', createdBy: 'u3' },
  ],
  orders: [
    { id: 'o1', buyerId: 'u2', sellerId: 'u3', status: 'DELIVERED', total: 4500, createdAt: new Date(Date.now() - 86400000 * 2).toISOString(), items: [{ productId: 'p1', quantity: 1, price: 4500 }], paymentMethod: 'WALLET' },
    { id: 'o2', buyerId: 'u2', sellerId: 'u3', status: 'PENDING', total: 6000, createdAt: new Date().toISOString(), items: [{ productId: 'p3', quantity: 1, price: 6000 }], paymentMethod: 'WALLET' },
  ],
  carts: {} as Record<string, any[]>,
  wishlists: {} as Record<string, string[]>,
  notifications: {} as Record<string, any[]>,
  events: [
    { id: 'e1', title: 'Campus Music Fest 2026', campus: 'UoN Main', price: 500, startDate: new Date(Date.now() + 86400000 * 10).toISOString(), venue: 'Great Court', organizer: { id: 'u3', name: 'Jane Events' }, _count: { rsvps: 250, tickets: 120 }, lat: -1.2805, lng: 36.8158, description: 'The biggest campus music festival in Nairobi.' },
    { id: 'e2', title: 'Tech Startup Pitch Night', campus: 'JKUAT Main', price: 0, startDate: new Date(Date.now() + 86400000 * 5).toISOString(), venue: 'Assembly Hall', organizer: { id: 'u1', name: 'Admin' }, _count: { rsvps: 80, tickets: 0 }, lat: -1.0912, lng: 37.0117, description: 'Pitch your ideas to top investors.' },
    { id: 'e3', title: 'Fashion Gala 2026', campus: 'Strathmore', price: 1000, startDate: new Date(Date.now() + 86400000 * 15).toISOString(), venue: 'Auditorium', organizer: { id: 'u3', name: 'Jane Events' }, _count: { rsvps: 150, tickets: 45 }, lat: -1.3090, lng: 36.8123, description: 'Student-led fashion show showcasing local talent.' },
    { id: 'e4', title: 'Inter-University Gaming Tourney', campus: 'KU Main', price: 200, startDate: new Date(Date.now() + 86400000 * 3).toISOString(), venue: 'Indoor Arena', organizer: { id: 'u1', name: 'Kampas Admin' }, _count: { rsvps: 300, tickets: 180 }, lat: -1.1812, lng: 36.9312, description: 'EA Sports and Tekken tournament with major prizes.' },
  ],
  services: [
    { id: 's1', name: 'Laptop Repair & Software', category: 'Tech', description: 'Expert laptop repair and optimization.', price: 1500, location: 'JKUAT Gate A', contactNumber: '0711223344', sellerId: 'u3', images: ['https://images.unsplash.com/photo-1591799264318-7e6ef8ddb7ea?w=400&q=80'] },
    { id: 's2', name: 'Campus Salon & Barber', category: 'Grooming', description: 'Affordable campus grooming services.', price: 500, location: 'UoN Hall 9', contactNumber: '0788990011', sellerId: 'u3', images: ['https://images.unsplash.com/photo-1585747860715-2ba37e788b70?w=400&q=80'] },
  ],
  flashSales: [
    { id: 'fs1', productId: 'p1', flashPrice: 3500, bannerImage: 'https://images.unsplash.com/photo-1595950653106-6c9ebd614d3a?w=400&q=80', startTime: new Date().toISOString(), endTime: new Date(Date.now() + 86400000).toISOString(), sellerId: 'u3' },
  ],
  payouts: [] as any[],
  walletTransactions: {} as Record<string, any[]>,
  sellerApplications: [] as any[],
  referrals: [] as { referrerId: string, referredId: string, createdAt: string }[],
};

// Initialize some cart/wishlist/transaction data
datastore.carts['u2'] = [{ id: 'c1', productId: 'p1', quantity: 1 }];
datastore.wishlists['u2'] = ['p2'];
datastore.walletTransactions['u2'] = [{ id: 'tx1', amount: -4500, description: 'Order #O1 payment', type: 'PAYMENT', createdAt: new Date().toISOString() }];
datastore.walletTransactions['u3'] = [{ id: 'tx2', amount: 4500, description: 'Order #O1 revenue', type: 'REVENUE', createdAt: new Date().toISOString() }];

async function startServer() {
  const app = express();
  const PORT = 3000;
  const server = http.createServer(app);
  const io = new Server(server, { cors: { origin: "*", methods: ["GET", "POST"] } });

  let activeUsers = 0;
  io.on("connection", (socket) => {
    activeUsers++;
    io.emit("activeUsers", activeUsers);
    socket.on("sendMessage", (msg) => io.emit("newMessage", { ...msg, id: Date.now(), timestamp: new Date().toISOString() }));
    socket.on("disconnect", () => { activeUsers--; io.emit("activeUsers", activeUsers); });
  });

  app.use(express.json());

  // ── AUTH MIDDLEWARE ──────────────────────────────────────────────────────────
  const authenticate = (req: any, res: any, next: any) => {
    const authHeader = req.headers.authorization;
    if (!authHeader) return res.status(401).json({ message: 'Missing token' });
    const token = authHeader.split(' ')[1];
    const user = datastore.users.find(u => u.id === token); // Simple token = ID
    if (!user) return res.status(401).json({ message: 'Invalid token' });
    req.user = user;
    next();
  };

  // ── AUTH ROUTES ─────────────────────────────────────────────────────────────
  app.post("/api/auth/login", (req, res) => {
    const { email } = req.body;
    const user = datastore.users.find(u => u.email === email);
    if (!user) return res.status(404).json({ message: 'User not found' });
    res.json({ data: { user, token: user.id } });
  });

  app.post("/api/auth/register", (req, res) => {
    const { name, email, role, campus, phone } = req.body;
    if (datastore.users.some(u => u.email === email)) return res.status(400).json({ message: 'User exists' });
    const newUser = { 
      id: 'u' + (datastore.users.length + 1), 
      name, email, role, campus, phone, 
      walletBalance: 0, 
      isVerified: true,
      lat: 0, 
      lng: 0, 
      last_location_update: new Date().toISOString() 
    };
    (datastore.users as any).push(newUser);
    res.json({ data: { user: newUser, token: newUser.id } });
    
    // Handle Referral logic if code provided
    if (req.body.referralCode) {
      const referrer = datastore.users.find(u => u.id === req.body.referralCode);
      if (referrer) {
        datastore.referrals.push({
          referrerId: referrer.id,
          referredId: newUser.id,
          createdAt: new Date().toISOString()
        });
      }
    }
  });

  app.get("/api/auth/me", authenticate, (req: any, res) => res.json({ data: { user: req.user } }));

  app.post("/api/marketplace/process-image", authenticate, async (req: any, res) => {
    const { image } = req.body; // Expecting base64 or URL
    if (!image) return res.status(400).json({ message: "No image provided" });

    try {
      const prompt = `Analyze this product image for a student marketplace. 
      1. Is it appropriate? 
      2. Is the quality good (not blurry or too dark)? 
      3. What is the product? 
      4. Suggest a clear title and the best category (Sneakers, Tech, Electronics, Textbooks, Others).
      
      Return JSON: { "isAppropriate": boolean, "isGoodQuality": boolean, "feedback": string, "suggestedTitle": string, "suggestedCategory": string }`;

      const response = await ai.models.generateContent({
        model: "gemini-3.5-flash",
        contents: [
          { text: prompt },
          { inlineData: { mimeType: "image/jpeg", data: image.split(',')[1] || image } }
        ],
        config: { responseMimeType: "application/json" }
      });

      const analysis = JSON.parse(response.text || '{}');

      // Simulate background removal and enhancement
      // In a real app, we would call a service like Remove.bg here
      // For this platform, we provide the "processed" payload
      const processedImage = image; // Placeholder for actual processed bytes
      
      res.json({ 
        data: { 
          analysis, 
          processedUrl: processedImage, 
          originalUrl: image,
          enhancements: { brightness: 1.1, contrast: 1.2, sharp: true }
        } 
      });
    } catch (error) {
      console.error("Image Analysis Error:", error);
      res.status(500).json({ message: "Failed to process image" });
    }
  });

  app.post("/api/marketplace/refine-image", authenticate, async (req: any, res) => {
    const { image, mask } = req.body;
    if (!image || !mask) return res.status(400).json({ message: "Missing image or mask" });

    try {
      // We use Gemini to "confirm" refinement strategy
      const prompt = `The user has provided an image of a product and a mask where they want parts removed or refined. 
      Analyze the mask and describe how the product should look after refinement. 
      Focus on extracting the main subject and cleaning the background.
      Return a confirmation message.`;

      await ai.models.generateContent({
        model: "gemini-3.5-flash",
        contents: [
          { text: prompt },
          { inlineData: { mimeType: "image/jpeg", data: image.split(',')[1] || image } }
        ]
      });

      // Simulation of a refined image: 
      // In a production app, we would use an inpainting model or background removal API.
      // Here we return the original image but with a "processed" flag for the UI.
      // We'll also "brighten" it slightly to show a difference.
      res.json({ 
        data: { 
          processedUrl: image, // In a real case, we'd send the output of the inpainting model
          message: "Image refined successfully by Kampas AI."
        } 
      });
    } catch (error) {
      console.error("Image Refinement Error:", error);
      res.status(500).json({ message: "AI refinement failed" });
    }
  });

  app.post("/api/auth/location", authenticate, (req: any, res) => {
    const { lat, lng, accuracy } = req.body;
    req.user.lat = lat;
    req.user.lng = lng;
    req.user.location_accuracy = accuracy;
    req.user.last_location_update = new Date().toISOString();
    req.user.location_verified = true;
    res.json({ message: 'Location updated', data: { user: req.user } });
  });

  // ── BUYER ROUTES ─────────────────────────────────────────────────────────────
  app.get("/api/buyer/wallet", authenticate, (req: any, res) => {
    res.json({ data: { balance: req.user.walletBalance, transactions: datastore.walletTransactions[req.user.id] || [] } });
  });

  app.post("/api/buyer/wallet/topup", authenticate, (req: any, res) => {
    const { amount } = req.body;
    req.user.walletBalance += amount;
    const tx = { id: 'tx' + Date.now(), amount, description: 'Wallet Topup via M-Pesa', type: 'TOPUP', createdAt: new Date().toISOString() };
    if (!datastore.walletTransactions[req.user.id]) datastore.walletTransactions[req.user.id] = [];
    datastore.walletTransactions[req.user.id].push(tx);
    res.json({ message: `Topup of KSH ${amount} successful!` });
  });

  app.get("/api/buyer/orders", authenticate, (req: any, res) => {
    const orders = datastore.orders.filter(o => o.buyerId === req.user.id).map(o => {
      const seller = datastore.users.find(u => u.id === o.sellerId);
      return {
        ...o,
        seller: seller ? { id: seller.id, name: seller.name, email: seller.email, campus: seller.campus } : null,
        items: o.items.map((item: any) => ({ 
          ...item, 
          product: item.isService 
            ? datastore.services.find(s => s.id === item.productId)
            : datastore.products.find(p => p.id === item.productId) 
        }))
      };
    });
    res.json({ data: { orders } });
  });

  app.get("/api/buyer/cart", authenticate, (req: any, res) => {
    const items = (datastore.carts[req.user.id] || []).map(i => ({ ...i, product: datastore.products.find(p => p.id === i.productId) }));
    const subtotal = items.reduce((acc, i) => acc + (i.product?.price || 0) * i.quantity, 0);
    res.json({ data: { id: 'cart_' + req.user.id, items, subtotal, deliveryFee: 100, total: subtotal + 100 } });
  });

  app.post("/api/buyer/cart/:pid", authenticate, (req: any, res) => {
    const { pid } = req.params;
    if (!datastore.carts[req.user.id]) datastore.carts[req.user.id] = [];
    const existing = datastore.carts[req.user.id].find(i => i.productId === pid);
    if (existing) existing.quantity += (req.body.quantity || 1);
    else datastore.carts[req.user.id].push({ id: 'c' + Date.now(), productId: pid, quantity: req.body.quantity || 1 });
    res.json({ message: 'Added to cart' });
  });

  app.put("/api/buyer/cart/:pid", authenticate, (req: any, res) => {
    const { pid } = req.params;
    const item = (datastore.carts[req.user.id] || []).find(i => i.productId === pid);
    if (item) item.quantity = req.body.quantity;
    res.json({ message: 'Cart updated' });
  });

  app.delete("/api/buyer/cart/:pid", authenticate, (req: any, res) => {
    const { pid } = req.params;
    datastore.carts[req.user.id] = (datastore.carts[req.user.id] || []).filter(i => i.productId !== pid);
    res.json({ message: 'Removed from cart' });
  });

  app.get("/api/buyer/wishlist", authenticate, (req: any, res) => {
    const items = (datastore.wishlists[req.user.id] || []).map(pid => ({ id: 'w' + pid, productId: pid, product: datastore.products.find(p => p.id === pid) }));
    res.json({ data: { items } });
  });

  app.post("/api/buyer/wishlist/:pid", authenticate, (req: any, res) => {
    if (!datastore.wishlists[req.user.id]) datastore.wishlists[req.user.id] = [];
    if (!datastore.wishlists[req.user.id].includes(req.params.pid)) datastore.wishlists[req.user.id].push(req.params.pid);
    res.json({ message: 'Added to wishlist' });
  });

  app.delete("/api/buyer/wishlist/:pid", authenticate, (req: any, res) => {
    datastore.wishlists[req.user.id] = (datastore.wishlists[req.user.id] || []).filter(id => id !== req.params.pid);
    res.json({ message: 'Removed from wishlist' });
  });

  app.post("/api/buyer/orders", authenticate, (req: any, res) => {
    const { items, paymentMethod, shippingAddress } = req.body;
    if (!items || items.length === 0) return res.status(400).json({ message: 'No items in order' });

    // Calculate total
    let subtotal = 0;
    const orderItems = items.map((i: any) => {
      let itemData: any = datastore.products.find(p => p.id === i.productId);
      if (!itemData && i.isService) {
        itemData = datastore.services.find(s => s.id === i.productId);
      }
      
      if (!itemData) throw new Error(`Product/Service ${i.productId} not found`);
      subtotal += itemData.price * i.quantity;
      return { productId: i.productId, quantity: i.quantity, price: itemData.price, sellerId: itemData.sellerId, isService: !!i.isService };
    });

    const deliveryFee = req.body.isService ? 0 : 100;
    const total = subtotal + deliveryFee;

    // Payment Logic
    if (paymentMethod === 'WALLET') {
      if (req.user.walletBalance < total) return res.status(400).json({ message: 'Insufficient wallet balance' });
      req.user.walletBalance -= total;
      const tx = { id: 'tx' + Date.now(), amount: -total, description: `Payment for ${req.body.isService ? 'Service' : 'Order'}`, type: 'PAYMENT', createdAt: new Date().toISOString() };
      if (!datastore.walletTransactions[req.user.id]) datastore.walletTransactions[req.user.id] = [];
      datastore.walletTransactions[req.user.id].push(tx);
    } else if (paymentMethod === 'MPESA') {
      // Simulate M-Pesa STK Push
      const tx = { id: 'tx' + Date.now(), amount: total, description: `Payment for ${req.body.isService ? 'Service' : 'Order'} via M-Pesa`, type: 'PAYMENT_MPESA', createdAt: new Date().toISOString(), status: 'COMPLETED' };
      if (!datastore.walletTransactions[req.user.id]) datastore.walletTransactions[req.user.id] = [];
      datastore.walletTransactions[req.user.id].push(tx);
    }

    const orderId = (req.body.isService ? 'BK' : 'O') + Math.random().toString(36).substr(2, 6).toUpperCase();
    const newOrder = {
      id: orderId,
      buyerId: req.user.id,
      sellerId: orderItems[0].sellerId,
      status: paymentMethod === 'COD' ? 'ORDER_REQUESTED' : (req.body.isService ? 'CONFIRMED' : 'PENDING'),
      total,
      subtotal,
      deliveryFee,
      paymentMethod,
      shippingAddress: req.body.shippingAddress || 'Campus Pick-up',
      appointmentDate: req.body.appointmentDate,
      createdAt: new Date().toISOString(),
      items: orderItems,
      receiptId: 'REC-' + Date.now(),
      isService: !!req.body.isService
    };

    datastore.orders.push(newOrder);

    // Clear cart
    datastore.carts[req.user.id] = [];

    // Notify seller
    const notification = {
      id: 'n' + Date.now(),
      type: 'NEW_ORDER',
      message: `You have a new order ${orderId} (${paymentMethod === 'COD' ? 'Pay on Delivery' : 'Paid'}).`,
      createdAt: new Date().toISOString(),
      read: false
    };
    if (!datastore.notifications[newOrder.sellerId]) datastore.notifications[newOrder.sellerId] = [];
    datastore.notifications[newOrder.sellerId].push(notification);

    res.json({ message: 'Order placed successfully', data: { order: newOrder } });
  });

  app.delete("/api/buyer/cart", authenticate, (req: any, res) => {
    datastore.carts[req.user.id] = [];
    res.json({ message: 'Cart cleared' });
  });

  app.get("/api/buyer/notifications", authenticate, (req: any, res) => {
    const list = datastore.notifications[req.user.id] || [];
    const unread = list.filter(n => !n.read).length;
    res.json({ data: { unread, notifications: list } });
  });

  // ── REFERRAL ROUTES ────────────────────────────────────────────────────────
  app.get("/api/seller/referrals", authenticate, (req: any, res) => {
    const list = datastore.referrals.filter(r => r.referrerId === req.user.id).map(r => {
      const referred = datastore.users.find(u => u.id === r.referredId);
      return { ...r, referredName: referred?.name, referredCampus: referred?.campus };
    });
    
    // Calculate current fee reduction (1% per referral, max 5%)
    const reduction = Math.min(list.length, 5);
    const baseFee = 10;
    const currentFee = baseFee - reduction;
    
    res.json({ data: { referrals: list, currentFee, reduction, referralCode: req.user.id } });
  });

  // ── IMAGE PROCESSING ENHANCED ──────────────────────────────────────────────
  app.post("/api/marketplace/remove-bg", authenticate, async (req: any, res) => {
    const { image } = req.body;
    if (!image) return res.status(400).json({ message: "No image provided" });

    // In a real app, we'd use ClipDrop or Remove.bg API
    // ClipDrop: POST https://clipdrop-api.co/remove-background/v1
    // Remove.bg: POST https://api.remove.bg/v1.0/removebg

    console.log("Simulating background removal using ClipDrop/Remove.bg...");
    
    // Simulate thinking delay
    await new Promise(r => setTimeout(r, 1500));

    res.json({ 
      data: { 
        processedUrl: image, // Placeholder
        method: "CLIPDROP_AI",
        message: "Background removed successfully."
      } 
    });
  });

  // ── PAYSTACK INTEGRATION ───────────────────────────────────────────────────
  app.post("/api/payments/paystack/initialize", authenticate, (req: any, res) => {
    const { amount, email } = req.body;
    // In real app, call Paystack API: https://api.paystack.co/transaction/initialize
    const reference = 'PAY-' + Date.now();
    res.json({ 
      data: { 
        authorization_url: `https://checkout.paystack.com/${reference}`,
        reference 
      } 
    });
  });

  app.post("/api/payments/paystack/verify", authenticate, (req: any, res) => {
    const { reference } = req.body;
    // In real app, call Paystack API: https://api.paystack.co/transaction/verify/:reference
    res.json({ status: "success", message: "Transaction verified" });
  });

  // ── SELLER ROUTES ────────────────────────────────────────────────────────────
  app.put("/api/auth/update", authenticate, (req: any, res) => {
    Object.assign(req.user, req.body);
    res.json({ message: 'Profile updated', data: { user: req.user } });
  });

  app.post("/api/auth/become-seller", authenticate, (req: any, res) => {
    const { businessName, businessDescription, category, campus } = req.body;
    
    if (!businessName || !businessDescription || !category || !campus) {
      return res.status(400).json({ message: 'Missing required fields' });
    }

    const application = {
      id: `app_${Date.now()}`,
      userId: req.user.id,
      userName: req.user.name,
      userEmail: req.user.email,
      businessName,
      businessDescription,
      category,
      campus,
      status: 'PENDING',
      createdAt: new Date().toISOString()
    };

    datastore.sellerApplications.push(application);
    req.user.sellerRequestPending = true;
    
    res.json({ message: 'Seller application submitted successfully' });
  });

  app.get("/api/seller/analytics", authenticate, (req: any, res) => {
    const sellerOrders = datastore.orders.filter(o => o.sellerId === req.user.id);
    const revenue = sellerOrders.reduce((acc, o) => acc + (o.status === 'DELIVERED' ? o.total : 0), 0);
    res.json({ data: {
      revenue: { total: revenue, month: revenue },
      products: { active: datastore.products.filter(p => p.sellerId === req.user.id && p.isActive).length, total: datastore.products.filter(p => p.sellerId === req.user.id).length },
      orders: { total: sellerOrders.length, pending: sellerOrders.filter(o => ['PENDING', 'ORDER_REQUESTED'].includes(o.status)).length, delivered: sellerOrders.filter(o => o.status === 'DELIVERED').length },
      customers: new Set(sellerOrders.map(o => o.buyerId)).size,
      recentOrders: [...sellerOrders].sort((a,b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime()).slice(0, 10),
    }});
  });

  app.get("/api/seller/analytics/sales", authenticate, (req: any, res) => {
    const days = parseInt(req.query.days as string) || 7;
    const salesData = Array.from({ length: days }).map((_, i) => {
      const d = new Date();
      d.setDate(d.getDate() - (days - 1 - i));
      const dateStr = d.toISOString().split('T')[0];
      return { date: dateStr, revenue: Math.floor(Math.random() * 5000) };
    });
    res.json({ data: { salesData } });
  });

  app.get("/api/seller/orders", authenticate, (req: any, res) => {
    const orders = datastore.orders.filter(o => o.sellerId === req.user.id).map(o => ({
      ...o,
      buyer: datastore.users.find(u => u.id === o.buyerId),
      items: o.items.map((i: any) => ({ 
        ...i, 
        product: i.isService 
          ? datastore.services.find(s => s.id === i.productId)
          : datastore.products.find(p => p.id === i.productId) 
      }))
    }));
    res.json({ data: { orders } });
  });

  app.put("/api/seller/orders/:id/status", authenticate, (req: any, res) => {
    const order = datastore.orders.find(o => o.id === req.params.id && o.sellerId === req.user.id);
    if (!order) return res.status(404).json({ message: 'Order not found' });
    order.status = req.body.status;
    
    // Notify buyer
    const notification = {
      id: 'n' + Date.now(),
      type: 'ORDER_UPDATE',
      message: `Your order ${order.id} is now ${order.status.replace(/_/g, ' ')}.`,
      createdAt: new Date().toISOString(),
      read: false
    };
    if (!datastore.notifications[order.buyerId]) datastore.notifications[order.buyerId] = [];
    datastore.notifications[order.buyerId].push(notification);

    res.json({ message: 'Order status updated' });
  });

  app.put("/api/seller/orders/:id/cancel", authenticate, (req: any, res) => {
    const order = datastore.orders.find(o => o.id === req.params.id && o.sellerId === req.user.id);
    if (!order) return res.status(404).json({ message: 'Order not found' });
    order.status = 'CANCELLED';
    (order as any).cancelReason = req.body.reason;
    
    // Refund if paid via wallet/mpesa
    if (order.paymentMethod !== 'COD') {
      const buyer = datastore.users.find(u => u.id === order.buyerId);
      if (buyer) {
        buyer.walletBalance += order.total;
        const tx = { id: 'tx' + Date.now(), amount: order.total, description: `Refund for order ${order.id}`, type: 'REFUND', createdAt: new Date().toISOString() };
        if (!datastore.walletTransactions[buyer.id]) datastore.walletTransactions[buyer.id] = [];
        datastore.walletTransactions[buyer.id].push(tx);
      }
    }

    res.json({ message: 'Order cancelled and buyer notified' });
  });

  app.get("/api/seller/wallet", authenticate, (req: any, res) => {
    const transactions = (datastore.walletTransactions[req.user.id] || []);
    const payouts = datastore.payouts.filter(p => p.sellerId === req.user.id);
    res.json({ data: { 
      balance: req.user.walletBalance, 
      transactions,
      payouts
    }});
  });

  app.post("/api/seller/wallet/withdraw", authenticate, (req: any, res) => {
    const { amount, phone } = req.body;
    if (amount < 100) return res.status(400).json({ message: 'Minimum withdrawal is KSH 100' });
    if (req.user.walletBalance < amount) return res.status(400).json({ message: 'Insufficient balance' });
    
    req.user.walletBalance -= amount;
    const payout = { 
      id: 'PO' + Date.now().toString(36).toUpperCase(), 
      sellerId: req.user.id, 
      amount, 
      phone, 
      status: 'PENDING', 
      createdAt: new Date().toISOString() 
    };
    datastore.payouts.push(payout);
    
    const tx = { id: 'tx' + Date.now(), amount: -amount, description: 'Payout request', type: 'WITHDRAWAL', createdAt: new Date().toISOString() };
    if (!datastore.walletTransactions[req.user.id]) datastore.walletTransactions[req.user.id] = [];
    datastore.walletTransactions[req.user.id].push(tx);

    res.json({ message: 'Payout request submitted successfully' });
  });

  app.get("/api/seller/services", authenticate, (req: any, res) => {
    res.json({ data: { services: datastore.services.filter(s => s.sellerId === req.user.id) } });
  });

  app.post("/api/seller/services", authenticate, (req: any, res) => {
    const service = { ...req.body, id: 's' + Date.now(), sellerId: req.user.id, price: parseFloat(req.body.price) };
    datastore.services.push(service);
    res.json({ data: { service } });
  });

  app.put("/api/seller/services/:id", authenticate, (req: any, res) => {
    const idx = datastore.services.findIndex(s => s.id === req.params.id && s.sellerId === req.user.id);
    if (idx === -1) return res.status(404).json({ message: 'Service not found' });
    datastore.services[idx] = { ...datastore.services[idx], ...req.body, price: parseFloat(req.body.price) };
    res.json({ data: { service: datastore.services[idx] } });
  });

  app.get("/api/seller/flash-sales", authenticate, (req: any, res) => {
    res.json({ data: { sales: datastore.flashSales.filter(fs => fs.sellerId === req.user.id).map(fs => {
      const p = datastore.products.find(prod => prod.id === fs.productId);
      return { ...fs, product: p };
    }) } });
  });

  app.post("/api/seller/flash-sales", authenticate, (req: any, res) => {
    const sale = { ...req.body, id: 'fs' + Date.now(), sellerId: req.user.id, flashPrice: parseFloat(req.body.flashPrice) };
    datastore.flashSales.push(sale);
    res.json({ data: { sale } });
  });

  app.get("/api/seller/products", authenticate, (req: any, res) => {
    res.json({ data: { products: datastore.products.filter(p => p.sellerId === req.user.id) } });
  });

  app.post("/api/seller/products", authenticate, (req: any, res) => {
    const p = { 
      ...req.body, 
      id: 'p' + Date.now(), 
      sellerId: req.user.id, 
      views: 0, 
      rating: null, 
      reviewCount: 0,
      originalPrice: req.body.originalPrice ? parseFloat(req.body.originalPrice) : null,
      price: parseFloat(req.body.price)
    };
    datastore.products.push(p);
    res.json({ data: { product: p } });
  });

  app.put("/api/seller/products/:id", authenticate, (req: any, res) => {
    const { id } = req.params;
    const index = datastore.products.findIndex(p => p.id === id && p.sellerId === req.user.id);
    if (index === -1) return res.status(404).json({ message: 'Product not found' });
    
    datastore.products[index] = { 
      ...datastore.products[index], 
      ...req.body,
      price: req.body.price ? parseFloat(req.body.price) : datastore.products[index].price,
      originalPrice: req.body.originalPrice !== undefined ? (req.body.originalPrice ? parseFloat(req.body.originalPrice) : null) : datastore.products[index].originalPrice
    };
    res.json({ data: { product: datastore.products[index] } });
  });

  // ── MARKETPLACE ROUTES ────────────────────────────────────────────────────────
  app.post("/api/seller/verify", authenticate, (req: any, res) => {
    req.user.verificationRequested = true;
    res.json({ message: 'Verification request sent' });
  });

  app.get("/api/seller/store", authenticate, (req: any, res) => {
    res.json({ data: { store: { 
      businessName: req.user.businessName || req.user.name,
      businessDescription: req.user.businessDescription || '',
      businessLogo: req.user.businessLogo || req.user.avatar,
      campus: req.user.campus
    } } });
  });

  app.get("/api/seller/ads", authenticate, (req: any, res) => {
    res.json({ data: { ads: [] } });
  });

  app.get("/api/seller/ads/analytics", authenticate, (req: any, res) => {
    res.json({ data: { totalClicks: 0, totalImpressions: 0 } });
  });

  app.get("/api/products/flash-sales", (req, res) => {
    const activeSales = datastore.flashSales.map((fs: any) => {
      const product = datastore.products.find(p => p.id === fs.productId);
      return { ...product, ...fs, isFlashSale: true };
    });
    res.json({ data: { sales: activeSales } });
  });

  app.get("/api/explore/trending", (req, res) => {
    res.json({ 
      data: { 
        products: datastore.products.slice(0, 8), 
        sellers: datastore.users.filter(u => u.role === 'SELLER').slice(0, 4),
        services: datastore.services.slice(0, 4),
        stores: datastore.users.filter(u => u.role === 'SELLER').slice(0, 4)
      } 
    });
  });

  app.get("/api/products", (req: any, res) => {
    let products: any[] = datastore.products.filter(p => p.isActive);
    let services: any[] = datastore.services;
    
    // If specific category requested
    if (req.query.category) {
      if (req.query.category === 'services') {
        products = []; // Only show services
      } else {
        products = products.filter(p => (typeof p.category === 'object' ? p.category.slug : p.category) === req.query.category);
        services = services.filter(s => s.category.toLowerCase() === (req.query.category as string).toLowerCase());
      }
    }

    if (req.query.q) {
      const q = (req.query.q as string).toLowerCase();
      products = products.filter(p => p.name.toLowerCase().includes(q) || p.campus.toLowerCase().includes(q));
      services = services.filter(s => s.name.toLowerCase().includes(q) || s.location?.toLowerCase().includes(q));
    }
    
    // Combine if it's a general search or specific to services
    let combined = [...products];
    if (req.query.category === 'services' || req.query.type === 'services' || (!req.query.category && !req.query.q)) {
      combined = [...products, ...services];
    } else if (req.query.q) {
      combined = [...products, ...services];
    }

    // Populate Sellers
    combined = combined.map(item => {
      const seller = datastore.users.find(u => u.id === item.sellerId);
      return { ...item, seller };
    });

    // Geospatial sort if user location provided
    if (req.query.lat && req.query.lng) {
      const userLat = parseFloat(req.query.lat);
      const userLng = parseFloat(req.query.lng);
      combined = combined.map(item => ({
        ...item,
        distance: getDistance({ latitude: userLat, longitude: userLng }, { latitude: item.lat || 0, longitude: item.lng || 0 })
      })).sort((a, b) => (a.distance || 0) - (b.distance || 0));
    }

    res.json({ data: { products: combined.filter(p => p.isActive !== false), total: combined.length, pages: 1 } });
  });

  app.get("/api/properties", (req: any, res) => {
    let filtered = datastore.properties;
    if (req.query.type) filtered = filtered.filter(h => h.type === req.query.type);
    if (req.query.campus) filtered = filtered.filter(h => h.campus === req.query.campus);
    
    if (req.query.lat && req.query.lng) {
      const userLat = parseFloat(req.query.lat);
      const userLng = parseFloat(req.query.lng);
      filtered = filtered.map(h => ({
        ...h,
        distance: getDistance({ latitude: userLat, longitude: userLng }, { latitude: h.lat || 0, longitude: h.lng || 0 })
      })).sort((a, b) => (a.distance || 0) - (b.distance || 0));
    }
    res.json({ data: { properties: filtered } });
  });

  app.get("/api/properties/:id", (req, res) => {
    const property = datastore.properties.find(h => h.id === req.params.id);
    if (!property) return res.status(404).json({ message: "Property not found" });
    const creator = datastore.users.find(u => u.id === property.createdBy);
    res.json({ data: { property, creator } });
  });

  app.post("/api/properties", authenticate, (req: any, res) => {
    const { title, type, price, deposit, description, campus, address, lat, lng, images, amenities, availabilityStatus, rooms, email, phone } = req.body;
    
    // Geo-validation logic
    const verified = !!(lat && lng); 

    const newProperty = {
      id: 'h' + Date.now(),
      title, type, price: parseFloat(price), deposit: parseFloat(deposit || 0), description, campus, address, 
      lat, lng, images, amenities, rooms, email, phone,
      availabilityStatus: availabilityStatus || 'AVAILABLE',
      verified,
      createdBy: req.user.id,
      createdAt: new Date().toISOString()
    };

    datastore.properties.push(newProperty);
    res.json({ data: { property: newProperty }, message: verified ? 'Property listed successfully!' : 'Property listed and pending location verification.' });
  });

  app.put("/api/admin/properties/:id/moderate", authenticate, (req: any, res) => {
    if (req.user.role !== 'ADMIN') return res.status(403).json({ message: 'Admin only' });
    const { status, verified } = req.body;
    const index = datastore.properties.findIndex(p => p.id === req.params.id);
    if (index === -1) return res.status(404).json({ message: 'Property not found' });
    
    datastore.properties[index] = { 
      ...datastore.properties[index], 
      availabilityStatus: status || datastore.properties[index].availabilityStatus,
      verified: verified !== undefined ? verified : datastore.properties[index].verified
    };
    res.json({ data: { property: datastore.properties[index] } });
  });

  app.get("/api/events", (req: any, res) => {
    let filtered = [...datastore.events];
    
    if (req.query.campus && req.query.campus !== 'All Campuses') {
      const campusQuery = (req.query.campus as string).toLowerCase();
      filtered = filtered.filter(e => 
        e.campus.toLowerCase() === campusQuery || 
        e.campus.toLowerCase().includes(campusQuery) || 
        campusQuery.includes(e.campus.toLowerCase())
      );
    }

    if (req.query.q) {
      const q = (req.query.q as string).toLowerCase();
      filtered = filtered.filter(e => 
        e.title.toLowerCase().includes(q) || 
        (e.description && e.description.toLowerCase().includes(q))
      );
    }

    if (req.query.lat && req.query.lng) {
      const userLat = parseFloat(req.query.lat);
      const userLng = parseFloat(req.query.lng);
      filtered = filtered.map(e => ({
        ...e,
        distance: getDistance({ latitude: userLat, longitude: userLng }, { latitude: e.lat || 0, longitude: e.lng || 0 })
      })).sort((a, b) => (a.distance || 0) - (b.distance || 0));
    } else {
      // Default sort by date
      filtered.sort((a, b) => new Date(a.startDate).getTime() - new Date(b.startDate).getTime());
    }

    res.json({ data: { events: filtered } });
  });

  app.post("/api/events", authenticate, (req: any, res) => {
    if (req.user.role !== 'ADMIN' && req.user.role !== 'SELLER') {
      return res.status(403).json({ message: 'Only admins and sellers can create events' });
    }

    const { title, description, campus, venue, startDate, endDate, price, capacity, image, lat, lng } = req.body;
    
    const newEvent = {
      id: 'e' + Date.now(),
      title,
      description,
      campus,
      venue,
      startDate,
      endDate,
      price: parseFloat(price || 0),
      capacity: capacity ? parseInt(capacity) : null,
      image,
      organizer: { id: req.user.id, name: req.user.name, avatar: req.user.avatar || null },
      _count: { rsvps: 0, tickets: 0 },
      lat: lat || 0,
      lng: lng || 0,
      createdAt: new Date().toISOString()
    };

    datastore.events.push(newEvent);
    res.json({ data: { event: newEvent }, message: 'Event created successfully!' });
  });

  app.post("/api/events/:id/rsvp", authenticate, (req: any, res) => {
    const event = datastore.events.find(e => e.id === req.params.id);
    if (!event) return res.status(404).json({ message: 'Event not found' });
    
    // In a real app we'd track RSVPs in a join table
    event._count.rsvps += 1;
    res.json({ message: 'RSVP confirmed' });
  });

  app.post("/api/events/:id/ticket", authenticate, (req: any, res) => {
    const event = datastore.events.find(e => e.id === req.params.id);
    if (!event) return res.status(404).json({ message: 'Event not found' });
    const { paymentMethod = 'WALLET' } = req.body;

    if (event.price > 0) {
      if (paymentMethod === 'WALLET') {
        if (req.user.walletBalance < event.price) {
          return res.status(400).json({ message: 'Insufficient wallet balance' });
        }
        req.user.walletBalance -= event.price;
        
        const tx = {
          id: 'tx' + Date.now(),
          amount: -event.price,
          description: `Ticket for ${event.title}`,
          type: 'PAYMENT',
          createdAt: new Date().toISOString()
        };
        if (!datastore.walletTransactions[req.user.id]) datastore.walletTransactions[req.user.id] = [];
        datastore.walletTransactions[req.user.id].push(tx);
      } else if (paymentMethod === 'MPESA' || paymentMethod === 'CARD') {
        // Simulate external payment success
        const tx = {
          id: 'tx' + Date.now(),
          amount: -event.price,
          description: `Ticket for ${event.title} via ${paymentMethod}`,
          type: 'PAYMENT_EXTERNAL',
          createdAt: new Date().toISOString(),
          paymentMethod
        };
        if (!datastore.walletTransactions[req.user.id]) datastore.walletTransactions[req.user.id] = [];
        datastore.walletTransactions[req.user.id].push(tx);
      } else {
        return res.status(400).json({ message: 'Invalid payment method' });
      }
    }

    event._count.tickets += 1;
    
    const ticketId = 'TK-' + Math.random().toString(36).substr(2, 9).toUpperCase();
    res.json({ 
      data: { 
        ticket: { 
          id: ticketId,
          eventId: event.id,
          eventTitle: event.title,
          startDate: event.startDate,
          venue: event.venue,
          campus: event.campus,
          price: event.price,
          qrCode: ticketId,
          buyerName: req.user.name
        } 
      },
      message: 'Ticket purchased successfully'
    });
  });

  // ── ADMIN ROUTES ─────────────────────────────────────────────────────────────
  app.get("/api/admin/seller-applications", authenticate, (req: any, res) => {
    if (req.user.role !== 'ADMIN') return res.status(403).json({ message: 'Forbidden' });
    res.json({ data: { applications: datastore.sellerApplications } });
  });

  app.post("/api/admin/approve-seller", authenticate, (req: any, res) => {
    if (req.user.role !== 'ADMIN') return res.status(403).json({ message: 'Forbidden' });
    const { applicationId, action } = req.body;
    
    const appIndex = datastore.sellerApplications.findIndex(a => a.id === applicationId);
    if (appIndex === -1) return res.status(404).json({ message: 'Application not found' });
    
    const application = datastore.sellerApplications[appIndex];
    if (action === 'APPROVE') {
      application.status = 'APPROVED';
      const user = datastore.users.find(u => u.id === application.userId) as any;
      if (user) {
        user.role = 'SELLER';
        user.sellerRequestPending = false;
        user.businessName = application.businessName;
        user.businessDescription = application.businessDescription;
        user.isVerified = true; 
      }
    } else {
      application.status = 'REJECTED';
      const user = datastore.users.find(u => u.id === application.userId) as any;
      if (user) user.sellerRequestPending = false;
    }
    
    res.json({ message: `Application ${action === 'APPROVE' ? 'approved' : 'rejected'}` });
  });

  app.post("/api/ai/recommendations", authenticate, async (req: any, res) => {
    const { lat, lng } = req.body;
    const user = req.user;
    
    try {
      const prompt = `Based on the user's location (${lat}, ${lng}), university (${user.campus}), and the following available items, recommend the top 3 best opportunities for them.
      
      PRODUCTS: ${JSON.stringify(datastore.products.slice(0, 10))}
      PROPERTIES: ${JSON.stringify(datastore.properties)}
      EVENTS: ${JSON.stringify(datastore.events)}
      
      Return a JSON object with:
      - reason: string (brief explanation)
      - recommendations: array of { type: 'PRODUCT' | 'PROPERTY' | 'EVENT', id: string, title: string, distanceLabel: string }
      `;

      const response = await ai.models.generateContent({
        model: "gemini-3.5-flash",
        contents: prompt,
        config: {
          responseMimeType: "application/json",
          responseSchema: {
            type: Type.OBJECT,
            properties: {
              reason: { type: Type.STRING },
              recommendations: {
                type: Type.ARRAY,
                items: {
                  type: Type.OBJECT,
                  properties: {
                    type: { type: Type.STRING },
                    id: { type: Type.STRING },
                    title: { type: Type.STRING },
                    distanceLabel: { type: Type.STRING }
                  }
                }
              }
            }
          }
        }
      });

      const text = response.text;
      res.json({ data: JSON.parse(text || '{}') });
    } catch (error) {
      console.error("AI Rec Error:", error);
      res.status(500).json({ message: "Failed to generate recommendations" });
    }
  });

  // ── FALLBACK ────────────────────────────────────────────────────────────────
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({ server: { middlewareMode: true }, appType: "spa" });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (req, res) => res.sendFile(path.join(distPath, 'index.html')));
  }

  server.listen(PORT, "0.0.0.0", () => console.log(`Server running on port ${PORT}`));
}

startServer();

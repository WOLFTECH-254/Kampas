export type UserRole = 'BUYER' | 'SELLER' | 'ADMIN';

export interface User {
  id: string;
  name: string;
  email: string;
  phone?: string;
  campus?: string;
  role: UserRole;
  avatar?: string;
  walletBalance: number;
  isVerified: boolean;
  verificationRequested?: boolean;
  verificationDate?: string; // To handle the 2-month free rule
  
  // Business Info (for Sellers)
  businessName?: string;
  businessDescription?: string;
  businessLogo?: string;
  businessContact?: string;
  businessEmail?: string;
  location?: string;
  
  // Fees and metrics
  successSalesCount?: number;
  platformFeeRate?: number; // KES 10, 8, 5 etc
}

export interface Product {
  id: string;
  sellerId: string;
  name: string;
  description: string;
  price: number;
  category: string;
  images: string[];
  stock: number;
  createdAt: string;
  // Flash sale specific
  isFlashSale?: boolean;
  flashSalePrice?: number;
  flashSaleStart?: string;
  flashSaleEnd?: string;
}

export interface Service {
  id: string;
  sellerId: string;
  name: string;
  category: string;
  description: string;
  price: number;
  location: string;
  contactNumber: string;
  email: string;
  availabilitySchedule: string; // e.g. "Mon-Fri: 9am-6pm"
  images: string[];
  createdAt: string;
}

export interface Booking {
  id: string;
  serviceId: string;
  buyerId: string;
  sellerId: string;
  date: string;
  time: string;
  status: 'PENDING' | 'ACCEPTED' | 'REJECTED' | 'COMPLETED';
  createdAt: string;
}

export interface FlashSale {
  id: string;
  productId: string;
  sellerId: string;
  flashPrice: number;
  startTime: string;
  endTime: string;
  bannerImage: string;
  isActive: boolean;
}

export interface PayoutRequest {
  id: string;
  sellerId: string;
  amount: number;
  phone: string;
  status: 'PENDING' | 'APPROVED' | 'REJECTED';
  createdAt: string;
  processedAt?: string;
}

export interface ChatMessage {
  id: string;
  senderId: string;
  receiverId: string;
  text: string;
  productId?: string;
  serviceId?: string;
  createdAt: string;
  isRead: boolean;
}

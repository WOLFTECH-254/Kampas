import React, { createContext, useContext, useState, useEffect } from 'react';
import { POST } from '../lib/api';

interface Location {
  lat: number;
  lng: number;
  accuracy: number;
  timestamp: string;
}

interface LocationContextType {
  location: Location | null;
  permissionStatus: PermissionState | 'unknown';
  requestLocation: () => Promise<void>;
  updateLocationOnServer: (loc: Location) => Promise<void>;
  formatDistance: (meters: number | undefined) => string;
}

const LocationContext = createContext<LocationContextType | undefined>(undefined);

export const LocationProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [location, setLocation] = useState<Location | null>(() => {
    const saved = localStorage.getItem('user_location');
    return saved ? JSON.parse(saved) : null;
  });
  const [permissionStatus, setPermissionStatus] = useState<PermissionState | 'unknown'>('unknown');

  useEffect(() => {
    if ('permissions' in navigator) {
      navigator.permissions.query({ name: 'geolocation' as any }).then(status => {
        setPermissionStatus(status.state);
        status.onchange = () => setPermissionStatus(status.state);
      });
    }
  }, []);

  const requestLocation = async () => {
    return new Promise<void>((resolve, reject) => {
      if (!navigator.geolocation) {
        reject(new Error('Geolocation not supported'));
        return;
      }

      navigator.geolocation.getCurrentPosition(
        (position) => {
          const newLoc = {
            lat: position.coords.latitude,
            lng: position.coords.longitude,
            accuracy: position.coords.accuracy,
            timestamp: new Date().toISOString(),
          };
          
          setLocation(newLoc);
          localStorage.setItem('user_location', JSON.stringify(newLoc));
          
          // Vibrate on success as requested
          if ('vibrate' in navigator) {
            navigator.vibrate(200);
          }
          
          resolve();
        },
        (error) => {
          reject(error);
        },
        { enableHighAccuracy: true, timeout: 10000, maximumAge: 0 }
      );
    });
  };

  const updateLocationOnServer = async (loc: Location) => {
    try {
      await POST('/api/auth/location', loc);
    } catch (err) {
      console.error('Failed to sync location with server', err);
    }
  };

  const formatDistance = (meters: number | undefined) => {
    if (meters === undefined) return 'Calculating...';
    if (meters < 1000) return `${Math.round(meters)}m away`;
    return `${(meters / 1000).toFixed(1)}km away`;
  };

  return (
    <LocationContext.Provider value={{ location, permissionStatus, requestLocation, updateLocationOnServer, formatDistance }}>
      {children}
    </LocationContext.Provider>
  );
};

export const useLocation = () => {
  const context = useContext(LocationContext);
  if (!context) throw new Error('useLocation must be used within LocationProvider');
  return context;
};

import { CalendarDays, MapPin, Users, Ticket as TicketIcon, Search, X, RefreshCw, CheckCircle, Tag, Wallet, AlertCircle, Navigation, Plus, Camera, Clock, Info, Download, Sparkles, TrendingUp, CreditCard, Smartphone } from 'lucide-react';
import { useState, useEffect } from 'react';
import React from 'react';
import { useAuth } from '../context/AuthContext';
import { useLocation } from '../context/LocationContext';
import { GET, POST } from '../lib/api';
import TicketModal from '../components/Ticket';
import { getAiRecommendations, Recommendation } from '../lib/recommendations';

interface Event {
  id: string;
  title: string;
  description: string | null;
  campus: string;
  venue: string | null;
  startDate: string;
  endDate: string | null;
  price: number;
  capacity: number | null;
  image: string | null;
  organizer: { id: string; name: string; avatar: string | null };
  _count: { rsvps: number; tickets: number };
  distance?: number;
}

const CAMPUSES = ['All Campuses','UoN Main','Strathmore','JKUAT Main','TU Kenya','KU Main','Mount Kenya Uni','Daystar','Nazarene'];

const formatDate = (d: string) => new Date(d).toLocaleDateString('en-KE', { weekday: 'short', day: 'numeric', month: 'short', year: 'numeric' });
const formatTime = (d: string) => new Date(d).toLocaleTimeString('en-KE', { hour: '2-digit', minute: '2-digit' });

const FALLBACK_IMAGES = [
  'https://images.unsplash.com/photo-1540575467063-178a50c2df87?w=600&q=80',
  'https://images.unsplash.com/photo-1492684223066-81342ee5ff30?w=600&q=80',
  'https://images.unsplash.com/photo-1514525253161-7a46d19cd819?w=600&q=80',
  'https://images.unsplash.com/photo-1533174072545-7a4b6ad7a6c3?w=600&q=80',
  'https://images.unsplash.com/photo-1559136555-9303baea8ebd?w=600&q=80',
  'https://images.unsplash.com/photo-1527224538127-2104bb71c51b?w=600&q=80',
];

export default function Events() {
  const { user, refresh } = useAuth();
  const { location, formatDistance } = useLocation();

  const [events,         setEvents]         = useState<Event[]>([]);
  const [loading,        setLoading]        = useState(true);
  const [search,         setSearch]         = useState('');
  const [campus,         setCampus]         = useState('All Campuses');
  const [activeTab,      setActiveTab]      = useState<'discover'|'mytickets'>('discover');
  const [myTickets,      setMyTickets]      = useState<any[]>([]);
  const [ticketsLoading, setTicketsLoading] = useState(false);
  const [actionLoading,  setActionLoading]  = useState<string|null>(null);
  const [rsvpd,          setRsvpd]          = useState<Set<string>>(new Set());
  const [purchased,      setPurchased]      = useState<Set<string>>(new Set());
  const [toast,          setToast]          = useState<{msg:string; type:'success'|'error'}|null>(null);
  const [selectedTicket, setSelectedTicket] = useState<any | null>(null);
  const [showCreateModal, setShowCreateModal] = useState(false);
  const [newEvent, setNewEvent] = useState({
    title: '', description: '', campus: '', venue: '', startDate: '', price: 0, image: ''
  });
  const [isCreating, setIsCreating] = useState(false);

  // Confirmation modal state
  const [confirmEvent,   setConfirmEvent]   = useState<Event|null>(null);
  const [payMethod,      setPayMethod]      = useState<'WALLET' | 'MPESA' | 'CARD'>('WALLET');
  const [aiRecs,        setAiRecs]        = useState<Recommendation[]>([]);

  useEffect(() => { fetchEvents(); }, [campus]);
  useEffect(() => { if (activeTab === 'mytickets') fetchMyTickets(); }, [activeTab]);

  const showToast = (msg: string, type: 'success'|'error' = 'success') => {
    setToast({ msg, type });
    setTimeout(() => setToast(null), 4000);
  };

  const fetchEvents = async () => {
    setLoading(true);
    try {
      const params = new URLSearchParams({ page: '1', limit: '12' });
      if (campus !== 'All Campuses') params.set('campus', campus);
      if (location) {
        params.set('lat', String(location.lat));
        params.set('lng', String(location.lng));
      }
      const [eventsRes, recommendations] = await Promise.all([
        GET(`/api/events?${params}`),
        getAiRecommendations({ location, category: 'EVENTS' })
      ]);
      setEvents(eventsRes.data.events);
      setAiRecs(recommendations);
    } catch (err) { console.error(err); }
    finally { setLoading(false); }
  };

  const fetchMyTickets = async () => {
    setTicketsLoading(true);
    try {
      // Use eventTickets via buyer wallet transactions as proxy
      const res = await GET('/api/buyer/wallet/transactions?limit=50');
      const ticketTxns = (res.data.transactions || []).filter((t: any) => t.description?.toLowerCase().includes('ticket'));
      setMyTickets(ticketTxns);
    } catch {}
    finally { setTicketsLoading(false); }
  };

  const handleRSVP = async (eventId: string) => {
    if (!user) { showToast('Please log in to RSVP', 'error'); return; }
    setActionLoading(eventId + '-rsvp');
    try {
      await POST(`/api/events/${eventId}/rsvp`, {});
      setRsvpd(prev => {
        const s = new Set(prev);
        prev.has(eventId) ? s.delete(eventId) : s.add(eventId);
        return s;
      });
      showToast(rsvpd.has(eventId) ? 'RSVP cancelled' : '✅ RSVP confirmed!');
    } catch (err: any) {
      showToast(err.message || 'Failed to RSVP', 'error');
    } finally { setActionLoading(null); }
  };

  // Step 1 — show confirmation modal
  const handleTicketClick = (event: Event) => {
    if (!user) { showToast('Please log in to buy tickets', 'error'); return; }
    if (purchased.has(event.id)) { showToast('You already have a ticket for this event!', 'error'); return; }
    setConfirmEvent(event);
  };

  // Step 2 — actual purchase after confirmation
  const confirmPurchase = async () => {
    if (!confirmEvent) return;
    const event = confirmEvent;
    setConfirmEvent(null);

    // Check wallet balance before even calling API
    if (event.price > 0 && (user?.walletBalance ?? 0) < event.price) {
      showToast(`Insufficient balance. You need KSH ${event.price.toLocaleString()} but have KSH ${(user?.walletBalance ?? 0).toLocaleString()}`, 'error');
      return;
    }

    setActionLoading(event.id + '-ticket');
    try {
      const res = await POST(`/api/events/${event.id}/ticket`, { paymentMethod: payMethod });
      setPurchased(prev => new Set([...prev, event.id]));
      await refresh();
      
      const ticketData = res.data.ticket;
      showToast(event.price === 0 ? '🎟️ Ticket confirmed!' : '🎟️ Ticket purchased!');
      setSelectedTicket(ticketData);
    } catch (err: any) {
      showToast(err.message || 'Failed to buy ticket', 'error');
    } finally {
      setActionLoading(null);
    }
  };

  const handleCreateEvent = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newEvent.title || !newEvent.startDate || !newEvent.campus) {
      showToast('Please fill all required fields', 'error');
      return;
    }
    setIsCreating(true);
    try {
      await POST('/api/events', newEvent);
      showToast('Event created successfully!');
      setShowCreateModal(false);
      setNewEvent({ title: '', description: '', campus: '', venue: '', startDate: '', price: 0, image: '' });
      fetchEvents();
    } catch (err: any) {
      showToast(err.message || 'Failed to create event', 'error');
    } finally {
      setIsCreating(false);
    }
  };

  const filtered = events.filter(e =>
    !search || e.title.toLowerCase().includes(search.toLowerCase()) || e.campus.toLowerCase().includes(search.toLowerCase())
  );

  return (
    <div className="min-h-screen bg-white">

      {/* Ticket Modal */}
      {selectedTicket && (
        <TicketModal ticket={selectedTicket} onClose={() => setSelectedTicket(null)} />
      )}

      {/* Create Event Modal */}
      {showCreateModal && (
        <div className="fixed inset-0 z-[100] bg-gray-900/80 backdrop-blur-sm flex items-center justify-center p-4 overflow-y-auto">
          <div className="bg-white rounded-[2.5rem] w-full max-w-xl shadow-2xl overflow-hidden flex flex-col my-8">
            <div className="p-8 border-b border-gray-100 flex items-center justify-between">
              <div>
                <h2 className="text-xl font-black text-gray-900 tracking-tight">CREATE NEW EVENT</h2>
                <p className="text-[10px] text-gray-400 font-bold uppercase tracking-widest mt-1">Host an experience on campus</p>
              </div>
              <button onClick={() => setShowCreateModal(false)} className="p-2 hover:bg-gray-100 rounded-full transition-colors">
                <X className="w-6 h-6 text-gray-400" />
              </button>
            </div>

            <form onSubmit={handleCreateEvent} className="p-8 space-y-6 overflow-y-auto max-h-[70vh]">
              <div className="space-y-4">
                 <div>
                   <label className="text-[10px] font-black text-gray-400 uppercase tracking-widest mb-1.5 block">Event Title *</label>
                   <input 
                     type="text" required value={newEvent.title}
                     onChange={e => setNewEvent({...newEvent, title: e.target.value})}
                     className="w-full bg-gray-50 border border-gray-100 rounded-2xl p-4 text-sm focus:outline-none focus:border-pink-500 transition-all font-bold"
                     placeholder="e.g. Annual Tech Hackathon"
                   />
                 </div>

                 <div className="grid grid-cols-2 gap-4">
                   <div>
                     <label className="text-[10px] font-black text-gray-400 uppercase tracking-widest mb-1.5 block">Campus *</label>
                     <select 
                       required value={newEvent.campus}
                       onChange={e => setNewEvent({...newEvent, campus: e.target.value})}
                       className="w-full bg-gray-50 border border-gray-100 rounded-2xl p-4 text-sm focus:outline-none focus:border-pink-500 transition-all font-bold appearance-none cursor-pointer"
                     >
                       <option value="">Select Campus</option>
                       {CAMPUSES.filter(c => c !== 'All Campuses').map(c => <option key={c}>{c}</option>)}
                     </select>
                   </div>
                   <div>
                     <label className="text-[10px] font-black text-gray-400 uppercase tracking-widest mb-1.5 block">Venue</label>
                     <input 
                       type="text" value={newEvent.venue}
                       onChange={e => setNewEvent({...newEvent, venue: e.target.value})}
                       className="w-full bg-gray-50 border border-gray-100 rounded-2xl p-4 text-sm focus:outline-none focus:border-pink-500 transition-all font-bold"
                       placeholder="Room/Hall"
                     />
                   </div>
                 </div>

                 <div className="grid grid-cols-2 gap-4">
                   <div>
                     <label className="text-[10px] font-black text-gray-400 uppercase tracking-widest mb-1.5 block">Start Date *</label>
                     <input 
                       type="datetime-local" required value={newEvent.startDate}
                       onChange={e => setNewEvent({...newEvent, startDate: e.target.value})}
                       className="w-full bg-gray-50 border border-gray-100 rounded-2xl p-4 text-sm focus:outline-none focus:border-pink-500 transition-all font-bold"
                     />
                   </div>
                   <div>
                     <label className="text-[10px] font-black text-gray-400 uppercase tracking-widest mb-1.5 block">Ticket Price (KSH)</label>
                     <input 
                       type="number" value={newEvent.price}
                       onChange={e => setNewEvent({...newEvent, price: parseFloat(e.target.value)})}
                       className="w-full bg-gray-50 border border-gray-100 rounded-2xl p-4 text-sm focus:outline-none focus:border-pink-500 transition-all font-bold"
                       placeholder="0 for FREE"
                     />
                   </div>
                 </div>

                 <div>
                   <label className="text-[10px] font-black text-gray-400 uppercase tracking-widest mb-1.5 block">Banner Image URL</label>
                   <input 
                     type="url" value={newEvent.image}
                     onChange={e => setNewEvent({...newEvent, image: e.target.value})}
                     className="w-full bg-gray-50 border border-gray-100 rounded-2xl p-4 text-sm focus:outline-none focus:border-pink-500 transition-all font-bold"
                     placeholder="https://images.unsplash.com/..."
                   />
                 </div>

                 <div>
                   <label className="text-[10px] font-black text-gray-400 uppercase tracking-widest mb-1.5 block">Description</label>
                   <textarea 
                     value={newEvent.description}
                     onChange={e => setNewEvent({...newEvent, description: e.target.value})}
                     className="w-full bg-gray-50 border border-gray-100 rounded-2xl p-4 text-sm focus:outline-none focus:border-pink-500 transition-all font-bold min-h-[100px]"
                     placeholder="Tell everyone what the event is about..."
                   />
                 </div>
              </div>

              <div className="bg-pink-50 p-4 rounded-2xl border border-pink-100 flex items-start gap-3">
                 <Info className="w-5 h-5 text-pink-500 flex-shrink-0" />
                 <p className="text-[10px] text-pink-700 font-bold leading-tight">
                   By posting an event, you agree to comply with campus policies. Your event will be visible to all students in your selected campus.
                 </p>
              </div>

              <button 
                type="submit" disabled={isCreating}
                className="w-full bg-pink-500 text-white p-5 rounded-3xl font-black text-[10px] uppercase tracking-[0.2em] shadow-xl hover:bg-pink-600 transition-all disabled:opacity-50 flex items-center justify-center gap-2"
              >
                {isCreating ? <RefreshCw className="w-4 h-4 animate-spin" /> : <CheckCircle className="w-4 h-4" />}
                {isCreating ? 'Publishing...' : 'Publish Event'}
              </button>
            </form>
          </div>
        </div>
      )}

      {/* Toast */}
      {toast && (
        <div className={`fixed top-4 right-4 z-50 max-w-sm px-4 py-3 rounded-xl shadow-lg text-sm font-medium flex items-start gap-2 ${
          toast.type === 'success' ? 'bg-green-500 text-white' : 'bg-red-500 text-white'
        }`}>
          {toast.type === 'success' ? <CheckCircle className="w-4 h-4 flex-shrink-0 mt-0.5" /> : <AlertCircle className="w-4 h-4 flex-shrink-0 mt-0.5" />}
          <span>{toast.msg}</span>
        </div>
      )}

      {/* Confirmation Modal */}
      {confirmEvent && (
        <div className="fixed inset-0 z-50 bg-black/50 flex items-center justify-center p-4" onClick={() => setConfirmEvent(null)}>
          <div className="bg-white rounded-2xl shadow-2xl w-full max-w-sm p-6" onClick={e => e.stopPropagation()}>
            <div className="flex items-center justify-between mb-4">
              <h3 className="font-bold text-lg">Confirm Purchase</h3>
              <button onClick={() => setConfirmEvent(null)} className="text-gray-400 hover:text-gray-600">
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="bg-pink-50 border border-pink-200 rounded-xl p-4 mb-5">
              <p className="font-semibold text-gray-900 mb-1">{confirmEvent.title}</p>
              <p className="text-xs text-gray-500 flex items-center gap-1 mb-1">
                <CalendarDays className="w-3 h-3" /> {formatDate(confirmEvent.startDate)}
              </p>
              <p className="text-xs text-gray-500 flex items-center gap-1">
                <MapPin className="w-3 h-3" /> {confirmEvent.venue || confirmEvent.campus}
              </p>
            </div>

            {/* Price breakdown */}
            <div className="space-y-4 mb-5 text-sm">
              <div className="flex justify-between text-gray-600">
                <span>Ticket Price</span>
                <span className="font-semibold">{confirmEvent.price === 0 ? 'FREE' : `KSH ${confirmEvent.price.toLocaleString()}`}</span>
              </div>
              
              {confirmEvent.price > 0 && (
                <div className="space-y-2 mt-4">
                  <p className="text-[10px] font-black text-gray-400 uppercase tracking-widest mb-2">Select Payment Method</p>
                  
                  <button 
                    onClick={() => setPayMethod('WALLET')}
                    className={`w-full flex items-center justify-between p-3 rounded-xl border transition-all ${
                      payMethod === 'WALLET' ? 'border-pink-500 bg-pink-50 shadow-sm' : 'border-gray-100 hover:border-pink-200'
                    }`}
                  >
                    <div className="flex items-center gap-2">
                       <Wallet className={`w-4 h-4 ${payMethod === 'WALLET' ? 'text-pink-500' : 'text-gray-300'}`} />
                       <div className="text-left">
                          <p className="text-xs font-bold text-gray-900">Kampas Wallet</p>
                          <p className={`text-[9px] font-medium ${
                            (user?.walletBalance ?? 0) >= confirmEvent.price ? 'text-green-600' : 'text-red-500'
                          }`}>
                            Balance: KSH {(user?.walletBalance ?? 0).toLocaleString()}
                          </p>
                       </div>
                    </div>
                    {payMethod === 'WALLET' && <CheckCircle className="w-4 h-4 text-pink-500" />}
                  </button>

                  <button 
                    onClick={() => setPayMethod('MPESA')}
                    className={`w-full flex items-center justify-between p-3 rounded-xl border transition-all ${
                      payMethod === 'MPESA' ? 'border-pink-500 bg-pink-50 shadow-sm' : 'border-gray-100 hover:border-pink-200'
                    }`}
                  >
                    <div className="flex items-center gap-2">
                       <Smartphone className={`w-4 h-4 ${payMethod === 'MPESA' ? 'text-pink-500' : 'text-gray-300'}`} />
                       <div className="text-left">
                          <p className="text-xs font-bold text-gray-900">M-PESA STK Push</p>
                          <p className="text-[9px] font-medium text-gray-400">Directly from your phone</p>
                       </div>
                    </div>
                    {payMethod === 'MPESA' && <CheckCircle className="w-4 h-4 text-pink-500" />}
                  </button>

                  <button 
                    onClick={() => setPayMethod('CARD')}
                    className={`w-full flex items-center justify-between p-3 rounded-xl border transition-all ${
                      payMethod === 'CARD' ? 'border-pink-500 bg-pink-50 shadow-sm' : 'border-gray-100 hover:border-pink-200'
                    }`}
                  >
                    <div className="flex items-center gap-2">
                       <CreditCard className={`w-4 h-4 ${payMethod === 'CARD' ? 'text-pink-500' : 'text-gray-300'}`} />
                       <div className="text-left">
                          <p className="text-xs font-bold text-gray-900">Credit / Debit Card</p>
                          <p className="text-[9px] font-medium text-gray-400">Secure payment gateway</p>
                       </div>
                    </div>
                    {payMethod === 'CARD' && <CheckCircle className="w-4 h-4 text-pink-500" />}
                  </button>
                </div>
              )}
            </div>

            <div className="flex gap-3">
              <button onClick={() => setConfirmEvent(null)}
                className="flex-1 py-3 rounded-xl border border-gray-200 text-sm font-semibold text-gray-600 hover:bg-gray-50 transition-colors">
                Cancel
              </button>
              <button
                onClick={confirmPurchase}
                disabled={confirmEvent.price > 0 && payMethod === 'WALLET' && (user?.walletBalance ?? 0) < confirmEvent.price}
                className="flex-1 py-3 rounded-xl bg-pink-500 text-white text-sm font-bold hover:bg-pink-600 transition-all shadow-xl shadow-pink-100 disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center gap-2">
                <TicketIcon className="w-4 h-4" />
                {confirmEvent.price === 0 ? 'Get Free Ticket' : `Pay KSH ${confirmEvent.price.toLocaleString()}`}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Page header */}
      <div className="bg-gradient-to-br from-pink-50 to-white border-b border-pink-200 px-4 md:px-8 py-8">
        <div className="max-w-6xl mx-auto">
          <div className="flex flex-col md:flex-row md:items-end justify-between gap-4 mb-6">
            <div>
              <h1 className="text-3xl font-bold mb-1">Campus Events</h1>
              <p className="text-gray-500 text-sm">Discover events happening across Kenyan campuses.</p>
            </div>
            
            {(user?.role === 'SELLER' || user?.role === 'ADMIN') && (
              <button 
                onClick={() => setShowCreateModal(true)}
                className="bg-gray-900 text-white px-6 py-3 rounded-2xl font-black text-[10px] uppercase tracking-widest flex items-center gap-2 hover:bg-pink-500 transition-all shadow-xl"
              >
                 <Plus className="w-4 h-4" /> Create Event
              </button>
            )}
          </div>

          <div className="flex gap-2 mb-8">
            {(['discover','mytickets'] as const).map(t => (
              <button key={t} onClick={() => setActiveTab(t)}
                className={`px-5 py-2 rounded-xl text-sm font-semibold transition-all ${
                  activeTab === t ? 'bg-pink-500 text-white shadow-sm' : 'bg-white border border-pink-200 text-gray-600 hover:border-pink-400'
                }`}>
                {t === 'discover' ? '🔍 Discover' : '🎟️ My Tickets'}
              </button>
            ))}
          </div>

          {activeTab === 'discover' && (
            <div className="flex flex-col sm:flex-row gap-3">
              <div className="relative flex-1">
                <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
                <input type="text" placeholder="Search events..." value={search}
                  onChange={e => setSearch(e.target.value)}
                  className="w-full bg-white border border-pink-200 rounded-xl py-2.5 pl-9 pr-4 text-sm focus:outline-none focus:border-pink-500" />
                {search && <button onClick={() => setSearch('')} className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-400"><X className="w-3.5 h-3.5" /></button>}
              </div>
              <select value={campus} onChange={e => setCampus(e.target.value)}
                className="bg-white border border-pink-200 rounded-xl px-4 py-2.5 text-sm focus:outline-none focus:border-pink-500 text-gray-700">
                {CAMPUSES.map(c => <option key={c}>{c}</option>)}
              </select>
            </div>
          )}
        </div>
      </div>

      <div className="px-4 md:px-8 py-8 max-w-6xl mx-auto">
        {/* AI Recommendations */}
        {activeTab === 'discover' && aiRecs.length > 0 && (
          <div className="mb-12">
            <div className="flex items-center justify-between mb-6">
              <div className="flex items-center gap-2">
                <Sparkles className="w-5 h-5 text-indigo-500 animate-pulse" />
                <h2 className="text-sm font-black uppercase tracking-[0.2em] text-gray-400">Recommended For You</h2>
              </div>
              <div className="px-3 py-1 bg-indigo-50 text-indigo-600 rounded-full text-[10px] font-black uppercase tracking-widest border border-indigo-100 shadow-sm shadow-indigo-100/50">
                AI Powered Radar
              </div>
            </div>
            <div className="flex gap-6 overflow-x-auto pb-4 scrollbar-hide">
              {aiRecs.map(rec => (
                <div key={rec.id} onClick={() => {
                  const ev = events.find(e => e.id === rec.id);
                  if (ev) handleTicketClick(ev);
                }} className="w-72 flex-shrink-0 bg-white border border-indigo-100 p-3 rounded-[2.5rem] shadow-sm hover:shadow-2xl transition-all cursor-pointer group hover:-translate-y-1">
                   <div className="relative aspect-video rounded-3xl overflow-hidden mb-4">
                     <img src={rec.image} className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-700" />
                     <div className="absolute top-3 right-3 bg-white/95 backdrop-blur px-2 py-1 rounded-xl text-[9px] font-black shadow-lg flex items-center gap-1 text-gray-900 border border-indigo-50">
                        <TrendingUp className="w-3.5 h-3.5 text-emerald-500" /> {(rec.relevance || 0).toFixed(0)}% MATCH
                     </div>
                     {rec.distance && (
                       <div className="absolute bottom-3 left-3 bg-gray-900/80 text-white text-[8px] font-black px-2.5 py-1.5 rounded-xl backdrop-blur-sm shadow-xl">
                          <Navigation className="w-3 h-3 inline mr-1 fill-current" />
                          {(rec.distance / 1000).toFixed(1)}km AWAY
                       </div>
                     )}
                   </div>
                   <div className="px-3 pb-2">
                      <h3 className="text-sm font-black text-gray-900 uppercase tracking-tight mb-2 truncate group-hover:text-indigo-600 transition-colors">{rec.title}</h3>
                      <div className="flex items-center justify-between">
                         <div className="flex flex-col">
                            <span className="text-[10px] font-black text-indigo-500">KSH {rec.price?.toLocaleString() || 'FREE'}</span>
                            <span className="text-[8px] font-bold text-gray-400 mt-0.5 uppercase tracking-widest">{rec.campus}</span>
                         </div>
                         <button className="bg-indigo-500 text-white p-2 rounded-xl group-hover:bg-indigo-600 transition-colors shadow-lg">
                            <TicketIcon className="w-4 h-4" />
                         </button>
                      </div>
                   </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Discover tab */}
        {activeTab === 'discover' && (
          loading ? (
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
              {Array.from({ length: 6 }).map((_, i) => (
                <div key={i} className="bg-pink-50 rounded-2xl overflow-hidden border border-pink-100 animate-pulse">
                  <div className="h-48 bg-pink-100" />
                  <div className="p-5 space-y-3">
                    <div className="h-4 bg-pink-100 rounded w-3/4" />
                    <div className="h-3 bg-pink-100 rounded w-1/2" />
                    <div className="h-8 bg-pink-100 rounded mt-4" />
                  </div>
                </div>
              ))}
            </div>
          ) : filtered.length === 0 ? (
            <div className="text-center py-20">
              <CalendarDays className="w-12 h-12 text-pink-200 mx-auto mb-3" />
              <p className="text-gray-500 font-semibold">No events found</p>
            </div>
          ) : (
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
              {filtered.map((event, idx) => {
                const image      = event.image || FALLBACK_IMAGES[idx % FALLBACK_IMAGES.length];
                const isFree     = event.price === 0;
                const isRsvpd    = rsvpd.has(event.id);
                const hasPurchased = purchased.has(event.id);
                const isLoadingRsvp   = actionLoading === event.id + '-rsvp';
                const isLoadingTicket = actionLoading === event.id + '-ticket';
                const canAfford   = isFree || (user?.walletBalance ?? 0) >= event.price;

                return (
                  <div key={event.id}
                    className="bg-white border border-pink-100 rounded-2xl overflow-hidden hover:border-pink-300 hover:shadow-lg hover:shadow-pink-50 transition-all group flex flex-col">

                    <div className="relative h-44 overflow-hidden bg-pink-50">
                      <img src={image} alt={event.title}
                        className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500" />
                      <div className="absolute inset-0 bg-gradient-to-t from-black/40 to-transparent" />
                      <div className={`absolute top-3 right-3 px-2.5 py-1 rounded-lg text-xs font-bold ${isFree ? 'bg-green-500 text-white' : 'bg-pink-500 text-white'}`}>
                        {isFree ? 'FREE' : `KSH ${event.price.toLocaleString()}`}
                      </div>
                      <div className="absolute bottom-3 left-3 bg-white/90 backdrop-blur-sm px-2 py-0.5 rounded-lg text-[10px] font-semibold text-gray-700">
                        {event.campus}
                      </div>
                    </div>

                    <div className="p-4 flex flex-col flex-1">
                      <h3 className="font-bold text-gray-900 mb-3 line-clamp-2 group-hover:text-pink-600 transition-colors">
                        {event.title}
                      </h3>
                        <div className="space-y-1.5 mb-4 text-xs text-gray-500">
                        <div className="flex items-center gap-2"><CalendarDays className="w-3.5 h-3.5 text-pink-400 flex-shrink-0" />{formatDate(event.startDate)} • {formatTime(event.startDate)}</div>
                        <div className="flex items-center gap-2">
                          <MapPin className="w-3.5 h-3.5 text-pink-400 flex-shrink-0" />
                          <span className="truncate">{event.venue || event.campus}</span>
                          {event.distance !== undefined && (
                            <span className="text-[10px] text-pink-600 font-black ml-auto flex items-center gap-1">
                              <Navigation className="w-2.5 h-2.5 fill-current" />
                              {formatDistance(event.distance)}
                            </span>
                          )}
                        </div>
                        <div className="flex items-center gap-2"><Users className="w-3.5 h-3.5 text-pink-400 flex-shrink-0" />{event._count.rsvps} going • {event._count.tickets} tickets sold</div>
                        <div className="flex items-center gap-2"><Tag className="w-3.5 h-3.5 text-pink-400 flex-shrink-0" />By {event.organizer.name}</div>
                      </div>

                      {/* Wallet warning for paid events */}
                      {!isFree && !hasPurchased && !canAfford && (
                          <div className="flex items-center gap-1.5 text-[11px] text-orange-600 bg-orange-50 border border-orange-200 rounded-lg px-2.5 py-1.5 mb-3">
                            <AlertCircle className="w-3.5 h-3.5 flex-shrink-0 mt-0.5" />
                            Insufficient balance — top up KSH {(event.price - (user?.walletBalance ?? 0)).toLocaleString()} more
                        </div>
                        )}

                      <div className="mt-auto flex gap-2">
                          <button onClick={() => handleRSVP(event.id)} disabled={!!isLoadingRsvp}
                            className={`flex-1 py-2 rounded-xl text-xs font-bold border transition-all flex items-center justify-center gap-1.5 ${
                            isRsvpd
                                ? 'bg-pink-100 border-pink-300 text-pink-700'
                                : 'bg-white border-pink-200 text-gray-700 hover:border-pink-400'
                            }`}>
                          {isLoadingRsvp ? <RefreshCw className="w-3.5 h-3.5 animate-spin" /> : isRsvpd ? '✓ Going' : '+ RSVP'}
                        </button>

                        <button
                            onClick={() => handleTicketClick(event)}
                            disabled={!!isLoadingTicket || hasPurchased}
                            className={`flex-1 py-2 rounded-xl text-xs font-bold transition-all flex items-center justify-center gap-1.5 ${
                              hasPurchased
                                ? 'bg-green-500 text-white cursor-default'
                                : canAfford
                                ? 'bg-pink-500 text-white hover:bg-pink-600'
                                : 'bg-gray-100 text-gray-400 cursor-not-allowed'
                            } disabled:opacity-70`}>
                            {isLoadingTicket
                              ? <RefreshCw className="w-3.5 h-3.5 animate-spin" />
                              : hasPurchased
                              ? <><CheckCircle className="w-3.5 h-3.5" /> Got Ticket</>
                              : <><TicketIcon className="w-3.5 h-3.5" /> {isFree ? 'Get Ticket' : 'Buy Ticket'}</>
                            }
                        </button>
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          )
        )}

        {/* My Tickets tab */}
        {activeTab === 'mytickets' && (
          ticketsLoading ? (
            <div className="text-center py-16 text-gray-400">Loading your tickets...</div>
          ) : myTickets.length === 0 ? (
            <div className="text-center py-20">
              <TicketIcon className="w-12 h-12 text-pink-200 mx-auto mb-3" />
              <p className="text-gray-500 font-semibold">No tickets yet</p>
              <p className="text-gray-400 text-sm mt-1">Get tickets to upcoming events to see them here.</p>
              <button onClick={() => setActiveTab('discover')}
                className="mt-4 bg-pink-500 text-white text-sm font-bold px-6 py-2 rounded-xl hover:bg-pink-600 transition-colors">
                Browse Events
              </button>
            </div>
          ) : (
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              {myTickets.map((tx, i) => (
                <div key={i} className="bg-white border border-pink-100 rounded-[2rem] p-6 flex flex-col md:flex-row items-center gap-6 shadow-sm hover:shadow-md transition-all">
                  <div className="w-20 h-20 bg-pink-50 rounded-2xl flex items-center justify-center text-pink-500 flex-shrink-0 shadow-inner">
                    <TicketIcon className="w-10 h-10" />
                  </div>
                  <div className="flex-1 min-w-0 text-center md:text-left">
                    <div className="flex items-center justify-center md:justify-start gap-2 mb-1">
                      <p className="font-black text-gray-900 text-lg tracking-tight truncate">{tx.description?.replace('Ticket for ', '') || 'Event Ticket'}</p>
                      <span className="text-[8px] font-black px-2 py-1 rounded-full bg-green-100 text-green-700 uppercase tracking-widest">VALID</span>
                    </div>
                    <div className="flex flex-wrap justify-center md:justify-start gap-4 text-xs text-gray-400 font-bold uppercase tracking-widest">
                       <span className="flex items-center gap-1.5"><CalendarDays className="w-3.5 h-3.5" /> {new Date(tx.createdAt).toLocaleDateString('en-KE')}</span>
                       <span className="flex items-center gap-1.5 text-pink-500"><Wallet className="w-3.5 h-3.5" /> KSH {Math.abs(tx.amount).toLocaleString()} paid</span>
                    </div>
                  </div>
                  <button 
                    onClick={() => setSelectedTicket({
                      id: tx.id,
                      eventTitle: tx.description?.replace('Ticket for ', ''),
                      price: Math.abs(tx.amount),
                      startDate: tx.createdAt, // Fallback if real event date not in tx
                      buyerName: user?.name,
                      campus: user?.campus
                    })}
                    className="w-full md:w-auto bg-gray-900 text-white px-8 py-4 rounded-2xl font-black text-[10px] uppercase tracking-widest flex items-center justify-center gap-2 hover:bg-pink-500 transition-all shadow-xl"
                  >
                     <Download className="w-4 h-4" /> View Ticket
                  </button>
                </div>
              ))}
            </div>
          )
        )}
      </div>
    </div>
  );
}

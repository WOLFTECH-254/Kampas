import React, { useState, useEffect, useRef } from 'react';
import { MapPin, ShieldCheck, Home, Search, SlidersHorizontal, Navigation, Bot, Plus, X, Camera, CheckCircle2, MessageSquare, Phone, Map as MapIcon, Info, Sparkles, ChevronLeft, ChevronRight, Mail, Hash, Layers, AlertTriangle, TrendingDown } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { GET, POST } from '../lib/api';
import { useLocation } from '../context/LocationContext';
import { useAuth } from '../context/AuthContext';
import MapView from '../components/MapView';
import { getAiRecommendations, Recommendation } from '../lib/recommendations';

interface House {
  id: string;
  title: string;
  price: number;
  deposit?: number;
  type: string;
  description: string;
  campus: string;
  address: string;
  rooms?: string;
  email?: string;
  phone?: string;
  images: { url: string }[];
  verified: boolean;
  amenities: string[];
  availabilityStatus: 'AVAILABLE' | 'OCCUPIED' | 'COMING_SOON';
  distance?: number;
  lat?: number;
  lng?: number;
  createdBy?: string;
  creator?: any;
}

function ImageCarousel({ images, className = "" }: { images: { url: string }[], className?: string }) {
  const [index, setIndex] = useState(0);

  if (!images || images.length === 0) return (
    <div className={`bg-pink-100 flex items-center justify-center ${className}`}>
      <Home className="w-10 h-10 text-pink-300" />
    </div>
  );

  return (
    <div className={`relative group overflow-hidden ${className}`}>
      <motion.div 
        key={index}
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        exit={{ opacity: 0 }}
        transition={{ duration: 0.5 }}
        className="w-full h-full"
      >
        <img src={images[index].url} className="w-full h-full object-cover" alt="Property" />
      </motion.div>
      
      {images.length > 1 && (
        <>
          <button 
            onClick={(e) => { e.stopPropagation(); setIndex(prev => (prev === 0 ? images.length - 1 : prev - 1)); }}
            className="absolute left-2 top-1/2 -translate-y-1/2 p-1.5 rounded-full bg-black/30 text-white backdrop-blur-md opacity-0 group-hover:opacity-100 transition-opacity"
          >
            <ChevronLeft className="w-4 h-4" />
          </button>
          <button 
            onClick={(e) => { e.stopPropagation(); setIndex(prev => (prev === images.length - 1 ? 0 : prev + 1)); }}
            className="absolute right-2 top-1/2 -translate-y-1/2 p-1.5 rounded-full bg-black/30 text-white backdrop-blur-md opacity-0 group-hover:opacity-100 transition-opacity"
          >
            <ChevronRight className="w-4 h-4" />
          </button>
          <div className="absolute bottom-3 left-1/2 -translate-x-1/2 flex gap-1">
            {images.map((_, i) => (
              <div key={i} className={`w-1.5 h-1.5 rounded-full transition-all ${i === index ? 'bg-pink-500 w-3' : 'bg-white/50'}`} />
            ))}
          </div>
        </>
      )}
    </div>
  );
}

export default function Housing() {
  const { user } = useAuth();
  const { location, formatDistance, requestLocation } = useLocation();
  
  const [houses, setHouses] = useState<House[]>([]);
  const [loading, setLoading] = useState(true);
  const [aiRecs, setAiRecs] = useState<Recommendation[]>([]);
  
  // Modals
  const [showAddForm, setShowAddForm] = useState(false);
  const [selectedHouse, setSelectedHouse] = useState<House | null>(null);
  
  // Form State
  const [form, setForm] = useState({
    title: '', type: 'BEDSITTER', price: '', deposit: '', description: '', 
    campus: user?.campus || '', address: '', amenities: [] as string[],
    rooms: '1', email: user?.email || '', phone: user?.phone || '',
    images: ['', '', '', ''] // Support 4 URLs
  });
  const [submitting, setSubmitting] = useState(false);

  const fetchHouses = async () => {
    setLoading(true);
    try {
      const url = location ? `/api/properties?lat=${location.lat}&lng=${location.lng}` : '/api/properties';
      const [housingRes, recommendations] = await Promise.all([
        GET(url),
        getAiRecommendations({ location, category: 'HOUSING' })
      ]);
      setHouses(housingRes.data.properties);
      setAiRecs(recommendations);
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchHouses();
  }, [location]);

  const handleAddHouse = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!location) {
      alert('Location verification is mandatory to post a listing.');
      await requestLocation();
      return;
    }
    setSubmitting(true);
    try {
      const body = { 
        ...form, 
        lat: location.lat, 
        lng: location.lng,
        images: form.images.filter(url => url).map(url => ({ url }))
      };
      await POST('/api/properties', body);
      setShowAddForm(false);
      fetchHouses();
      // Reset form
      setForm({
        title: '', type: 'BEDSITTER', price: '', deposit: '', description: '', 
        campus: user?.campus || '', address: '', amenities: [],
        rooms: '1', email: user?.email || '', phone: user?.phone || '',
        images: ['', '', '', '']
      });
    } catch (err) {
      console.error(err);
    } finally {
      setSubmitting(false);
    }
  };

  const checkAvailability = async (id: string) => {
    try {
      const res = await GET(`/api/properties/${id}`);
      setSelectedHouse({ ...res.data.property, creator: res.data.creator });
    } catch (err) {
      console.error(err);
    }
  };

  const AMENITIES_LIST = ['Water', 'Electricity', 'WiFi', 'Security', 'Parking', 'Balcony', 'Hot Water', 'Gated'];

  return (
    <div className="min-h-screen bg-white">
      {/* Header */}
      <div className="sticky top-0 z-30 bg-white/95 backdrop-blur border-b border-pink-100 px-4 py-4">
        <div className="flex items-center justify-between mb-4">
          <div>
            <h1 className="text-2xl font-black text-gray-900 tracking-tight text-center md:text-left">KAMPAS HOUSING</h1>
            <p className="text-xs text-gray-400 font-bold uppercase tracking-widest text-center md:text-left">Discover & List Student Homes</p>
          </div>
          <button className="p-2 bg-pink-50 rounded-xl border border-pink-200">
            <SlidersHorizontal className="w-5 h-5 text-pink-600" />
          </button>
        </div>

        <div className="relative">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
          <input type="text" placeholder="Search bedsitters, apartments, hostels..."
            className="w-full bg-pink-50 border border-pink-200 rounded-xl py-3 pl-10 pr-4 text-sm focus:outline-none focus:border-pink-500 shadow-sm" />
        </div>
      </div>

      <div className="p-4 space-y-6 pb-24 max-w-4xl mx-auto">
        {/* AI Recommendations Groups */}
        {aiRecs.length > 0 && (
          <div className="space-y-4">
             <div className="flex items-center justify-between px-1">
               <div className="flex items-center gap-2">
                 <Sparkles className="w-4 h-4 text-pink-500 animate-pulse" />
                 <h2 className="font-black text-[10px] text-gray-400 uppercase tracking-widest">AI Market Pulse</h2>
               </div>
               <div className="text-[8px] font-black text-indigo-500 bg-indigo-50 px-2 py-1 rounded-md uppercase">Personalized Discovery</div>
             </div>
             
             <div className="flex gap-4 overflow-x-auto pb-2 scrollbar-hide">
               {aiRecs.slice(0, 5).map(rec => (
                 <div key={rec.id} onClick={() => setSelectedHouse(houses.find(h => h.id === rec.id) || null)} className="w-64 flex-shrink-0 bg-white border border-pink-100 p-2 rounded-[2rem] shadow-sm hover:shadow-xl transition-all cursor-pointer group">
                   <div className="relative aspect-[16/9] rounded-2xl overflow-hidden mb-3">
                     <img src={rec.image} className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500" />
                     <div className="absolute top-2 right-2 bg-white/95 backdrop-blur px-2 py-1 rounded-lg text-[8px] font-black shadow-sm">
                       {(rec.relevance || 0).toFixed(0)}% MATCH
                     </div>
                     <div className="absolute bottom-2 left-2 flex items-center gap-1 bg-gray-900/80 text-white text-[8px] font-black px-2 py-1 rounded-lg backdrop-blur-sm">
                        <TrendingDown className="w-3 h-3 text-emerald-400" /> RECOMMENDED
                     </div>
                   </div>
                   <div className="px-2 pb-2">
                     <h3 className="text-xs font-black text-gray-900 truncate uppercase tracking-tight">{rec.title}</h3>
                     <div className="flex items-center justify-between mt-1">
                        <p className="text-[10px] font-black text-pink-500">KSH {rec.price?.toLocaleString()}</p>
                        <p className="text-[8px] font-bold text-gray-400">{rec.campus}</p>
                     </div>
                   </div>
                 </div>
               ))}
             </div>

             <div className="grid grid-cols-2 gap-3">
                <div className="bg-emerald-50 border border-emerald-100 p-4 rounded-3xl">
                  <p className="text-[9px] font-black text-emerald-600 uppercase mb-1">Top Value</p>
                  <p className="text-xs font-bold text-gray-800">Budget Stays</p>
                  <p className="text-[10px] text-emerald-600/70 mt-1 font-medium">Near {user?.campus || 'your location'}</p>
                </div>
                <div className="bg-amber-50 border border-amber-100 p-4 rounded-3xl">
                  <p className="text-[9px] font-black text-amber-600 uppercase mb-1">Coming Soon</p>
                  <p className="text-xs font-bold text-gray-800">Recently Listed</p>
                  <p className="text-[10px] text-amber-600/70 mt-1 font-medium">Be the first to view</p>
                </div>
             </div>
          </div>
        )}

        {/* Housing Feed */}
        <div className="space-y-4">
          <div className="flex items-center justify-between px-1">
            <h2 className="font-black text-xs text-gray-500 uppercase tracking-widest">Nearby Listings</h2>
            <div className="flex items-center gap-1 text-[10px] font-bold text-pink-500 bg-pink-50 px-2 py-1 rounded-full border border-pink-100 italic">
              <Navigation className="w-3 h-3 fill-current" />
              Live Near {user?.campus || 'Campus'}
            </div>
          </div>

          {loading ? (
            <div className="space-y-4">
              {[1, 2, 3].map(i => (
                <div key={i} className="h-48 bg-pink-50 rounded-3xl animate-pulse"></div>
              ))}
            </div>
          ) : (
            <div className="grid grid-cols-1 gap-6">
              {houses.map(house => (
                <div key={house.id} className="bg-white rounded-[2rem] border border-pink-100 overflow-hidden shadow-sm hover:shadow-xl transition-all flex flex-col md:flex-row group">
                  <div className="w-full md:w-64 aspect-[4/3] md:aspect-square relative flex-shrink-0">
                    <ImageCarousel images={house.images} className="w-full h-full" />
                    <div className="absolute top-3 left-3 flex flex-col gap-1.5 pointer-events-none">
                      <span className="bg-white/90 backdrop-blur px-2 py-0.5 rounded-lg text-[9px] font-black text-gray-900 border border-pink-100 shadow-sm uppercase">
                        {house.type}
                      </span>
                      {house.verified && (
                        <span className="bg-emerald-500 text-white px-2 py-0.5 rounded-lg text-[9px] font-black flex items-center gap-1 shadow-sm">
                          <CheckCircle2 className="w-2.5 h-2.5" /> VERIFIED
                        </span>
                      )}
                    </div>
                  </div>
                  <div className="p-6 flex-1 flex flex-col">
                    <div className="flex justify-between items-start mb-2">
                       <div>
                        <h3 className="font-extrabold text-gray-900 leading-tight group-hover:text-pink-600 transition-colors">{house.title}</h3>
                        <div className="flex items-center gap-1 text-gray-400 mt-1">
                          <MapPin className="w-3 h-3 text-pink-400" />
                          <span className="text-[10px] font-bold uppercase tracking-wider truncate">{house.address}</span>
                        </div>
                       </div>
                       <div className="text-right">
                        <p className="font-black text-pink-600 text-lg">KSH {house.price.toLocaleString()}</p>
                        <p className="text-[8px] font-black text-gray-400 uppercase">Per Month</p>
                       </div>
                    </div>
                    
                    <p className="text-xs text-gray-500 line-clamp-2 my-4 leading-relaxed font-medium">
                      {house.description}
                    </p>

                    <div className="flex items-center gap-2 mb-6">
                        <span className={`text-[10px] font-black px-2.5 py-1 rounded-lg ${
                          house.availabilityStatus === 'AVAILABLE' ? 'bg-emerald-50 text-emerald-600 border border-emerald-100' : 
                          house.availabilityStatus === 'OCCUPIED' ? 'bg-red-50 text-red-600 border border-red-100' : 'bg-amber-50 text-amber-600 border border-amber-100'
                        }`}>
                          ● {house.availabilityStatus}
                        </span>
                        {house.distance !== undefined && (
                          <span className="text-[10px] text-gray-400 font-bold bg-gray-50 px-2 py-1 rounded-lg border border-gray-100">
                             {formatDistance(house.distance)} Away
                          </span>
                        )}
                    </div>

                    <div className="mt-auto">
                       <button 
                        onClick={() => checkAvailability(house.id)}
                        className="w-full bg-gray-900 text-white py-3.5 rounded-2xl font-black text-xs hover:bg-pink-600 transition-all shadow-md active:scale-[0.98]"
                       >
                        CHECK AVAILABILITY
                      </button>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>

      {/* Floating Add Button */}
      {user && (
        <button 
          onClick={() => setShowAddForm(true)}
          className="fixed bottom-24 right-6 w-16 h-16 bg-pink-500 text-gray-900 rounded-full shadow-2xl flex items-center justify-center hover:scale-110 active:scale-95 transition-all z-40 border-4 border-white"
        >
          <Plus className="w-8 h-8" />
        </button>
      )}

      {/* Add House Modal */}
      {showAddForm && (
        <div className="fixed inset-0 z-[1000] flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm animate-in fade-in">
          <div className="bg-white w-full max-w-lg rounded-[2.5rem] shadow-2xl overflow-hidden max-h-[90vh] flex flex-col">
            <div className="p-6 border-b border-pink-100 flex items-center justify-between bg-pink-50/50">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-2xl bg-pink-500 flex items-center justify-center text-white">
                  <Home className="w-6 h-6" />
                </div>
                <div>
                  <h2 className="font-black text-gray-900 leading-none">POST A HOUSE</h2>
                  <p className="text-[10px] text-gray-400 font-bold uppercase tracking-widest mt-1">Listing Creation</p>
                </div>
              </div>
              <button 
                onClick={() => setShowAddForm(false)}
                className="w-10 h-10 rounded-2xl bg-white border border-pink-100 flex items-center justify-center text-gray-400 hover:text-pink-500 transition-colors"
              >
                <X className="w-5 h-5" />
              </button>
            </div>
            
            <form onSubmit={handleAddHouse} className="overflow-y-auto flex-1 p-6 space-y-5 scrollbar-hide">
              <div className="space-y-4">
                <div>
                  <label className="block text-[10px] font-black text-gray-400 uppercase tracking-widest mb-1.5 ml-1">Property Title</label>
                  <input required type="text" value={form.title} placeholder="e.g. Elegant Studio near Gate B"
                    onChange={e => setForm({...form, title: e.target.value})}
                    className="w-full bg-pink-50 border border-pink-100 rounded-2xl py-3 px-4 text-sm focus:outline-none focus:border-pink-500" />
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label className="block text-[10px] font-black text-gray-400 uppercase tracking-widest mb-1.5 ml-1">Type</label>
                    <select value={form.type} onChange={e => setForm({...form, type: e.target.value})}
                      className="w-full bg-pink-50 border border-pink-100 rounded-2xl py-3 px-4 text-sm focus:outline-none focus:border-pink-500">
                      <option value="BEDSITTER">Bedsitter</option>
                      <option value="APARTMENT">Apartment</option>
                      <option value="HOSTEL">Hostel</option>
                      <option value="ROOM">Single Room</option>
                      <option value="BNB">Airbnb/BnB</option>
                    </select>
                  </div>
                  <div>
                    <label className="block text-[10px] font-black text-gray-400 uppercase tracking-widest mb-1.5 ml-1">Rent (KSH)</label>
                    <input required type="number" value={form.price} placeholder="0"
                      onChange={e => setForm({...form, price: e.target.value})}
                      className="w-full bg-pink-50 border border-pink-100 rounded-2xl py-3 px-4 text-sm focus:outline-none focus:border-pink-500" />
                  </div>
                </div>

                <div>
                   <label className="block text-[10px] font-black text-gray-400 uppercase tracking-widest mb-1.5 ml-1">Full Address & Nearby University</label>
                   <input required type="text" value={form.address} placeholder="Juja, Gate C, Next to..."
                    onChange={e => setForm({...form, address: e.target.value})}
                    className="w-full bg-pink-50 border border-pink-100 rounded-2xl py-3 px-4 text-sm focus:outline-none focus:border-pink-500" />
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label className="block text-[10px] font-black text-gray-400 uppercase tracking-widest mb-1.5 ml-1">Rooms</label>
                    <input type="number" value={form.rooms} placeholder="1"
                      onChange={e => setForm({...form, rooms: e.target.value})}
                      className="w-full bg-pink-50 border border-pink-100 rounded-2xl py-3 px-4 text-sm focus:outline-none focus:border-pink-500" />
                  </div>
                  <div>
                    <label className="block text-[10px] font-black text-gray-400 uppercase tracking-widest mb-1.5 ml-1">Deposit (KSH)</label>
                    <input type="number" value={form.deposit} placeholder="Optional"
                      onChange={e => setForm({...form, deposit: e.target.value})}
                      className="w-full bg-pink-50 border border-pink-100 rounded-2xl py-3 px-4 text-sm focus:outline-none focus:border-pink-500" />
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-4">
                   <div>
                    <label className="block text-[10px] font-black text-gray-400 uppercase tracking-widest mb-1.5 ml-1">Contact Phone</label>
                    <input required type="tel" value={form.phone} placeholder="07..."
                      onChange={e => setForm({...form, phone: e.target.value})}
                      className="w-full bg-pink-50 border border-pink-100 rounded-2xl py-3 px-4 text-sm focus:outline-none focus:border-pink-500" />
                  </div>
                  <div>
                    <label className="block text-[10px] font-black text-gray-400 uppercase tracking-widest mb-1.5 ml-1">Contact Email</label>
                    <input type="email" value={form.email} placeholder="email@..."
                      onChange={e => setForm({...form, email: e.target.value})}
                      className="w-full bg-pink-50 border border-pink-100 rounded-2xl py-3 px-4 text-sm focus:outline-none focus:border-pink-500" />
                  </div>
                </div>

                <div>
                   <label className="block text-[10px] font-black text-gray-400 uppercase tracking-widest mb-1.5 ml-1">Description</label>
                   <textarea value={form.description} placeholder="Tell us more about the house..." rows={3}
                    onChange={e => setForm({...form, description: e.target.value})}
                    className="w-full bg-pink-50 border border-pink-100 rounded-2xl py-3 px-4 text-sm focus:outline-none focus:border-pink-500 resize-none" />
                </div>

                <div>
                  <label className="block text-[10px] font-black text-gray-400 uppercase tracking-widest mb-3 ml-1">Upload House Images (Max 4)</label>
                  <div className="grid grid-cols-2 gap-4">
                    {form.images.map((url, i) => (
                      <div key={i} className="relative group bg-pink-50 rounded-2xl border border-pink-100 p-2 overflow-hidden flex flex-col justify-center min-h-[120px]">
                        {url ? (
                          <div className="relative aspect-video rounded-xl overflow-hidden">
                            <img src={url} className="w-full h-full object-cover" />
                            <button 
                              type="button"
                              onClick={() => {
                                const next = [...form.images];
                                next[i] = '';
                                setForm({...form, images: next});
                              }}
                              className="absolute top-1 right-1 bg-black/50 text-white p-1 rounded-full backdrop-blur-sm"
                            >
                              <X className="w-3 h-3" />
                            </button>
                          </div>
                        ) : (
                          <div className="flex flex-col gap-2">
                             <label className="flex flex-col items-center justify-center py-2 cursor-pointer border-2 border-dashed border-pink-200 rounded-xl hover:bg-pink-100 transition-colors">
                                <Camera className="w-5 h-5 text-pink-400 mb-1" />
                                <span className="text-[8px] font-black text-pink-500 uppercase">Upload File</span>
                                <input 
                                  type="file" 
                                  accept="image/*" 
                                  className="hidden" 
                                  onChange={(e) => {
                                    const file = e.target.files?.[0];
                                    if (file) {
                                      const reader = new FileReader();
                                      reader.onloadend = () => {
                                        const next = [...form.images];
                                        next[i] = reader.result as string;
                                        setForm({...form, images: next});
                                      };
                                      reader.readAsDataURL(file);
                                    }
                                  }}
                                />
                             </label>
                             <div className="flex items-center gap-2">
                               <div className="h-px bg-gray-200 flex-1" />
                               <span className="text-[8px] font-bold text-gray-400">OR</span>
                               <div className="h-px bg-gray-200 flex-1" />
                             </div>
                             <input 
                              type="url" 
                              placeholder="Paste URL..."
                              onBlur={(e) => {
                                if (e.target.value) {
                                  const next = [...form.images];
                                  next[i] = e.target.value;
                                  setForm({...form, images: next});
                                }
                              }}
                              className="w-full bg-white border border-pink-100 rounded-lg py-1 px-2 text-[8px] focus:outline-none focus:border-pink-500" 
                            />
                          </div>
                        )}
                      </div>
                    ))}
                  </div>
                </div>

                <div className="p-4 bg-emerald-50 rounded-2xl border border-emerald-100 flex items-center gap-3">
                  <div className="w-8 h-8 rounded-full bg-emerald-500 flex items-center justify-center text-white">
                    <Navigation className="w-4 h-4" />
                  </div>
                  <div>
                    <p className="text-[10px] font-black text-emerald-600 uppercase">GPS Validation Required</p>
                    <p className="text-[10px] text-gray-500 leading-tight">Your current GPS location will be anchored to this listing.</p>
                  </div>
                </div>
              </div>

              <button type="submit" disabled={submitting}
                className="w-full bg-pink-500 text-gray-900 font-bold py-4 rounded-2xl mt-4 hover:bg-pink-600 transition-all flex items-center justify-center gap-2 group shadow-xl">
                {submitting ? 'Verifying & Posting...' : (<>Post Listing <Sparkles className="w-5 h-5 group-hover:scale-110 transition-transform" /></>)}
              </button>
            </form>
          </div>
        </div>
      )}

      {/* House Receipt Summary Modal */}
      <AnimatePresence>
        {selectedHouse && (
          <motion.div 
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-[1000] flex items-center justify-center p-4 md:p-6 bg-black/80 backdrop-blur-md"
          >
            <motion.div 
              initial={{ scale: 0.9, y: 20 }}
              animate={{ scale: 1, y: 0 }}
              exit={{ scale: 0.9, y: 20 }}
              className="bg-white w-full max-w-xl rounded-[2.5rem] shadow-2xl overflow-hidden relative flex flex-col max-h-[90vh]"
            >
              {/* Receipt Header Style */}
              <div className="p-8 border-b-2 border-dashed border-gray-100 bg-pink-50/30">
                <div className="flex justify-between items-start mb-6">
                  <div className="flex items-center gap-3">
                    <div className="w-12 h-12 bg-gray-900 rounded-[1.5rem] flex items-center justify-center text-white">
                      <Home className="w-6 h-6" />
                    </div>
                    <div>
                      <h2 className="text-xl font-black text-gray-900 leading-none">PROPERTY RECEIPT</h2>
                      <p className="text-[10px] text-gray-400 font-bold uppercase tracking-[0.2em] mt-1.5">Housing Verification Unit</p>
                    </div>
                  </div>
                  <button onClick={() => setSelectedHouse(null)} className="p-2 hover:bg-gray-100 rounded-full transition-colors">
                    <X className="w-6 h-6 text-gray-400" />
                  </button>
                </div>
                
                <div className="flex gap-2 overflow-x-auto pb-2 scrollbar-hide">
                  {selectedHouse.images.map((img, i) => (
                    <img key={i} src={img.url} className="w-24 h-24 rounded-2xl object-cover border-2 border-white shadow-sm flex-shrink-0" />
                  ))}
                </div>
              </div>

              <div className="p-8 overflow-y-auto scrollbar-hide space-y-8">
                {/* Basic Section */}
                <div className="space-y-4">
                   <div className="flex justify-between items-end">
                      <h3 className="text-2xl font-black text-gray-900 uppercase tracking-tight">{selectedHouse.title}</h3>
                      <span className="text-xs font-black text-pink-500 bg-pink-100 px-3 py-1 rounded-lg uppercase">{selectedHouse.type}</span>
                   </div>
                   <div className="flex items-center gap-2 text-gray-400">
                     <MapPin className="w-4 h-4 text-pink-500" />
                     <p className="text-xs font-bold uppercase tracking-wide">{selectedHouse.address}</p>
                   </div>
                </div>

                <div className="h-px bg-gray-100 w-full" />

                {/* Details Grid */}
                <div className="grid grid-cols-2 gap-y-6">
                  <div>
                    <p className="text-[9px] font-black text-gray-400 uppercase tracking-widest mb-1.5">Monthly Rent</p>
                    <p className="text-xl font-black text-gray-900">KSH {selectedHouse.price.toLocaleString()}</p>
                  </div>
                  <div className="text-right">
                    <p className="text-[9px] font-black text-gray-400 uppercase tracking-widest mb-1.5">Condition</p>
                    <p className="text-sm font-bold text-emerald-600 uppercase flex items-center justify-end gap-1">
                      <ShieldCheck className="w-4 h-4" /> Campus Approved
                    </p>
                  </div>
                  <div>
                    <p className="text-[9px] font-black text-gray-400 uppercase tracking-widest mb-1.5">Security Deposit</p>
                    <p className="text-xl font-black text-gray-900">KSH {(selectedHouse.deposit || 0).toLocaleString()}</p>
                  </div>
                  <div className="text-right">
                    <p className="text-[9px] font-black text-gray-400 uppercase tracking-widest mb-1.5">Rooms Available</p>
                    <p className="text-xl font-black text-gray-900">{selectedHouse.rooms || '1'}</p>
                  </div>
                </div>

                <div className="h-px bg-gray-100 w-full" />

                {/* Description */}
                <div className="space-y-3">
                  <div className="flex items-center gap-2">
                    <Layers className="w-4 h-4 text-gray-400" />
                    <h4 className="text-[10px] font-black text-gray-900 uppercase tracking-widest">Property Overview</h4>
                  </div>
                  <p className="text-sm text-gray-600 leading-relaxed font-medium">
                    {selectedHouse.description}
                  </p>
                </div>

                {/* Contact Section */}
                <div className="bg-pink-50/50 rounded-3xl p-6 border border-pink-100 space-y-4">
                  <h4 className="text-[10px] font-black text-pink-500 uppercase tracking-widest text-center">Contact Information</h4>
                  <div className="flex flex-col gap-3">
                    {selectedHouse.phone && (
                      <div className="flex items-center justify-between text-sm">
                        <span className="text-gray-400 font-bold">WhatsApp/Phone</span>
                        <span className="text-gray-900 font-black">{selectedHouse.phone}</span>
                      </div>
                    )}
                    {selectedHouse.email && (
                      <div className="flex items-center justify-between text-sm">
                        <span className="text-gray-400 font-bold">Official Email</span>
                        <span className="text-gray-900 font-black">{selectedHouse.email}</span>
                      </div>
                    )}
                  </div>
                </div>

                {/* Safety Warning */}
                <div className="bg-amber-50 border border-amber-200 rounded-3xl p-5 text-center shadow-inner">
                  <div className="flex items-center justify-center gap-2 mb-2">
                    <AlertTriangle className="w-4 h-4 text-amber-500" />
                    <p className="text-[10px] font-black text-amber-600 uppercase tracking-widest">Safety & Verification Note</p>
                  </div>
                  <p className="text-xs font-black text-gray-900 leading-tight">
                    DO NOT PROCEED TO MAKE PAYMENT WITHOUT VISITING THE EXACT PLACE.
                  </p>
                  <p className="text-[9px] text-gray-500 mt-2 font-medium">Verify utility meters and security before signing any agreement.</p>
                </div>

                {/* Status Footer */}
                <div className="flex items-center justify-center gap-2 py-4 border-t-2 border-dashed border-gray-100">
                  <div className={`w-2 h-2 rounded-full animate-pulse ${selectedHouse.availabilityStatus === 'AVAILABLE' ? 'bg-emerald-500' : 'bg-red-500'}`} />
                  <p className="text-[10px] font-black text-gray-400 uppercase tracking-widest">
                    Status: {selectedHouse.availabilityStatus} as of {new Date().toLocaleDateString()}
                  </p>
                </div>
              </div>

               {/* Action Bar */}
               <div className="p-6 bg-white border-t border-gray-100 flex gap-3">
                  <a 
                   href={`mailto:${selectedHouse.email}?subject=Inquiry about ${selectedHouse.title}`}
                   className="flex-1 bg-gray-900 text-white py-4 rounded-2xl font-black text-xs hover:bg-gray-800 transition-all flex items-center justify-center gap-2 shadow-lg text-center"
                  >
                    <Mail className="w-5 h-5" /> CONTACT VIA EMAIL
                  </a>
                  <a 
                    href={`tel:${selectedHouse.phone}`}
                    className="flex-1 bg-pink-500 text-gray-900 py-4 rounded-2xl font-black text-xs hover:bg-pink-600 transition-all flex items-center justify-center gap-2 shadow-lg text-center"
                  >
                    <Phone className="w-5 h-5" /> CALL LANDLORD
                  </a>
               </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}

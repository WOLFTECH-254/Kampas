
import { Wallet, Package, Heart, MapPin, Settings, HelpCircle, ArrowRight, Bell, LogOut, ShoppingCart, Trash2, Plus, Minus, RefreshCw, AlertTriangle, CreditCard, Smartphone, CheckCircle, Download, X, Home, Info, Store, Clock, Save } from 'lucide-react';
import { useEffect, useState } from 'react';
import { useAuth } from '../context/AuthContext';
import { GET, POST, PUT, DEL } from '../lib/api';
import { useNavigate, Link } from 'react-router-dom';
import WalletModal from '../components/WalletModal';
import Receipt from '../components/Receipt';
import { motion, AnimatePresence } from 'motion/react';

interface Order {
  id: string; status: string; total: number; createdAt: string; paymentMethod: string;
  items: { product: { name: string; images: string[] }; quantity: number; price: number }[];
}
interface WishlistItem {
  id: string; productId: string;
  product: { id: string; name: string; price: number; campus: string; images: string[]; seller: { name: string } };
}
interface CartItem {
  id: string; quantity: number; productId: string;
  product: { id: string; name: string; price: number; campus: string; images: string[]; stock: number };
}
interface CartData { id: string; items: CartItem[]; subtotal: number; deliveryFee: number; total: number; }

export default function BuyerDashboard() {
  const { user, logout, refresh } = useAuth();
  const navigate = useNavigate();

  const [wallet,        setWallet]        = useState({ balance: 0, transactions: [] as any[] });
  const [orders,        setOrders]        = useState<Order[]>([]);
  const [wishlist,      setWishlist]      = useState<WishlistItem[]>([]);
  const [cart,          setCart]          = useState<CartData | null>(null);
  const [unreadNotifs,  setUnreadNotifs]  = useState(0);
  const [activeTab,     setActiveTab]     = useState('orders');
  const [topupAmount,   setTopupAmount]   = useState('');
  const [topupLoading,  setTopupLoading]  = useState(false);
  const [topupMsg,      setTopupMsg]      = useState('');
  const [loading,       setLoading]       = useState(true);
  const [cartUpdating,  setCartUpdating]  = useState<string | null>(null);
  const [placingOrder,  setPlacingOrder]  = useState(false);
  const [orderMsg,      setOrderMsg]      = useState('');
  const [walletModal,   setWalletModal]   = useState(false);
  
  // Checkout States
  const [checkoutStep,  setCheckoutStep]  = useState<'WARNING' | 'ADDRESS' | 'PAYMENT'>('WARNING');
  const [showCheckout,  setShowCheckout]  = useState(false);
  const [shippingAddr,  setShippingAddr]  = useState('');
  const [payMethod,     setPayMethod]     = useState<'WALLET' | 'MPESA' | 'COD'>('WALLET');
  const [recentOrder,   setRecentOrder]   = useState<any | null>(null);
  const [buyNowProduct, setBuyNowProduct] = useState<any | null>(null);

  const [becomingSeller, setBecomingSeller] = useState(false);
  const [showApplyForm, setShowApplyForm] = useState(false);
  const [applyForm, setApplyForm] = useState({
    businessName: '',
    businessDescription: '',
    category: 'VARSITY_MERCH',
    campus: user?.campus || ''
  });
  const [verifying,       setVerifying]      = useState(false);
  const [profileForm,    setProfileForm]    = useState({
    name: user?.name || '',
    phone: user?.phone || '',
    campus: user?.campus || '',
    avatar: user?.avatar || ''
  });
  const [savingProfile,  setSavingProfile]  = useState(false);

  useEffect(() => { fetchAll(); }, []);

  useEffect(() => {
    const params = new URLSearchParams(window.location.search);
    const productId = params.get('buyNow');
    const checkout = params.get('checkout');
    
    if (productId && checkout === 'true') {
      // Fetch product details for Buy Now
      GET(`/api/products`).then(res => {
         const found = res.data.products.find((p: any) => p.id === productId);
         if (found) {
            setBuyNowProduct(found);
            setShowCheckout(true);
            setActiveTab('cart');
         }
      });
    }
  }, []);

  const fetchAll = async () => {
    setLoading(true);
    try {
      const [walletRes, ordersRes, wishlistRes, notifRes, cartRes] = await Promise.all([
        GET('/api/buyer/wallet'),
        GET('/api/buyer/orders'),
        GET('/api/buyer/wishlist'),
        GET('/api/buyer/notifications'),
        GET('/api/buyer/cart'),
      ]);
      setWallet(walletRes.data);
      setOrders(ordersRes.data.orders);
      setWishlist(wishlistRes.data.items);
      setUnreadNotifs(notifRes.data.unread);
      setCart(cartRes.data);
    } catch (err) { console.error(err); }
    finally { setLoading(false); }
  };

  const handleTopup = async () => {
    const amount = parseFloat(topupAmount);
    if (!amount || amount <= 0) return;
    setTopupLoading(true);
    try {
      const res = await POST('/api/buyer/wallet/topup', { amount });
      setTopupMsg(res.message);
      setTopupAmount('');
      await refresh();
      fetchAll();
      setTimeout(() => setTopupMsg(''), 3000);
    } catch (err: any) { setTopupMsg(err.message); }
    finally { setTopupLoading(false); }
  };

  const removeFromWishlist = async (productId: string) => {
    setWishlist(prev => prev.filter(i => i.productId !== productId));
    try { await DEL(`/api/buyer/wishlist/${productId}`); }
    catch { fetchAll(); }
  };

  const moveToCart = async (item: WishlistItem) => {
    try {
      await POST(`/api/buyer/cart/${item.productId}`, { quantity: 1 });
      await removeFromWishlist(item.productId);
      setActiveTab('cart');
      fetchAll();
    } catch (err: any) { alert(err.message); }
  };

  const updateCartQty = async (productId: string, quantity: number) => {
    if (quantity < 1) { removeFromCart(productId); return; }
    setCartUpdating(productId);
    try {
      await PUT(`/api/buyer/cart/${productId}`, { quantity });
      const res = await GET('/api/buyer/cart');
      setCart(res.data);
    } catch (err: any) { console.error(err); }
    finally { setCartUpdating(null); }
  };

  const removeFromCart = async (productId: string) => {
    setCartUpdating(productId);
    try {
      await DEL(`/api/buyer/cart/${productId}`);
      const res = await GET('/api/buyer/cart');
      setCart(res.data);
    } catch (err: any) { console.error(err); }
    finally { setCartUpdating(null); }
  };

  const placeOrderFromCart = async () => {
    const isBuyNow = !!buyNowProduct;
    const items = isBuyNow 
      ? [{ productId: buyNowProduct.id, quantity: 1 }]
      : (cart?.items.map(i => ({ productId: i.productId, quantity: i.quantity })) || []);
    
    const totalPrice = isBuyNow 
      ? (buyNowProduct.flashSalePrice || buyNowProduct.price) 
      : (cart?.total || 0);

    if (items.length === 0) return;
    
    // Validate balance if using wallet
    if (payMethod === 'WALLET' && (user?.walletBalance ?? 0) < totalPrice) {
      setOrderMsg('Insufficient wallet balance. Please top up first.'); 
      setCheckoutStep('PAYMENT');
      return;
    }

    if (!shippingAddr.trim()) {
      setOrderMsg('Please provide a shipping address');
      setCheckoutStep('ADDRESS');
      return;
    }

    setPlacingOrder(true);
    setOrderMsg('');
    try {
      const res = await POST('/api/buyer/orders', {
        items,
        paymentMethod: payMethod,
        shippingAddress: shippingAddr
      });
      
      setRecentOrder(res.data.order);
      setShowCheckout(false);
      setBuyNowProduct(null); // Clear buy now
      await refresh();
      fetchAll();
      setActiveTab('orders');
    } catch (err: any) { 
      setOrderMsg(err.message || 'Failed to place order'); 
    } finally { 
      setPlacingOrder(false); 
    }
  };

  const becomeSeller = () => {
    setShowApplyForm(true);
  };

  const submitApplication = async () => {
    if (!applyForm.businessName || !applyForm.businessDescription) {
      showToast('Please fill in all business details');
      return;
    }
    setBecomingSeller(true);
    try {
      await POST('/api/auth/become-seller', applyForm);
      showToast('Application sent to Admin! We will review your application.');
      setShowApplyForm(false);
      refresh();
      fetchAll();
    } catch (err: any) { 
      showToast(err.message, 'error'); 
    } finally { 
      setBecomingSeller(false); 
    }
  };

  const handleProfileSave = async () => {
    setSavingProfile(true);
    try {
      await PUT('/api/auth/update', profileForm);
      showToast('Profile updated!');
    } catch (err: any) { showToast(err.message, 'error'); }
    finally { setSavingProfile(false); }
  };

  const showToast = (msg: string, type: 'success' | 'error' = 'success') => {
    // Basic alert for now, can implement a better toast if needed
    alert(msg);
  };

  const statusColor = (s: string) => ({
    PENDING: 'bg-yellow-100 text-yellow-700', CONFIRMED: 'bg-blue-100 text-blue-700',
    PROCESSING: 'bg-blue-100 text-blue-700', OUT_FOR_DELIVERY: 'bg-pink-100 text-pink-600',
    DELIVERED: 'bg-green-100 text-green-700', CANCELLED: 'bg-red-100 text-red-600',
  }[s] || 'bg-gray-100 text-gray-600');

  const navItems = [
    { icon: Package,     label: 'My Orders',      tab: 'orders',       badge: orders.length },
    { icon: Heart,       label: 'Wishlist',        tab: 'wishlist',     badge: wishlist.length },
    { icon: ShoppingCart,label: 'Cart',            tab: 'cart',         badge: cart?.items.length || 0 },
    { icon: Wallet,      label: 'Transactions',    tab: 'transactions' },
    { icon: Settings,    label: 'Account Settings', tab: 'settings' },
    { icon: HelpCircle,  label: 'Help & Support',  tab: 'help' },
  ];

  return (
    <div className="p-4 md:p-8 max-w-5xl mx-auto">

      {/* Unique Receipt Modal */}
      {recentOrder && (
        <Receipt order={recentOrder} onClose={() => setRecentOrder(null)} />
      )}

      {/* Seller Application Form Modal */}
      <AnimatePresence>
        {showApplyForm && (
          <div className="fixed inset-0 bg-black/60 backdrop-blur-sm z-[200] flex items-center justify-center p-4">
            <motion.div 
              initial={{ opacity: 0, scale: 0.9, y: 20 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.9, y: 20 }}
              className="bg-white rounded-[2.5rem] w-full max-w-md overflow-hidden shadow-2xl border border-pink-50"
            >
              <div className="p-8">
                <div className="flex justify-between items-center mb-6">
                  <div>
                    <h3 className="text-2xl font-black text-gray-900 uppercase tracking-tighter italic">Seller Hub</h3>
                    <p className="text-xs text-gray-400 font-bold uppercase tracking-widest mt-1">Application Form</p>
                  </div>
                  <button onClick={() => setShowApplyForm(false)} className="p-2 hover:bg-pink-50 rounded-full transition-colors">
                    <X className="w-5 h-5 text-gray-400" />
                  </button>
                </div>

                <div className="space-y-5">
                  <div>
                    <label className="block text-[10px] font-black text-gray-400 uppercase tracking-widest mb-2 ml-1">Business Name *</label>
                    <input 
                      type="text" 
                      value={applyForm.businessName}
                      onChange={e => setApplyForm({...applyForm, businessName: e.target.value})}
                      placeholder="e.g. Campus Kicks Store"
                      className="w-full bg-pink-50 border border-pink-100 rounded-2xl py-4 px-5 text-sm focus:outline-none focus:border-pink-500 focus:ring-4 focus:ring-pink-500/10 transition-all font-medium"
                    />
                  </div>

                  <div>
                    <label className="block text-[10px] font-black text-gray-400 uppercase tracking-widest mb-2 ml-1">Business Campus *</label>
                    <select 
                      value={applyForm.campus}
                      onChange={e => setApplyForm({...applyForm, campus: e.target.value})}
                      className="w-full bg-pink-50 border border-pink-100 rounded-2xl py-4 px-5 text-sm focus:outline-none focus:border-pink-500 transition-all font-medium appearance-none"
                    >
                      <option value="UoN Main">UoN Main</option>
                      <option value="JKUAT Main">JKUAT Main</option>
                      <option value="KU Main">KU Main</option>
                      <option value="Strathmore">Strathmore University</option>
                      <option value="Daystar Valley">Daystar Valley Road</option>
                    </select>
                  </div>

                  <div>
                    <label className="block text-[10px] font-black text-gray-400 uppercase tracking-widest mb-2 ml-1">Primary Category *</label>
                    <select 
                      value={applyForm.category}
                      onChange={e => setApplyForm({...applyForm, category: e.target.value})}
                      className="w-full bg-pink-50 border border-pink-100 rounded-2xl py-4 px-5 text-sm focus:outline-none focus:border-pink-500 transition-all font-medium appearance-none"
                    >
                      <option value="VARSITY_MERCH">Varsity Merch</option>
                      <option value="ELECTRONICS">Tech & Gadgets</option>
                      <option value="FASHION">Fashion & Drip</option>
                      <option value="SERVICES">Campus Services</option>
                      <option value="FOOD">Food & Snacks</option>
                    </select>
                  </div>

                  <div>
                    <label className="block text-[10px] font-black text-gray-400 uppercase tracking-widest mb-2 ml-1">Business Description *</label>
                    <textarea 
                      rows={3}
                      value={applyForm.businessDescription}
                      onChange={e => setApplyForm({...applyForm, businessDescription: e.target.value})}
                      placeholder="Tell us what you plan to sell and why students would love it..."
                      className="w-full bg-pink-50 border border-pink-100 rounded-2xl py-4 px-5 text-sm focus:outline-none focus:border-pink-500 transition-all font-medium resize-none"
                    ></textarea>
                  </div>

                  <button 
                    onClick={submitApplication}
                    disabled={becomingSeller}
                    className="w-full bg-gray-900 text-white py-4 rounded-2xl font-black text-xs uppercase tracking-widest hover:bg-pink-500 transition-all shadow-xl shadow-pink-100 disabled:opacity-50 mt-4 flex items-center justify-center gap-2"
                  >
                    {becomingSeller ? <RefreshCw className="w-4 h-4 animate-spin" /> : 'Submit Application'}
                  </button>
                  <p className="text-[10px] text-gray-400 text-center font-bold px-4">
                    By submitting, you agree to Kampas's Seller Terms & Conditions.
                  </p>
                </div>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* Checkout Selection Modal */}
      <AnimatePresence>
        {showCheckout && (
          <div className="fixed inset-0 z-[150] bg-gray-900/80 backdrop-blur-sm flex items-center justify-center p-4">
            <motion.div 
               initial={{ y: 50, opacity: 0 }} 
               animate={{ y: 0, opacity: 1 }} 
               exit={{ y: 50, opacity: 0 }}
               className="w-full max-w-md bg-white rounded-[2rem] shadow-2xl overflow-hidden flex flex-col"
            >
               <div className="p-6 border-b border-pink-50 flex items-center justify-between">
                  <h3 className="font-black text-gray-900 uppercase tracking-tight">KAMPAS CHECKOUT</h3>
                  <button onClick={() => { setShowCheckout(false); setBuyNowProduct(null); }} className="p-2 hover:bg-pink-50 rounded-full text-gray-400">
                    <X className="w-5 h-5" />
                  </button>
               </div>

               <div className="p-6 flex-1">
                  {/* Step Indicators */}
                  <div className="flex gap-2 mb-8">
                     {['WARNING', 'ADDRESS', 'PAYMENT'].map((s, i) => (
                        <div key={s} className={`h-1.5 flex-1 rounded-full ${
                          ['WARNING', 'ADDRESS', 'PAYMENT'].indexOf(checkoutStep) >= i ? 'bg-pink-500' : 'bg-pink-100'
                        }`} />
                     ))}
                  </div>

                  {checkoutStep === 'WARNING' && (
                    <div className="space-y-6 text-center">
                       <div className="w-20 h-20 bg-orange-50 text-orange-500 rounded-full flex items-center justify-center mx-auto shadow-inner border-2 border-orange-100">
                          <AlertTriangle className="w-10 h-10 animate-pulse" />
                       </div>
                       <div className="space-y-2">
                          <h4 className="text-xl font-black text-gray-900">TRUST VERIFICATION</h4>
                          <p className="text-sm text-gray-500 leading-relaxed">
                            Before proceeding, please ensure you **trust this business**. Have you bought from this seller before or verified their campus presence? 
                          </p>
                          <div className="bg-orange-50 p-4 rounded-2xl border border-orange-100 mt-4">
                             <p className="text-[10px] text-orange-700 font-bold uppercase leading-tight italic">
                               If unsure, please select "Pay on Delivery" in the next steps to ensure item quality before payment.
                             </p>
                          </div>
                       </div>
                       <button 
                         onClick={() => setCheckoutStep('ADDRESS')} 
                         className="w-full bg-gray-900 text-white py-4 rounded-2xl font-black text-xs uppercase tracking-widest hover:bg-pink-500 transition-all shadow-xl"
                       >
                         I Trust the Seller
                       </button>
                    </div>
                  )}

                  {checkoutStep === 'ADDRESS' && (
                    <div className="space-y-6">
                       <div className="flex items-center gap-3 mb-2">
                          <Home className="w-5 h-5 text-pink-500" />
                          <h4 className="text-lg font-black text-gray-900 uppercase tracking-tight">Delivery Address</h4>
                       </div>
                       <textarea 
                         value={shippingAddr}
                         onChange={(e) => setShippingAddr(e.target.value)}
                         placeholder="Specific Hostel, Gate, or Campus Landmark..."
                         className="w-full bg-pink-50 border border-pink-200 rounded-2xl p-4 text-sm focus:outline-none focus:border-pink-500 min-h-[120px]"
                       />
                       <div className="flex gap-3">
                          <button onClick={() => setCheckoutStep('WARNING')} className="flex-1 py-4 border border-gray-100 rounded-2xl text-[10px] font-black uppercase tracking-widest hover:bg-gray-50">Back</button>
                          <button onClick={() => setCheckoutStep('PAYMENT')} disabled={!shippingAddr.trim()} className="flex-[2] bg-gray-900 text-white py-4 rounded-2xl font-black text-[10px] uppercase tracking-widest hover:bg-pink-500 transition-all shadow-xl disabled:opacity-50">Continue</button>
                       </div>
                    </div>
                  )}

                  {checkoutStep === 'PAYMENT' && (
                    <div className="space-y-6">
                       <div className="flex items-center gap-3 mb-2">
                          <CreditCard className="w-5 h-5 text-pink-500" />
                          <h4 className="text-lg font-black text-gray-900 uppercase tracking-tight">Select Method</h4>
                       </div>
                       
                       <div className="grid gap-3">
                          <button 
                            onClick={() => setPayMethod('WALLET')} 
                            className={`p-4 rounded-2xl border-2 text-left transition-all ${payMethod === 'WALLET' ? 'border-pink-500 bg-pink-50' : 'border-gray-50'}`}
                          >
                             <div className="flex items-center justify-between font-bold text-xs mb-1">
                                <span>Kampas Wallet</span>
                                {payMethod === 'WALLET' && <CheckCircle className="w-4 h-4 text-pink-500" />}
                             </div>
                             <p className="text-[10px] text-gray-400">Fast checkout with available balance</p>
                          </button>

                          <button 
                            onClick={() => setPayMethod('MPESA')} 
                            className={`p-4 rounded-2xl border-2 text-left transition-all ${payMethod === 'MPESA' ? 'border-green-500 bg-green-50' : 'border-gray-50'}`}
                          >
                             <div className="flex items-center justify-between font-bold text-xs mb-1">
                                <span className="flex items-center gap-2"><Smartphone className="w-4 h-4" /> M-Pesa Instant</span>
                                {payMethod === 'MPESA' && <CheckCircle className="w-4 h-4 text-green-500" />}
                             </div>
                             <p className="text-[10px] text-gray-400">Pay via STK Push directly</p>
                          </button>

                          <button 
                            onClick={() => setPayMethod('COD')} 
                            className={`p-4 rounded-2xl border-2 text-left transition-all ${payMethod === 'COD' ? 'border-orange-500 bg-orange-50' : 'border-gray-50'}`}
                          >
                             <div className="flex items-center justify-between font-bold text-xs mb-1">
                                <span className="flex items-center gap-2"><Package className="w-4 h-4" /> Pay on Delivery</span>
                                {payMethod === 'COD' && <CheckCircle className="w-4 h-4 text-orange-500" />}
                             </div>
                             <p className="text-[10px] text-gray-400">Inspect before you pay</p>
                          </button>
                       </div>

                       {orderMsg && <p className="text-xs text-red-500 bg-red-50 p-3 rounded-xl border border-red-100">{orderMsg}</p>}

                       <div className="flex gap-3">
                          <button onClick={() => setCheckoutStep('ADDRESS')} className="flex-1 py-4 border border-gray-100 rounded-2xl text-[10px] font-black uppercase tracking-widest hover:bg-gray-50">Back</button>
                          <button onClick={placeOrderFromCart} disabled={placingOrder} className="flex-[2] bg-pink-500 text-white py-4 rounded-2xl font-black text-[10px] uppercase tracking-widest hover:bg-pink-600 transition-all shadow-xl disabled:opacity-50 flex items-center justify-center gap-2">
                            {placingOrder ? <RefreshCw className="w-4 h-4 animate-spin" /> : 'Confirm Order'}
                          </button>
                       </div>
                    </div>
                  )}
               </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* Profile Header */}
      <div className="flex flex-col md:flex-row items-center md:items-start gap-6 bg-pink-50 border border-pink-200 p-6 rounded-3xl mb-8 relative overflow-hidden">
        <div className="absolute top-0 right-0 w-32 h-32 bg-pink-500/10 rounded-full blur-[50px]"></div>
        <div className="w-24 h-24 rounded-2xl overflow-hidden border-2 border-pink-500 flex-shrink-0 bg-white">
          <img src={user?.avatar || `https://api.dicebear.com/7.x/avataaars/svg?seed=${user?.name}`} alt="Profile" className="w-full h-full object-cover" />
        </div>
        <div className="flex-1 text-center md:text-left z-10">
          <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
            <div>
              <div className="flex items-center gap-2 justify-center md:justify-start">
                <h1 className="text-2xl font-bold">{user?.name || 'Loading...'}</h1>
                {user?.isVerified
                  ? <span className="text-xs bg-green-100 text-green-700 px-2 py-0.5 rounded-full font-semibold">✓ Verified</span>
                  : <span className="text-xs bg-yellow-100 text-yellow-700 px-2 py-0.5 rounded-full font-semibold">Unverified</span>
                }
              </div>
              <p className="text-gray-500 text-sm mb-1 flex items-center justify-center md:justify-start gap-1">
                <MapPin className="w-3 h-3 text-pink-500" /> {user?.campus || 'No campus set'}
              </p>
              <p className="text-xs text-gray-400">{user?.email}</p>
            </div>
            <div className="flex items-center gap-2">
              {unreadNotifs > 0 && (
                <div className="relative">
                  <Bell className="w-5 h-5 text-pink-500" />
                  <span className="absolute -top-1 -right-1 w-4 h-4 bg-pink-500 rounded-full text-white text-[10px] flex items-center justify-center">{unreadNotifs}</span>
                </div>
              )}
              <Link to="/profile" className="bg-white border border-pink-200 text-gray-900 text-sm font-semibold px-4 py-2 rounded-xl hover:text-pink-600 transition-colors">
                Edit Profile
              </Link>
              <button onClick={logout} className="bg-white border border-pink-200 text-gray-400 p-2 rounded-xl hover:text-red-500 transition-colors">
                <LogOut className="w-4 h-4" />
              </button>
            </div>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        {/* Sidebar */}
        <div className="space-y-4">

          {/* Wallet */}
          <div className="bg-gradient-to-br from-pink-50 to-white border border-pink-200 p-5 rounded-2xl">
            <h3 className="text-gray-500 text-xs font-semibold mb-1">Kampas Wallet</h3>
            <p className="text-2xl font-bold mb-4">KSH {(user?.walletBalance ?? 0).toLocaleString()}</p>
            <button onClick={() => setWalletModal(true)}
              className="w-full bg-green-500 text-white text-xs font-bold py-2.5 rounded-xl hover:bg-green-600 transition-colors flex items-center justify-center gap-2">
              📱 Top Up via M-Pesa
            </button>
          </div>
          <WalletModal open={walletModal} onClose={() => setWalletModal(false)} onSuccess={() => { fetchAll(); }} />

          {/* Become a Seller Prompt */}
          {user?.role === 'BUYER' && !user?.sellerRequestPending && (
             <div className="bg-gradient-to-br from-indigo-500 to-purple-600 p-6 rounded-3xl text-white shadow-xl shadow-indigo-200">
               <div className="flex items-center gap-3 mb-2">
                 <Store className="w-5 h-5" />
                 <h4 className="font-black text-sm uppercase tracking-widest">Start Selling</h4>
               </div>
               <p className="text-xs text-indigo-50/80 mb-4 leading-relaxed">List your products and services to thousands of students on campus.</p>
               <button 
                 onClick={becomeSeller}
                 disabled={becomingSeller}
                 className="w-full bg-white text-indigo-600 py-3 rounded-xl font-bold text-xs hover:bg-indigo-50 transition-all flex items-center justify-center gap-2"
               >
                 {becomingSeller ? <RefreshCw className="w-4 h-4 animate-spin" /> : 'Apply to be a Seller'}
               </button>
             </div>
          )}
          {user?.sellerRequestPending && (
             <div className="bg-orange-50 border border-orange-100 p-6 rounded-3xl">
                <p className="text-xs font-bold text-orange-700 flex items-center gap-2">
                  <Clock className="w-4 h-4" /> Application Under Review
                </p>
                <p className="text-[10px] text-orange-600 mt-1">We are verifying your seller profile. This usually takes 24h.</p>
             </div>
          )}

          {/* Nav */}
          <div className="bg-pink-50 border border-pink-200 rounded-2xl overflow-hidden">
            {navItems.map(item => (
              <button key={item.tab} onClick={() => setActiveTab(item.tab)}
                className={`w-full flex items-center justify-between p-4 border-b border-pink-100 last:border-0 hover:bg-white transition-colors ${activeTab === item.tab ? 'bg-white border-l-2 border-l-pink-500' : ''}`}>
                <div className="flex items-center gap-3">
                  <item.icon className={`w-5 h-5 ${activeTab === item.tab ? 'text-pink-500' : 'text-gray-500'}`} />
                  <span className={`text-sm font-medium ${activeTab === item.tab ? 'text-gray-900' : 'text-gray-600'}`}>{item.label}</span>
                </div>
                {item.badge != null && item.badge > 0 && (
                  <span className="bg-pink-100 text-pink-600 text-xs px-2 py-0.5 rounded-full font-bold">{item.badge}</span>
                )}
              </button>
            ))}
          </div>
        </div>

        {/* Main Content */}
        <div className="md:col-span-2 space-y-4">

          {/* ── ORDERS ── */}
          {activeTab === 'orders' && (
            <>
              <h2 className="text-lg font-bold">My Orders</h2>
              {loading ? <div className="text-center py-10 text-gray-400">Loading...</div> :
               orders.length === 0 ? (
                <div className="bg-pink-50 border border-pink-200 rounded-2xl p-10 text-center">
                  <Package className="w-10 h-10 text-pink-200 mx-auto mb-3" />
                  <p className="text-gray-500 text-sm">No orders yet.</p>
                  <button onClick={() => navigate('/explore')} className="mt-4 bg-pink-500 text-white text-sm font-bold px-6 py-2 rounded-xl hover:bg-pink-600 transition-colors">
                    Browse Products
                  </button>
                </div>
              ) : orders.map(order => (
                <div key={order.id} className="bg-pink-50 border border-pink-200 rounded-2xl p-5">
                  <div className="flex items-center justify-between mb-3 pb-3 border-b border-pink-100">
                    <div className="flex items-center gap-2">
                      <span className="font-semibold text-pink-600 text-sm">#{order.id.slice(-6).toUpperCase()}</span>
                      <span className={`text-xs px-2 py-0.5 rounded-full font-medium ${statusColor(order.status)}`}>{order.status.replace(/_/g,' ')}</span>
                    </div>
                    <span className="text-xs text-gray-400">{new Date(order.createdAt).toLocaleDateString()}</span>
                  </div>
                  {order.items.map((item, i) => (
                    <div key={i} className="flex items-center gap-3 mb-2">
                      <div className="w-12 h-12 rounded-xl overflow-hidden bg-white flex-shrink-0 border border-pink-100">
                        {item.product.images?.[0]
                          ? <img src={item.product.images[0]} className="w-full h-full object-cover" />
                          : <div className="w-full h-full bg-pink-100" />}
                      </div>
                      <div className="flex-1 min-w-0">
                        <p className="font-semibold text-sm truncate">{item.product.name}</p>
                        <p className="text-xs text-gray-500">Qty: {item.quantity} · KSH {item.price.toLocaleString()}</p>
                      </div>
                    </div>
                  ))}
                  <div className="flex items-center justify-between pt-3 border-t border-pink-100 mt-2">
                    <div className="flex flex-col">
                       <span className="text-sm font-bold">Total: KSH {order.total.toLocaleString()}</span>
                       <span className="text-[9px] font-black text-gray-400 uppercase tracking-widest">{order.paymentMethod === 'COD' ? 'Pay on Delivery' : 'Instant Payment'}</span>
                    </div>
                    <button 
                      onClick={() => setRecentOrder(order)}
                      className="bg-white border border-pink-200 text-pink-500 px-4 py-2 rounded-xl text-[10px] font-black uppercase tracking-widest hover:bg-pink-50 transition-all flex items-center gap-2"
                    >
                      <Download className="w-3 h-3" /> View Receipt
                    </button>
                  </div>
                </div>
              ))}
            </>
          )}

          {/* ── WISHLIST ── */}
          {activeTab === 'wishlist' && (
            <>
              <div className="flex items-center justify-between">
                <h2 className="text-lg font-bold">My Wishlist</h2>
                <span className="text-sm text-gray-400">{wishlist.length} items</span>
              </div>
              {loading ? <div className="text-center py-10 text-gray-400">Loading...</div> :
               wishlist.length === 0 ? (
                <div className="bg-pink-50 border border-pink-200 rounded-2xl p-10 text-center">
                  <Heart className="w-10 h-10 text-pink-200 mx-auto mb-3" />
                  <p className="text-gray-500 text-sm">Your wishlist is empty.</p>
                  <button onClick={() => navigate('/explore')} className="mt-4 bg-pink-500 text-white text-sm font-bold px-6 py-2 rounded-xl hover:bg-pink-600 transition-colors">
                    Explore Products
                  </button>
                </div>
              ) : (
                <div className="space-y-3">
                  {wishlist.map(item => (
                    <div key={item.id} className="bg-pink-50 border border-pink-200 rounded-2xl p-4 flex items-center gap-4">
                      <div className="w-16 h-16 rounded-xl overflow-hidden bg-white flex-shrink-0 border border-pink-100">
                        {item.product.images?.[0]
                          ? <img src={item.product.images[0]} className="w-full h-full object-cover" />
                          : <div className="w-full h-full bg-pink-100" />}
                      </div>
                      <div className="flex-1 min-w-0">
                        <p className="font-semibold text-sm truncate">{item.product.name}</p>
                        <p className="text-xs text-gray-500 flex items-center gap-1 mt-0.5">
                          <MapPin className="w-3 h-3 text-pink-400" />{item.product.campus}
                        </p>
                        <p className="font-bold text-pink-500 text-sm mt-1">KSH {item.product.price.toLocaleString()}</p>
                      </div>
                      <div className="flex flex-col gap-2 flex-shrink-0">
                        <button onClick={() => moveToCart(item)}
                          className="bg-pink-500 text-white text-xs font-bold px-3 py-1.5 rounded-lg hover:bg-pink-600 transition-colors flex items-center gap-1">
                          <ShoppingCart className="w-3 h-3" /> Add to Cart
                        </button>
                        <button onClick={() => removeFromWishlist(item.productId)}
                          className="bg-white border border-pink-200 text-red-400 text-xs font-bold px-3 py-1.5 rounded-lg hover:bg-red-50 transition-colors flex items-center gap-1">
                          <Trash2 className="w-3 h-3" /> Remove
                        </button>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </>
          )}

          {/* ── CART ── */}
          {activeTab === 'cart' && (
            <>
              <div className="flex items-center justify-between">
                <h2 className="text-lg font-bold">My Cart</h2>
                <span className="text-sm text-gray-400">{cart?.items.length || 0} items</span>
              </div>

              {loading ? <div className="text-center py-10 text-gray-400">Loading...</div> :
               !cart || cart.items.length === 0 ? (
                <div className="bg-pink-50 border border-pink-200 rounded-2xl p-10 text-center">
                  <ShoppingCart className="w-10 h-10 text-pink-200 mx-auto mb-3" />
                  <p className="text-gray-500 text-sm">Your cart is empty.</p>
                  <button onClick={() => navigate('/explore')} className="mt-4 bg-pink-500 text-white text-sm font-bold px-6 py-2 rounded-xl hover:bg-pink-600 transition-colors">
                    Start Shopping
                  </button>
                </div>
              ) : (
                <>
                  <div className="space-y-3">
                    {cart.items.map(item => (
                      <div key={item.id} className="bg-pink-50 border border-pink-200 rounded-2xl p-4 flex items-center gap-4">
                        <div className="w-16 h-16 rounded-xl overflow-hidden bg-white flex-shrink-0 border border-pink-100">
                          {item.product.images?.[0]
                            ? <img src={item.product.images[0]} className="w-full h-full object-cover" />
                            : <div className="w-full h-full bg-pink-100" />}
                        </div>
                        <div className="flex-1 min-w-0">
                          <p className="font-semibold text-sm truncate">{item.product.name}</p>
                          <p className="font-bold text-pink-500 text-sm mt-0.5">KSH {item.product.price.toLocaleString()}</p>
                        </div>
                        <div className="flex items-center gap-2 flex-shrink-0">
                          <button onClick={() => updateCartQty(item.productId, item.quantity - 1)}
                            disabled={cartUpdating === item.productId}
                            className="w-7 h-7 rounded-lg bg-white border border-pink-200 flex items-center justify-center hover:bg-pink-100 transition-colors disabled:opacity-50">
                            <Minus className="w-3 h-3" />
                          </button>
                          <span className="w-6 text-center text-sm font-bold">
                            {cartUpdating === item.productId ? <RefreshCw className="w-3 h-3 animate-spin mx-auto" /> : item.quantity}
                          </span>
                          <button onClick={() => updateCartQty(item.productId, item.quantity + 1)}
                            disabled={cartUpdating === item.productId || item.quantity >= item.product.stock}
                            className="w-7 h-7 rounded-lg bg-white border border-pink-200 flex items-center justify-center hover:bg-pink-100 transition-colors disabled:opacity-50">
                            <Plus className="w-3 h-3" />
                          </button>
                          <button onClick={() => removeFromCart(item.productId)}
                            disabled={cartUpdating === item.productId}
                            className="w-7 h-7 rounded-lg bg-white border border-red-200 text-red-400 flex items-center justify-center hover:bg-red-50 transition-colors ml-1 disabled:opacity-50">
                            <Trash2 className="w-3 h-3" />
                          </button>
                        </div>
                      </div>
                    ))}
                  </div>

                  {/* Order summary */}
                  <div className="bg-pink-50 border border-pink-200 rounded-2xl p-5 mt-2">
                    <div className="flex items-center justify-between mb-4">
                      <h3 className="font-bold">{buyNowProduct ? 'Buy Now Summary' : 'Order Summary'}</h3>
                      {buyNowProduct && (
                        <button onClick={() => setBuyNowProduct(null)} className="text-[10px] font-black text-pink-500 uppercase tracking-widest hover:underline">
                          Cancel Buy Now
                        </button>
                      )}
                    </div>
                    <div className="space-y-2 text-sm mb-4">
                      {buyNowProduct ? (
                        <>
                          <div className="flex justify-between text-gray-600">
                            <span className="truncate max-w-[200px]">{buyNowProduct.name}</span>
                            <span>KSH {(buyNowProduct.flashSalePrice || buyNowProduct.price).toLocaleString()}</span>
                          </div>
                          <div className="flex justify-between font-bold text-gray-900 pt-2 border-t border-pink-200">
                            <span>Total</span>
                            <span>KSH {(buyNowProduct.flashSalePrice || buyNowProduct.price).toLocaleString()}</span>
                          </div>
                        </>
                      ) : (
                        <>
                          <div className="flex justify-between text-gray-600">
                            <span>Subtotal</span>
                            <span>KSH {cart.subtotal.toLocaleString()}</span>
                          </div>
                          <div className="flex justify-between text-gray-600">
                            <span>Delivery Fee</span>
                            <span>KSH {cart.deliveryFee.toLocaleString()}</span>
                          </div>
                          <div className="flex justify-between font-bold text-gray-900 pt-2 border-t border-pink-200">
                            <span>Total</span>
                            <span>KSH {cart.total.toLocaleString()}</span>
                          </div>
                        </>
                      )}
                      <div className="flex justify-between text-xs text-gray-400">
                        <span>Wallet Balance</span>
                        <span className={(user?.walletBalance ?? 0) >= (buyNowProduct ? (buyNowProduct.flashSalePrice || buyNowProduct.price) : (cart?.total || 0)) ? 'text-green-600 font-medium' : 'text-red-500 font-medium'}>
                          KSH {(user?.walletBalance ?? 0).toLocaleString()}
                        </span>
                      </div>
                    </div>

                    {orderMsg && (
                      <p className="text-xs text-red-500 mb-3 bg-red-50 border border-red-200 rounded-lg p-2">{orderMsg}</p>
                    )}

                    {(user?.walletBalance ?? 0) < (buyNowProduct ? (buyNowProduct.flashSalePrice || buyNowProduct.price) : (cart?.total || 0)) && (
                      <p className="text-xs text-orange-600 mb-3 bg-orange-50 border border-orange-200 rounded-lg p-2 flex items-center gap-2">
                        <AlertTriangle className="w-4 h-4" />
                        Insufficient balance. Other methods available at checkout.
                      </p>
                    )}

                    <button onClick={() => setShowCheckout(true)} disabled={!buyNowProduct && cart?.items.length === 0}
                      className="w-full bg-pink-500 text-white font-black text-xs uppercase tracking-widest py-4 rounded-2xl hover:bg-pink-600 transition-all shadow-xl flex items-center justify-center gap-2 disabled:opacity-60 disabled:cursor-not-allowed">
                      <ShoppingCart className="w-4 h-4" /> 
                      {buyNowProduct 
                        ? `Complete Purchase · KSH ${(buyNowProduct.flashSalePrice || buyNowProduct.price).toLocaleString()}` 
                        : `Proceed to Checkout · KSH ${cart?.total.toLocaleString()}`
                      }
                    </button>
                  </div>
                </>
              )}
            </>
          )}

          {/* ── TRANSACTIONS ── */}
          {activeTab === 'transactions' && (
            <>
              <h2 className="text-lg font-bold">Wallet Transactions</h2>
              {wallet.transactions.length === 0 ? (
                <div className="bg-pink-50 border border-pink-200 rounded-2xl p-10 text-center">
                  <Wallet className="w-10 h-10 text-pink-200 mx-auto mb-3" />
                  <p className="text-gray-500 text-sm">No transactions yet.</p>
                </div>
              ) : (
                <div className="bg-pink-50 border border-pink-200 rounded-2xl overflow-hidden">
                  {wallet.transactions.map((tx: any) => (
                    <div key={tx.id} className="flex items-center justify-between p-4 border-b border-pink-100 last:border-0">
                      <div>
                        <p className="text-sm font-semibold">{tx.description || tx.type}</p>
                        <p className="text-xs text-gray-400">{new Date(tx.createdAt).toLocaleDateString()}</p>
                      </div>
                      <span className={`font-bold text-sm ${tx.amount > 0 ? 'text-green-600' : 'text-red-500'}`}>
                        {tx.amount > 0 ? '+' : ''}KSH {Math.abs(tx.amount).toLocaleString()}
                      </span>
                    </div>
                  ))}
                </div>
              )}
            </>
          )}

          {/* ── SETTINGS ── */}
          {activeTab === 'settings' && (
            <div className="space-y-6">
               <h2 className="text-lg font-bold">Account Settings</h2>
               <div className="bg-pink-50 border border-pink-100 p-6 rounded-3xl space-y-4">
                  <div>
                    <label className="text-[10px] font-black text-gray-400 uppercase tracking-widest mb-1.5 block">Full Name</label>
                    <input 
                      value={profileForm.name} 
                      onChange={e => setProfileForm({...profileForm, name: e.target.value})}
                      className="w-full bg-white border border-pink-200 rounded-2xl py-3 px-4 text-sm focus:outline-none focus:border-pink-500" 
                    />
                  </div>
                  <div>
                    <label className="text-[10px] font-black text-gray-400 uppercase tracking-widest mb-1.5 block">Phone Number</label>
                    <input 
                      value={profileForm.phone} 
                      onChange={e => setProfileForm({...profileForm, phone: e.target.value})}
                      className="w-full bg-white border border-pink-200 rounded-2xl py-3 px-4 text-sm focus:outline-none focus:border-pink-500" 
                    />
                  </div>
                  <div>
                    <label className="text-[10px] font-black text-gray-400 uppercase tracking-widest mb-1.5 block">Campus</label>
                    <input 
                      value={profileForm.campus} 
                      onChange={e => setProfileForm({...profileForm, campus: e.target.value})}
                      className="w-full bg-white border border-pink-200 rounded-2xl py-3 px-4 text-sm focus:outline-none focus:border-pink-500" 
                    />
                  </div>
                  <button 
                    onClick={handleProfileSave}
                    disabled={savingProfile}
                    className="w-full bg-gray-900 text-white font-black py-4 rounded-2xl flex items-center justify-center gap-2 hover:bg-pink-600 transition-all uppercase tracking-widest disabled:opacity-50"
                  >
                    {savingProfile ? <RefreshCw className="w-5 h-5 animate-spin"/> : <Save className="w-5 h-5" />}
                    Save Changes
                  </button>
               </div>
            </div>
          )}

          {/* ── OTHER TABS ── */}
          {!['orders','wishlist','cart','transactions','settings'].includes(activeTab) && (
            <div className="bg-pink-50 border border-pink-200 rounded-2xl p-10 text-center">
              <Settings className="w-10 h-10 text-pink-200 mx-auto mb-3" />
              <p className="text-gray-400 text-sm capitalize">{activeTab} — coming soon</p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}

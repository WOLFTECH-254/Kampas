import React, { useState, useEffect, useCallback } from 'react';
import { MapPin, Heart, ShoppingCart, Search, Star, Package, X, ChevronDown, SlidersHorizontal, Navigation, Map as MapIcon, CheckCircle, TrendingUp, Store as StoreIcon, Hammer, Zap, ArrowRight, UserCheck, Sparkles, RefreshCw, Calendar } from 'lucide-react';
import { useAuth } from '../context/AuthContext';
import { useLocation } from '../context/LocationContext';
import { GET, POST, DEL } from '../lib/api';
import { motion, AnimatePresence } from 'motion/react';
import { getAiRecommendations, Recommendation } from '../lib/recommendations';
import FlashSaleStories from '../components/Explore/FlashSaleStories';
import Receipt from '../components/Receipt';
import { Product } from '../types';

const CATEGORIES = [
  { label: 'All',             slug: '',              icon: '🛍️' },
  { label: 'Trending',        slug: 'trending',      icon: '🔥' },
  { label: 'Sneakers & Drip', slug: 'sneakers-drip', icon: '👟' },
  { label: 'Tech & Gadgets',  slug: 'tech-gadgets',  icon: '💻' },
  { label: 'Services',        slug: 'services',      icon: '🛠️' },
  { label: 'Textbooks',       slug: 'textbooks',     icon: '📚' },
  { label: 'Fashion',         slug: 'fashion',       icon: '👕' },
];

const CONDITION_STYLES: Record<string, string> = {
  NEW:           'bg-green-100 text-green-700',
  SLIGHTLY_USED: 'bg-blue-100 text-blue-700',
  USED:          'bg-yellow-100 text-yellow-700',
  THRIFTED:      'bg-purple-100 text-purple-700',
};

const CONDITION_LABEL: Record<string, string> = {
  NEW: 'New', SLIGHTLY_USED: 'S.Used', USED: 'Used', THRIFTED: 'Thrifted',
};

export default function Marketplace() {
  const { user } = useAuth();
  const { location, formatDistance } = useLocation();

  const [products,     setProducts]     = useState<Product[]>([]);
  const [flashSales,   setFlashSales]   = useState<Product[]>([]);
  const [trending,     setTrending]     = useState<{products: Product[], sellers: any[], services: any[], stores: any[]}>({
    products: [], sellers: [], services: [], stores: []
  });
  
  const [loading,      setLoading]      = useState(true);
  const [activeFilter, setActiveFilter] = useState('');
  const [search,       setSearch]       = useState('');
  const [searchInput,  setSearchInput]  = useState('');
  const [searchType,   setSearchType]   = useState<'products' | 'services' | 'sellers' | 'stores'>('products');
  const [sort,         setSort]         = useState('createdAt');

  const [wishlist,    setWishlist]    = useState<Set<string>>(new Set());
  const [cartItems,   setCartItems]   = useState<Set<string>>(new Set());
  const [aiRecs,      setAiRecs]      = useState<Recommendation[]>([]);

  const [bookingService, setBookingService] = useState<any>(null);
  const [bookingDate,    setBookingDate]    = useState('');
  const [bookingLoading, setBookingLoading] = useState(false);
  const [bookingSuccess, setBookingSuccess] = useState<any | null>(null);

  const fetchExploreData = useCallback(async () => {
    setLoading(true);
    try {
      const [prodRes, flashRes, trendRes, recs] = await Promise.all([
        GET(`/api/products?limit=20&sort=${sort}${activeFilter ? `&category=${activeFilter}` : ''}${search ? `&q=${search}` : ''}`),
        GET('/api/products/flash-sales'),
        GET('/api/explore/trending'),
        getAiRecommendations({ location, category: 'MARKETPLACE' })
      ]);
      
      setProducts(prodRes.data.products);
      setFlashSales(flashRes.data.sales || []);
      setAiRecs(recs);
      setTrending(trendRes.data || { products: [], sellers: [], services: [], stores: [] });
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  }, [activeFilter, search, sort, location]);

  useEffect(() => { fetchExploreData(); }, [fetchExploreData]);

  // Search debouncing
  useEffect(() => {
    const t = setTimeout(() => setSearch(searchInput), 500);
    return () => clearTimeout(t);
  }, [searchInput]);

  const handleBookService = async () => {
    if (!bookingService || !bookingDate) return;
    setBookingLoading(true);
    try {
      const res = await POST(`/api/buyer/orders`, {
        items: [{ productId: bookingService.id, quantity: 1, isService: true }],
        paymentMethod: 'WALLET',
        appointmentDate: bookingDate,
        shippingAddress: 'Service Appointment at Seller Location'
      });
      setBookingSuccess(res.data.order);
      setBookingService(null);
    } catch (err: any) {
      alert(err.message || 'Booking failed');
    } finally {
      setBookingLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-white pb-20">
      
      {/* ── RECEIPT MODAL AT TOP ── */}
      {bookingSuccess && (
        <Receipt order={bookingSuccess} onClose={() => setBookingSuccess(null)} />
      )}

      {/* ── BOOKING MODAL ── */}
      {bookingService && (
        <div className="fixed inset-0 z-[100] bg-black/60 backdrop-blur-sm flex items-center justify-center p-4" onClick={() => setBookingService(null)}>
           <motion.div initial={{ scale: 0.9, opacity: 0 }} animate={{ scale: 1, opacity: 1 }} className="bg-white rounded-[2.5rem] w-full max-w-md overflow-hidden" onClick={e => e.stopPropagation()}>
              <div className="p-8 bg-pink-500 text-white">
                 <h3 className="text-2xl font-black uppercase tracking-tight">Book Service</h3>
                 <p className="text-white/80 text-xs font-bold uppercase tracking-widest mt-1">Schedule your appointment</p>
              </div>
              <div className="p-8 space-y-6">
                 <div>
                    <label className="text-[10px] font-black text-gray-400 uppercase tracking-widest mb-2 block">Service</label>
                    <p className="text-lg font-black text-gray-900">{bookingService.name}</p>
                    <p className="text-xs text-pink-500 font-bold">KSH {bookingService.price.toLocaleString()}</p>
                 </div>
                 <div>
                    <label className="text-[10px] font-black text-gray-400 uppercase tracking-widest mb-2 block">Select Date & Time</label>
                    <input type="datetime-local" value={bookingDate} onChange={e => setBookingDate(e.target.value)}
                      className="w-full bg-pink-50 border border-pink-100 rounded-2xl py-4 px-4 text-sm font-bold focus:outline-none focus:border-pink-500 shadow-inner" />
                 </div>
                 <div className="bg-pink-50 p-4 rounded-2xl border border-pink-100 italic text-[10px] text-pink-700 font-bold">
                    Booking will be paid using your Kampas Wallet balance.
                 </div>
                 <button onClick={handleBookService} disabled={bookingLoading || !bookingDate}
                   className="w-full bg-gray-900 text-white font-black py-4 rounded-2xl hover:bg-pink-500 transition-all uppercase tracking-widest flex items-center justify-center gap-2 shadow-xl disabled:opacity-50">
                   {bookingLoading ? <RefreshCw className="w-5 h-5 animate-spin" /> : <Calendar className="w-5 h-5" />}
                   Confirm Booking
                 </button>
              </div>
           </motion.div>
        </div>
      )}
      
      {/* ── TOP SECTION ── */}
      <div className="bg-white px-4 pt-6 pb-4 border-b border-pink-50 sticky top-0 z-40">
        <div className="flex flex-col gap-4">
          <div className="flex items-center justify-between">
            <h1 className="text-2xl font-black tracking-tight text-gray-900 flex items-center gap-2">
              <div className="w-8 h-8 rounded-lg bg-pink-500 flex items-center justify-center text-gray-900 text-xl font-black">K</div>
              EXPLORE
            </h1>
            <div className="flex items-center gap-2">
              <MapPin className="w-4 h-4 text-pink-500" />
              <span className="text-xs font-bold text-gray-600 truncate max-w-[120px]">
                {location ? 'My Campus' : 'Select Location'}
              </span>
            </div>
          </div>

          <div className="flex flex-col gap-2">
            <div className="relative">
              <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
              <input
                type="text"
                placeholder={`Search ${searchType}...`}
                value={searchInput}
                onChange={e => setSearchInput(e.target.value)}
                className="w-full bg-pink-50 border border-pink-200 rounded-2xl py-3.5 pl-11 pr-12 text-sm focus:outline-none focus:border-pink-500 transition-colors shadow-inner"
              />
              <div className="absolute right-3 top-1/2 -translate-y-1/2 flex items-center gap-1">
                {searchInput && (
                  <button onClick={() => setSearchInput('')} className="p-1 text-gray-400 hover:text-gray-600">
                    <X className="w-4 h-4" />
                  </button>
                )}
                <div className="h-6 w-px bg-pink-200 mx-1" />
                <button className="p-1.5 bg-pink-500 text-white rounded-lg shadow-sm">
                  <SlidersHorizontal className="w-4 h-4" />
                </button>
              </div>
            </div>

            <div className="flex gap-2 overflow-x-auto scrollbar-hide py-1">
              {(['products', 'services', 'sellers', 'stores'] as const).map(type => (
                <button
                  key={type}
                  onClick={() => setSearchType(type)}
                  className={`flex-shrink-0 px-4 py-1.5 rounded-full text-[10px] font-black uppercase tracking-widest transition-all ${
                    searchType === type ? 'bg-gray-900 text-white' : 'bg-pink-100 text-pink-600 hover:bg-pink-200'
                  }`}
                >
                  {type}
                </button>
              ))}
            </div>
          </div>
        </div>
      </div>

      {/* ── FLASH SALE STORIES ───────────────────────────────────────────────────────────── */}
      <FlashSaleStories sales={flashSales} />

      {/* ── AI RECOMMENDATIONS ───────────────────────────────────────────────────────────── */}
      {aiRecs.length > 0 && (
        <div className="px-4 mb-8">
          <div className="flex items-center justify-between mb-4">
            <h2 className="text-sm font-black uppercase tracking-widest text-indigo-900 flex items-center gap-2">
              <Sparkles className="w-4 h-4 text-indigo-500 animate-pulse" /> Recommended For You
            </h2>
            <div className="flex items-center gap-2 text-[8px] font-bold text-indigo-500 bg-indigo-50 px-2 py-1 rounded-full uppercase tracking-tighter">
               AI Personalized
            </div>
          </div>
          <div className="flex gap-4 overflow-x-auto pb-4 scrollbar-hide">
            {aiRecs.map(rec => (
              <div key={rec.id} className="w-48 flex-shrink-0 group relative">
                <div className="relative aspect-square rounded-3xl overflow-hidden mb-3 bg-indigo-50 shadow-sm border border-indigo-100">
                  <img src={rec.image} className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500" />
                  <div className="absolute inset-0 bg-gradient-to-t from-indigo-900/40 via-transparent to-transparent opacity-0 group-hover:opacity-100 transition-opacity" />
                  <div className="absolute top-2 right-2 bg-white/95 backdrop-blur px-2 py-1 rounded-lg text-[9px] font-black shadow-sm flex items-center gap-1">
                    <TrendingUp className="w-3 h-3 text-emerald-500" />
                    {(rec.relevance || 0).toFixed(0)}% Match
                  </div>
                  {rec.distance && (
                    <div className="absolute bottom-2 left-2 bg-gray-900/80 text-white text-[8px] font-black px-2 py-1 rounded-lg backdrop-blur-sm">
                      <MapPin className="w-2.5 h-2.5 inline mr-1" />
                      {(rec.distance / 1000).toFixed(1)}km
                    </div>
                  )}
                </div>
                <h3 className="text-sm font-bold text-gray-800 truncate mb-0.5 tracking-tight group-hover:text-indigo-600 transition-colors uppercase">{rec.title}</h3>
                <p className="text-[10px] font-black text-indigo-500">KSH {rec.price?.toLocaleString()}</p>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* ── CATEGORIES ───────────────────────────────────────────────────────────── */}
      <div className="px-4 mb-8">
        <div className="flex items-center justify-between mb-4">
          <h2 className="text-sm font-black uppercase tracking-widest text-gray-400">Categories</h2>
          <button className="text-[10px] font-bold text-pink-500 flex items-center gap-1">SEE ALL <ArrowRight className="w-3 h-3" /></button>
        </div>
        <div className="grid grid-cols-4 sm:grid-cols-7 gap-3">
          {CATEGORIES.map(cat => (
            <button
              key={cat.slug}
              onClick={() => setActiveFilter(cat.slug)}
              className="flex flex-col items-center gap-2 group"
            >
              <div className={`w-14 h-14 sm:w-16 sm:h-16 rounded-2xl flex items-center justify-center text-2xl transition-all ${
                activeFilter === cat.slug ? 'bg-pink-500 scale-105 shadow-lg' : 'bg-pink-50 border border-pink-100 group-hover:border-pink-300'
              }`}>
                {cat.icon}
              </div>
              <span className={`text-[10px] font-bold text-center leading-tight transition-colors ${activeFilter === cat.slug ? 'text-pink-600' : 'text-gray-500'}`}>
                {cat.label}
              </span>
            </button>
          ))}
        </div>
      </div>

      {/* ── TRENDING SECTION ───────────────────────────────────────────────────────────── */}
      {trending.products.length > 0 && (
        <div className="px-4 mb-8">
          <div className="flex items-center justify-between mb-4">
            <h2 className="text-sm font-black uppercase tracking-widest text-gray-900 flex items-center gap-2">
              <TrendingUp className="w-4 h-4 text-pink-600" /> Trending Now
            </h2>
          </div>
          <div className="flex gap-4 overflow-x-auto pb-4 scrollbar-hide">
            {trending.products.map(product => (
              <div key={product.id} className="w-40 flex-shrink-0 group">
                <div className="relative aspect-[4/5] rounded-2xl overflow-hidden mb-2 bg-pink-50 shadow-sm border border-pink-100">
                  <img src={product.images[0]} className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500" />
                  <div className="absolute top-2 right-2 bg-white/90 backdrop-blur px-1.5 py-0.5 rounded-md text-[8px] font-black shadow-sm">
                    KSH {product.price.toLocaleString()}
                  </div>
                  {product.isFlashSale && (
                    <div className="absolute bottom-2 left-2 flex items-center gap-1 bg-rose-600 text-white text-[8px] font-black px-1.5 py-0.5 rounded-md">
                      <Zap className="w-2.5 h-2.5 fill-current" /> FLASH
                    </div>
                  )}
                </div>
                <h3 className="text-xs font-bold text-gray-800 truncate mb-0.5">{product.name}</h3>
                <div className="flex items-center justify-between">
                  <span className="text-[9px] font-medium text-gray-400">By {(product as any).businessName || 'Seller'}</span>
                  {(product as any).isVerified && <UserCheck className="w-3 h-3 text-blue-500 fill-current" />}
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* ── TRENDING STORES/SELLERS ───────────────────────────────────────────────────────────── */}
      {trending.stores.length > 0 && (
        <div className="px-4 mb-8">
          <div className="flex items-center justify-between mb-4">
            <h2 className="text-sm font-black uppercase tracking-widest text-gray-400">Top Stores</h2>
          </div>
          <div className="flex gap-3 overflow-x-auto pb-4 scrollbar-hide">
            {trending.stores.map((store: any) => (
              <div key={store.id} className="flex-shrink-0 flex items-center gap-3 bg-pink-20 border border-pink-100 p-2 rounded-2xl hover:border-pink-400 transition-colors cursor-pointer">
                <img src={store.businessLogo || store.avatar} className="w-12 h-12 rounded-xl object-cover bg-white" />
                <div className="pr-4">
                  <div className="flex items-center gap-1">
                    <p className="text-xs font-black text-gray-900 truncate max-w-[100px]">{store.businessName || store.name}</p>
                    {store.isVerified && <CheckCircle className="w-3 h-3 text-blue-500 fill-current" />}
                  </div>
                  <p className="text-[10px] text-gray-500">{store.campus}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* ── MAIN MARKETPLACE GRID ───────────────────────────────────────────────────────────── */}
      <div className="px-4">
        <div className="flex items-center justify-between mb-6">
          <div>
            <h2 className="text-xl font-black text-gray-900">{activeFilter ? CATEGORIES.find(c => c.slug === activeFilter)?.label : 'All Items'}</h2>
            <p className="text-xs text-gray-400 font-medium">Verified local campus listings</p>
          </div>
          <div className="flex items-center gap-2">
            <div className="relative">
              <select 
                value={sort} 
                onChange={e => setSort(e.target.value)}
                className="appearance-none bg-white border border-pink-200 text-[10px] font-black uppercase tracking-widest px-3 py-2 pr-8 rounded-xl focus:outline-none focus:border-pink-500 cursor-pointer"
              >
                <option value="createdAt">Newest</option>
                <option value="price_asc">Price ↑</option>
                <option value="price_desc">Price ↓</option>
              </select>
              <ChevronDown className="absolute right-2 top-1/2 -translate-y-1/2 w-3 h-3 text-gray-400 pointer-events-none" />
            </div>
          </div>
        </div>

        {loading ? (
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            {Array.from({ length: 8 }).map((_, i) => (
              <div key={i} className="animate-pulse space-y-3">
                <div className="aspect-[4/5] bg-pink-50 rounded-2xl" />
                <div className="h-4 bg-pink-50 rounded w-full" />
                <div className="h-3 bg-pink-50 rounded w-2/3" />
              </div>
            ))}
          </div>
        ) : searchType === 'services' || activeFilter === 'services' ? (
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {products.map(service => (
              <div key={service.id}>
                <ServiceCard service={service} onBook={(s) => { setBookingService(s); setBookingDate(''); }} />
              </div>
            ))}
          </div>
        ) : (
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            {products.map(product => (
              <div key={product.id}>
                <ProductCard product={product} />
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}

function ServiceCard({ service, onBook }: { service: any, onBook: (s: any) => void }) {
  return (
    <div className="bg-white border border-pink-100 p-6 rounded-[2.5rem] shadow-sm hover:shadow-xl transition-all relative overflow-hidden group">
       <div className="flex justify-between items-start mb-4">
          <div className="flex items-center gap-4">
             <div className="w-14 h-14 rounded-2xl bg-pink-50 overflow-hidden flex-shrink-0">
                <img src={service.images?.[0] || 'https://images.unsplash.com/photo-1595950653106-6c9ebd614d3a?w=100&q=80'} className="w-full h-full object-cover" />
             </div>
             <div>
                <span className="text-[10px] font-black uppercase bg-pink-100 text-pink-600 px-2 py-0.5 rounded-full">
                  {typeof service.category === 'object' ? service.category.name : (service.category || 'Service')}
                </span>
                <h3 className="text-xl font-black text-gray-900 mt-1 uppercase tracking-tight">{service.name}</h3>
             </div>
          </div>
          <p className="text-xl font-black text-pink-500">KSH {service.price?.toLocaleString()}</p>
       </div>
       <p className="text-sm text-gray-500 line-clamp-2 leading-relaxed mb-6">{service.description}</p>
       
       <div className="flex items-center justify-between pt-4 border-t border-pink-50">
          <div className="flex items-center gap-2">
             <img src={(service.seller || service.organizer)?.avatar || `https://api.dicebear.com/7.x/avataaars/svg?seed=${service.sellerId}`} className="w-6 h-6 rounded-full border border-pink-200" />
             <div className="flex items-center gap-1">
                <span className="text-[10px] font-bold text-gray-400 capitalize">{(service.seller || service.organizer)?.businessName || (service.seller || service.organizer)?.name || 'Seller'}</span>
                {(service.seller || service.organizer)?.isVerified && <UserCheck className="w-3 h-3 text-blue-500 fill-current" />}
             </div>
          </div>
          <button 
             onClick={() => onBook(service)}
             className="bg-gray-900 text-white px-6 py-2.5 rounded-xl font-black text-[10px] uppercase tracking-widest hover:bg-pink-500 transition-all shadow-lg"
          >
            Book Service
          </button>
       </div>
    </div>
  );
}

function ProductCard({ product }: { product: Product }) {
  return (
    <div className="group bg-white rounded-3xl overflow-hidden border border-pink-50 hover:border-pink-200 transition-all hover:shadow-xl hover:shadow-pink-500/5">
      <div className="relative aspect-[4/5] overflow-hidden bg-pink-50">
        <img src={product.images[0]} alt={product.name} className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-700" />
        
        {/* Badges */}
        <div className="absolute top-3 left-3 flex flex-col gap-2">
          {product.isFlashSale && (
            <div className="bg-rose-600 text-white text-[8px] font-black px-2 py-1 rounded-lg uppercase tracking-widest flex items-center gap-1 shadow-lg">
              <Zap className="w-2.5 h-2.5 fill-current" /> Sale
            </div>
          )}
        </div>

        <button className="absolute top-3 right-3 w-8 h-8 rounded-full bg-white/20 backdrop-blur-md flex items-center justify-center text-white border border-white/30 transition-all hover:bg-pink-500 hover:border-pink-500">
          <Heart className="w-4 h-4" />
        </button>

        <div className="absolute bottom-3 left-3 right-3 flex justify-between items-end">
          <div className="bg-white/95 backdrop-blur px-2.5 py-1.5 rounded-2xl shadow-lg border border-pink-50">
            <p className="text-[10px] font-black text-pink-600 leading-none mb-0.5">KSH</p>
            <p className="text-sm font-black text-gray-900 leading-none">{(product.isFlashSale ? product.flashSalePrice : product.price)?.toLocaleString()}</p>
          </div>
          <button className="w-10 h-10 rounded-2xl bg-gray-900 text-white flex items-center justify-center shadow-xl hover:bg-pink-600 transition-all active:scale-90">
            <ShoppingCart className="w-5 h-5" />
          </button>
        </div>
      </div>

      <div className="p-4">
        <h3 className="text-sm font-bold text-gray-900 mb-1 line-clamp-1 group-hover:text-pink-600 transition-colors uppercase tracking-tight">
          {product.name}
        </h3>
        <div className="flex items-center gap-1.5">
          <img src={(product as any).seller?.avatar || `https://api.dicebear.com/7.x/avataaars/svg?seed=${product.sellerId}`} className="w-4 h-4 rounded-full" />
          <span className="text-[10px] font-bold text-gray-400">By {(product as any).seller?.businessName || (product as any).seller?.name || 'Seller'}</span>
          {(product as any).seller?.isVerified && <UserCheck className="w-3 h-3 text-blue-500 fill-current" />}
        </div>
      </div>
    </div>
  );
}

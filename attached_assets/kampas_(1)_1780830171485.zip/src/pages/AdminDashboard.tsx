import { 
  Users, DollarSign, Package, Activity, AlertTriangle, Shield, TrendingUp, Search, Database,
  Store, ShoppingCart, Truck, CreditCard, Megaphone, Calendar, HelpCircle, LayoutDashboard,
  Bell, Settings, Power, ChevronRight, Zap, Target, Eye, MousePointerClick, Filter, Plus, Home, CheckCircle, XCircle, MapPin, History, Info, ShieldCheck, RefreshCw
} from 'lucide-react';
import { ResponsiveContainer, AreaChart, Area, XAxis, YAxis, Tooltip, CartesianGrid } from 'recharts';
import { Link } from 'react-router-dom';
import { useEffect, useState } from 'react';
import { socket } from '@/src/lib/socket';
import { GET, PUT } from '../lib/api';
import MapView from '../components/MapView';

const analyticsData = [
  { name: 'Mon', revenue: 0, users: 0, orders: 0 },
  { name: 'Tue', revenue: 0, users: 0, orders: 0 },
  { name: 'Wed', revenue: 0, users: 0, orders: 0 },
  { name: 'Thu', revenue: 0, users: 0, orders: 0 },
  { name: 'Fri', revenue: 0, users: 0, orders: 0 },
  { name: 'Sat', revenue: 0, users: 0, orders: 0 },
  { name: 'Sun', revenue: 0, users: 0, orders: 0 },
];

type TabType = 'dashboard' | 'users' | 'sellers' | 'verification' | 'payouts' | 'flash-sales' | 'products' | 'housing' | 'orders' | 'transactions' | 'ads' | 'events' | 'support' | 'kyc' | 'reports' | 'seller-apps';

export default function AdminDashboard() {
  const [activeUsers, setActiveUsers] = useState<number>(0);
  const [activeTab, setActiveTab] = useState<TabType>('seller-apps');
  const [isSidebarOpen, setIsSidebarOpen] = useState(true);
  const [sellerApps, setSellerApps] = useState<any[]>([]);
  const [loadingApps, setLoadingApps] = useState(false);

  useEffect(() => {
    if (activeTab === 'seller-apps') fetchApplications();
  }, [activeTab]);

  const fetchApplications = async () => {
    setLoadingApps(true);
    try {
      const res = await GET('/api/admin/seller-applications');
      setSellerApps(res.data.applications);
    } catch (err) {
      console.error(err);
    } finally {
      setLoadingApps(false);
    }
  };

  const handleAppAction = async (applicationId: string, action: 'APPROVE' | 'REJECT') => {
    try {
      await PUT('/api/admin/approve-seller', { applicationId, action });
      fetchApplications();
    } catch (err) {
      console.error(err);
    }
  };

  useEffect(() => {
    socket.on('activeUsers', (count) => {
      setActiveUsers(count);
    });

    fetchApplications();

    return () => {
      socket.off('activeUsers');
    };
  }, []);

  const renderEmptyState = (title: string, description: string) => (
    <div className="flex-1 bg-pink-50 border border-pink-200 rounded-3xl p-12 flex flex-col items-center justify-center text-center h-full min-h-[60vh] shadow-sm relative overflow-hidden">
      <div className="relative w-20 h-20 bg-pink-100 border border-pink-200 rounded-3xl flex items-center justify-center mb-6">
        <Database className="w-10 h-10 text-pink-500" />
      </div>
      <h3 className="text-2xl font-bold text-gray-900 mb-3">{title} Module</h3>
      <p className="text-gray-600 max-w-md text-sm leading-relaxed">
        There are currently <span className="text-pink-600 font-bold">0 records</span> stored. {description}
      </p>
      <button className="mt-8 px-6 py-3 bg-pink-500 hover:bg-pink-600 rounded-xl text-sm font-bold text-white transition-all flex items-center gap-2">
        <Activity className="w-4 h-4" /> Initialize Connection
      </button>
    </div>
  );

  const NavItem = ({ id, label, icon: Icon, tag }: { id: TabType, label: string, icon: any, tag?: string }) => {
    const isActive = activeTab === id;
    return (
      <button 
        onClick={() => setActiveTab(id)} 
        className={`w-full flex items-center justify-between px-4 py-3 rounded-xl transition-all duration-300 group
          ${isActive 
            ? 'bg-pink-500/10 text-pink-600 font-bold' 
            : 'border border-transparent text-gray-600 hover:text-gray-900 hover:bg-pink-50'
          }`}
      >
        <div className="flex items-center gap-3">
          <Icon className={`w-5 h-5 ${isActive ? 'text-pink-600' : 'group-hover:text-pink-500 transition-colors'}`} />
          <span className="text-sm tracking-wide">{label}</span>
        </div>
        {tag && (
          <span className={`text-[10px] px-2 py-0.5 rounded-full font-bold uppercase tracking-wider ${isActive ? 'bg-pink-500/20 text-pink-600' : 'bg-gray-100 text-gray-500'}`}>
            {tag}
          </span>
        )}
      </button>
    );
  };

  return (
    <div className="flex h-screen bg-white text-gray-900 font-sans selection:bg-pink-500 selection:text-white overflow-hidden relative">

      {/* Sidebar */}
      <aside className={`relative z-20 flex flex-col bg-white border-r border-pink-100 transition-all duration-500 ${isSidebarOpen ? 'w-72' : 'w-20'}`}>
        <div className="p-6 border-b border-pink-100 flex items-center justify-between">
          <Link to="/" className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-pink-500 flex items-center justify-center font-bold text-white text-xl shadow-[0_0_15px_rgba(236,72,153,0.3)]">
              K
            </div>
            {isSidebarOpen && (
              <div className="flex flex-col">
                <span className="font-bold text-lg tracking-tight leading-none text-gray-900">Kampas <span className="text-pink-500 font-light">OS</span></span>
                <span className="text-[10px] text-pink-500 font-mono mt-1 uppercase tracking-widest flex items-center gap-1">
                  <span className="w-1.5 h-1.5 rounded-full bg-pink-500 animate-pulse"></span> Super Admin
                </span>
              </div>
            )}
          </Link>
        </div>
        
        <div className="flex-1 overflow-y-auto w-full py-6 px-4 space-y-8 scrollbar-hide">
          {/* Main Module */}
          <div className="space-y-2">
            {isSidebarOpen && <p className="text-[10px] text-gray-500 font-bold px-4 mb-3 uppercase tracking-widest">Command Center</p>}
            <NavItem id="dashboard" label="Dashboard" icon={LayoutDashboard} />
          </div>

          {/* Directory Module */}
          <div className="space-y-2">
            {isSidebarOpen && <p className="text-[10px] text-gray-500 font-bold px-4 mb-3 uppercase tracking-widest">Marketplace</p>}
            <NavItem id="seller-apps" label="New Applications" icon={Plus} tag={String(sellerApps.filter(a => a.status === 'PENDING').length)} />
            <NavItem id="sellers" label="Sellers" icon={Store} tag="0" />
            <NavItem id="verification" label="Verifications" icon={ShieldCheck} tag="0" />
            <NavItem id="payouts" label="Payouts" icon={DollarSign} tag="0" />
            <NavItem id="flash-sales" label="Flash Sales" icon={Zap} tag="0" />
          </div>

          <div className="space-y-2">
            {isSidebarOpen && <p className="text-[10px] text-gray-500 font-bold px-4 mb-3 uppercase tracking-widest">Ecosystem</p>}
            <NavItem id="users" label="Users" icon={Users} tag="0" />
            <NavItem id="products" label="Products" icon={Package} tag="0" />
            <NavItem id="housing" label="Housing" icon={Home} tag="0" />
          </div>

          {/* Logistics & Finance */}
          <div className="space-y-2">
            {isSidebarOpen && <p className="text-[10px] text-gray-500 font-bold px-4 mb-3 uppercase tracking-widest">Operations</p>}
            <NavItem id="orders" label="Orders" icon={Truck} tag="0" />
            <NavItem id="transactions" label="Transactions" icon={DollarSign} tag="0" />
            <NavItem id="ads" label="Ads" icon={Megaphone} tag="0" />
            <NavItem id="events" label="Events" icon={Calendar} tag="0" />
          </div>
          
          {/* Moderation */}
          <div className="space-y-2">
            {isSidebarOpen && <p className="text-[10px] text-gray-500 font-bold px-4 mb-3 uppercase tracking-widest">Security</p>}
            <NavItem id="kyc" label="KYC" icon={Shield} tag="0" />
            <NavItem id="reports" label="Reports" icon={AlertTriangle} tag="0" />
            <NavItem id="support" label="Support" icon={HelpCircle} tag="0" />
          </div>
        </div>

        <div className="p-4 border-t border-pink-100">
          <button className="flex items-center gap-3 w-full px-4 py-3 rounded-xl text-gray-500 hover:text-red-500 hover:bg-red-50 transition-colors">
            <Power className="w-5 h-5" />
            {isSidebarOpen && <span className="font-bold text-sm">Terminate Session</span>}
          </button>
        </div>
      </aside>

      {/* Main Admin Area */}
      <main className="flex-1 flex flex-col h-screen bg-gray-50 relative z-10 overflow-hidden">
        {/* Top Navbar */}
        <header className="h-20 bg-white border-b border-pink-100 flex items-center justify-between px-8 z-20">
          <div className="flex items-center gap-4">
             <div className="relative group">
              <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400 group-focus-within:text-pink-500 transition-colors" />
              <input type="text" placeholder="Global Search (Txn, ID, User)..." className="bg-gray-100 border border-transparent rounded-xl py-2.5 pl-11 pr-4 text-sm w-96 focus:outline-none focus:border-pink-500 focus:bg-white text-gray-900 transition-all" />
              <div className="absolute right-3 top-1/2 -translate-y-1/2 flex items-center gap-1">
                <kbd className="px-2 py-1 bg-white border border-gray-200 rounded text-[10px] text-gray-500 font-mono shadow-sm">⌘</kbd>
                <kbd className="px-2 py-1 bg-white border border-gray-200 rounded text-[10px] text-gray-500 font-mono shadow-sm">K</kbd>
              </div>
             </div>
          </div>
          
          <div className="flex items-center gap-6">
             <button className="relative w-10 h-10 bg-gray-50 border border-gray-200 hover:bg-gray-100 rounded-full flex items-center justify-center transition-colors">
                <Bell className="w-4 h-4 text-gray-600" />
                <span className="absolute top-2 right-2 w-2 h-2 rounded-full bg-pink-500"></span>
             </button>
             <button className="w-10 h-10 bg-gray-50 border border-gray-200 hover:bg-gray-100 rounded-full flex items-center justify-center transition-colors">
                <Settings className="w-4 h-4 text-gray-600" />
             </button>
             <div className="ml-2 w-10 h-10 rounded-full bg-pink-500 border-2 border-pink-200 flex items-center justify-center shadow-md">
               <span className="font-bold text-sm text-white">SU</span>
             </div>
          </div>
        </header>

        {/* Scrollable Content */}
        <div className="flex-1 overflow-y-auto p-8 scrollbar-hide">
          {activeTab === 'dashboard' && (
            <div className="space-y-8 animate-in fade-in slide-in-from-bottom-4 duration-700">
               <div>
                <h1 className="text-3xl font-black text-gray-900 tracking-tight flex items-center gap-3">
                  <LayoutDashboard className="w-8 h-8 text-pink-500" /> Command Center
                </h1>
                <p className="text-gray-500 mt-2">Real-time platform overview and ecosystem metrics.</p>
              </div>

              {/* Core Ecosystem Stats */}
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
                {[
                  { label: 'Platform Revenue', value: 'KSH 0.00', sub: 'Gross Merchandise Value', icon: DollarSign },
                  { label: 'Active Users', value: activeUsers.toString(), sub: 'Live connections', icon: Users },
                  { label: 'Total Listings', value: '0', sub: 'Verified products', icon: Package },
                  { label: 'Growth Vector', value: '0%', sub: 'Weekly increase', icon: TrendingUp },
                ].map((stat, i) => (
                  <div key={i} className={`bg-white border border-pink-100 p-6 rounded-3xl relative overflow-hidden group shadow-sm`}>
                     <div className="flex items-center justify-between mb-4 relative z-10">
                       <span className="text-sm font-bold text-gray-500">{stat.label}</span>
                       <div className={`p-2 rounded-xl bg-pink-50 text-pink-500`}>
                         <stat.icon className="w-5 h-5" />
                       </div>
                     </div>
                     <h3 className="text-3xl font-black mb-1 tracking-tight text-gray-900">{stat.value}</h3>
                     <p className="text-xs text-gray-400 font-medium">{stat.sub}</p>
                  </div>
                ))}
              </div>

              <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
                <div className="lg:col-span-2 bg-white border border-pink-100 rounded-3xl p-6 shadow-sm">
                   <h3 className="text-lg font-black text-gray-900 mb-6 flex items-center gap-2">
                     <TrendingUp className="w-5 h-5 text-gray-400" /> Revenue Overview
                   </h3>
                   <div className="h-80 w-full">
                     <ResponsiveContainer width="100%" height="100%">
                        <AreaChart data={analyticsData}>
                          <defs>
                            <linearGradient id="colorRev" x1="0" y1="0" x2="0" y2="1">
                              <stop offset="5%" stopColor="#ec4899" stopOpacity={0.3}/>
                              <stop offset="95%" stopColor="#ec4899" stopOpacity={0}/>
                            </linearGradient>
                          </defs>
                          <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#fdf2f8" />
                          <XAxis dataKey="name" axisLine={false} tickLine={false} tick={{fontSize: 12, fill: '#9ca3af'}} />
                          <YAxis axisLine={false} tickLine={false} tick={{fontSize: 12, fill: '#9ca3af'}} />
                          <Tooltip 
                            contentStyle={{ backgroundColor: '#fff', borderRadius: '16px', border: '1px solid #fce7f3', boxShadow: '0 10px 15px -3px rgba(0, 0, 0, 0.1)' }}
                            itemStyle={{ fontWeight: 'bold' }}
                          />
                          <Area type="monotone" dataKey="revenue" stroke="#ec4899" strokeWidth={4} fillOpacity={1} fill="url(#colorRev)" />
                        </AreaChart>
                     </ResponsiveContainer>
                   </div>
                </div>

                <div className="bg-white border border-pink-100 rounded-3xl p-6 shadow-sm">
                   <h3 className="text-lg font-black text-gray-900 mb-6 flex items-center gap-2">
                     <Activity className="w-5 h-5 text-gray-400" /> Recent Actions
                   </h3>
                   <div className="space-y-4">
                     <div className="flex items-center gap-3 p-3 bg-pink-50 rounded-2xl border border-pink-100">
                        <div className="w-2 h-2 rounded-full bg-pink-500"></div>
                        <p className="text-xs font-bold text-pink-600">Admin session active</p>
                     </div>
                   </div>
                </div>
              </div>
            </div>
          )}

          {activeTab === 'ads' && (
            <div className="space-y-8 animate-in fade-in slide-in-from-bottom-4 duration-700">
              <div className="flex justify-between items-end mb-6">
                <div>
                  <h1 className="text-3xl font-black text-gray-900 tracking-tight flex items-center gap-3">
                    <Megaphone className="w-8 h-8 text-pink-500" /> Advertisement Manager
                  </h1>
                  <p className="text-gray-500 mt-2">Manage platform ads and placements</p>
                </div>
                <div className="flex gap-3">
                  <button className="px-4 py-2 bg-white border border-pink-200 text-gray-700 rounded-xl font-bold flex items-center gap-2 hover:bg-pink-50">
                    <Filter className="w-4 h-4" /> Filters
                  </button>
                  <button className="px-4 py-2 bg-pink-500 text-white rounded-xl font-bold flex items-center gap-2 hover:bg-pink-600 shadow-[0_0_15px_rgba(236,72,153,0.3)]">
                    <Plus className="w-4 h-4" /> New Category
                  </button>
                </div>
              </div>

              {/* Advertisement Core Metrics */}
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
                {[
                  { label: 'Total Ad Revenue', value: 'KSH 0.00', sub: 'Gross Earnings', icon: DollarSign },
                  { label: 'Active Campaigns', value: '0', sub: 'Running now', icon: Activity },
                  { label: 'Total Impressions', value: '0', sub: 'Across network', icon: Eye },
                  { label: 'Total Clicks', value: '0', sub: '0.00% CTR', icon: MousePointerClick },
                ].map((stat, i) => (
                  <div key={i} className={`bg-white border border-pink-100 p-6 rounded-3xl relative overflow-hidden group shadow-sm`}>
                     <div className="flex items-center justify-between mb-4 relative z-10">
                       <span className="text-sm font-bold text-gray-500">{stat.label}</span>
                       <div className={`p-2 rounded-xl bg-pink-50 text-pink-500`}>
                         <stat.icon className="w-5 h-5" />
                       </div>
                     </div>
                     <h3 className="text-3xl font-black mb-1 tracking-tight text-gray-900">{stat.value}</h3>
                     <p className="text-xs text-gray-400 font-medium">{stat.sub}</p>
                  </div>
                ))}
              </div>

              <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
                <div className="lg:col-span-2 space-y-6">
                  {/* Category Management */}
                  <div className="bg-white border border-pink-100 rounded-3xl p-6 shadow-sm">
                     <h3 className="text-lg font-black text-gray-900 mb-6 flex items-center gap-2">
                       <Settings className="w-5 h-5 text-gray-400" /> Ad Categories & Pricing
                     </h3>
                     
                     <div className="space-y-4">
                       {[
                         { name: 'Homepage Banner', type: 'Premium Hero Placement', pricing: 'KSH 5,000 / week' },
                         { name: 'Sponsored Story/Reel', type: 'Social Video Ad', pricing: 'KSH 1,500 / day' },
                         { name: 'Featured Product', type: 'Marketplace Search Boost', pricing: 'KSH 500 / week' },
                         { name: 'Campus Event Push', type: 'Targeted Notification', pricing: 'KSH 2,000 / blast' },
                       ].map((cat, i) => (
                         <div key={i} className="flex items-center justify-between p-4 border border-gray-100 rounded-2xl hover:border-pink-200 transition-colors bg-gray-50/50">
                           <div className="flex items-center gap-4">
                             <div className="w-12 h-12 rounded-xl bg-white border border-gray-200 flex items-center justify-center font-bold text-gray-400">
                               {i + 1}
                             </div>
                             <div>
                               <h4 className="font-bold text-gray-900">{cat.name}</h4>
                               <p className="text-xs text-gray-500">{cat.type}</p>
                             </div>
                           </div>
                           <div className="flex items-center gap-6">
                             <div className="text-right">
                               <p className="font-bold text-gray-900 text-sm">{cat.pricing}</p>
                               <span className="text-[10px] text-green-600 font-bold bg-green-50 px-2 py-0.5 rounded-full inline-block mt-1">Active</span>
                             </div>
                             <button className="text-pink-500 font-bold text-sm hover:underline">Edit</button>
                           </div>
                         </div>
                       ))}
                     </div>
                  </div>

                  {/* Active Campaigns Tracking */}
                  <div className="bg-white border border-pink-100 rounded-3xl p-6 shadow-sm min-h-[300px] flex flex-col items-center justify-center text-center">
                    <Target className="w-12 h-12 text-gray-300 mb-4" />
                    <h4 className="font-bold text-gray-900 mb-2">No Active Campaigns</h4>
                    <p className="text-sm text-gray-500 max-w-sm">When advertisers launch campaigns for campuses and events, live location heatmaps and performance data will appear here.</p>
                  </div>
                </div>

                <div className="space-y-6">
                  {/* Approval Queue */}
                  <div className="bg-white border border-pink-100 rounded-3xl p-6 shadow-sm">
                    <h3 className="text-lg font-black text-gray-900 mb-4 flex items-center justify-between">
                      <span>Approval Queue</span>
                      <span className="bg-gray-100 text-gray-600 px-2 py-1 rounded text-xs">0 Pending</span>
                    </h3>
                    <div className="h-40 flex flex-col items-center justify-center border-2 border-dashed border-gray-200 rounded-2xl bg-gray-50/50">
                      <Shield className="w-8 h-8 text-gray-300 mb-2" />
                      <p className="text-xs text-gray-500 font-medium">All advertisements reviewed.</p>
                    </div>
                  </div>

                  {/* Tier Rankings */}
                  <div className="bg-white border border-pink-100 rounded-3xl p-6 shadow-sm">
                    <h3 className="text-lg font-black text-gray-900 mb-4">Premium Tiers</h3>
                    <div className="space-y-3">
                      {[
                        { name: 'Platinum', color: 'bg-gray-900', text: 'text-white' },
                        { name: 'Gold', color: 'bg-yellow-100', text: 'text-yellow-800' },
                        { name: 'Silver', color: 'bg-gray-200', text: 'text-gray-800' },
                        { name: 'Bronze', color: 'bg-orange-100', text: 'text-orange-800' },
                      ].map((tier, i) => (
                         <div key={i} className={`flex items-center justify-between p-3 rounded-xl border border-gray-100`}>
                           <span className={`px-3 py-1 rounded-lg text-xs font-bold ${tier.color} ${tier.text}`}>{tier.name}</span>
                           <span className="text-xs text-gray-500 font-medium tracking-wide">0 Active</span>
                         </div>
                      ))}
                    </div>
                  </div>
                </div>
              </div>
            </div>
          )}
          
          {activeTab === 'seller-apps' && (
            <div className="p-8 pb-24 overflow-y-auto h-full">
              <div className="mb-8">
                <h2 className="text-3xl font-black text-gray-900 uppercase tracking-tighter italic">Seller Applications</h2>
                <p className="text-sm text-gray-400 font-bold uppercase tracking-widest mt-1">Review student applications for campus businesses</p>
              </div>

              {loadingApps ? (
                <div className="bg-white border border-pink-100 rounded-3xl p-12 flex items-center justify-center">
                  <RefreshCw className="w-8 h-8 text-pink-500 animate-spin" />
                </div>
              ) : sellerApps.length === 0 ? (
                renderEmptyState('Application Hub', 'Student seller applications will appear here for review.')
              ) : (
                <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                  {sellerApps.map(app => (
                    <div key={app.id} className={`bg-white border p-6 rounded-[2rem] shadow-sm transition-all ${app.status === 'PENDING' ? 'border-pink-200 shadow-xl shadow-pink-50/50' : 'border-gray-100 opacity-70'}`}>
                      <div className="flex justify-between items-start mb-4">
                        <div className="flex items-center gap-3">
                          <div className="w-12 h-12 bg-pink-50 rounded-2xl flex items-center justify-center font-black text-pink-500 text-lg">
                            {app.businessName[0].toUpperCase()}
                          </div>
                          <div>
                            <h4 className="font-black text-gray-900 uppercase tracking-tight">{app.businessName}</h4>
                            <p className="text-[10px] text-gray-400 font-black uppercase tracking-widest">{app.category.replace('_',' ')} · {app.campus}</p>
                          </div>
                        </div>
                        <span className={`text-[10px] px-2 py-0.5 rounded-full font-black uppercase tracking-widest ${
                          app.status === 'PENDING' ? 'bg-orange-100 text-orange-600' : 
                          app.status === 'APPROVED' ? 'bg-green-100 text-green-600' : 'bg-red-100 text-red-600'
                        }`}>
                          {app.status}
                        </span>
                      </div>
                      
                      <div className="bg-gray-50 border border-gray-100 rounded-2xl p-4 mb-4">
                        <p className="text-[10px] text-gray-400 font-black uppercase tracking-widest mb-1">Description</p>
                        <p className="text-sm text-gray-600 leading-relaxed italic">"{app.businessDescription}"</p>
                      </div>

                      <div className="flex items-center justify-between">
                        <div className="flex flex-col">
                          <p className="text-[10px] text-gray-400 font-black uppercase tracking-widest">Applicant</p>
                          <p className="text-xs font-bold text-gray-900">{app.userName}</p>
                          <p className="text-[9px] text-gray-400">{app.userEmail}</p>
                        </div>
                        {app.status === 'PENDING' && (
                          <div className="flex gap-2">
                            <button 
                              onClick={() => handleAppAction(app.id, 'REJECT')}
                              className="px-4 py-2 bg-red-50 text-red-500 rounded-xl text-[10px] font-black uppercase tracking-widest hover:bg-red-100 transition-all font-bold"
                            >
                              Reject
                            </button>
                            <button 
                              onClick={() => handleAppAction(app.id, 'APPROVE')}
                              className="px-4 py-2 bg-gray-900 text-white rounded-xl text-[10px] font-black uppercase tracking-widest hover:bg-pink-500 transition-all shadow-lg shadow-pink-100 font-bold"
                            >
                              Approve
                            </button>
                          </div>
                        )}
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>
          )}

          {activeTab === 'housing' && <HousingModeration />}
          
          {activeTab === 'sellers' && <SellerModeration />}
          {activeTab === 'verification' && <VerificationModeration />}
          {activeTab === 'payouts' && <PayoutModeration />}
          {activeTab === 'flash-sales' && <FlashSaleManagement />}
          
          {/* Dynamic Tab Rendering (Empty States mapped to DB prep) */}
          {activeTab === 'users' && renderEmptyState('User Matrix', 'Records of Buyers, Sellers, Admins, and Support staff will be localized here.')}
          {activeTab === 'sellers' && renderEmptyState('Business Hub', 'Approved businesses, storefronts, analytics, and verification queues will be managed here.')}
          {activeTab === 'products' && renderEmptyState('Global Inventory', 'All active listings, stock alerts, fake product detection, and price tracking will appear here.')}
          {activeTab === 'orders' && renderEmptyState('Logistics Control', 'Live tracking feeds, dispatch assignments, and full order lifecycle tracking will be initialized here.')}
          {activeTab === 'transactions' && renderEmptyState('Financial Engine', 'M-Pesa deposits, Escrow holds, Seller payouts, and platform commission records will index here.')}
          {activeTab === 'events' && renderEmptyState('Campus Events', 'Ticketing, event verification, and venue capacity analytics.')}
          {activeTab === 'kyc' && renderEmptyState('KYC Gateway', 'ID verification documents, ML-powered fraud scoring, and manual approval tickets.')}
          {activeTab === 'support' && renderEmptyState('Support Matrix', 'Dispute resolutions, live consumer chats, and refund processing tickets.')}
          {activeTab === 'reports' && renderEmptyState('Threat Intel', 'System flags, automated scam detection alerts, and user reports.')}

        </div>
      </main>
    </div>
  );
}

function SellerModeration() {
  const [requests, setRequests] = useState<any[]>([]);
  const fetchRequests = async () => { const r = await GET('/api/admin/sellers/pending'); setRequests(r.data.requests); };
  useEffect(() => { fetchRequests(); }, []);
  const handleAction = async (id: string, action: 'APPROVE' | 'REJECT') => {
    await PUT(`/api/admin/sellers/${id}/respond`, { action });
    fetchRequests();
  };
  return (
    <div className="space-y-6">
      <h2 className="text-2xl font-black">Seller Applications</h2>
      {requests.length === 0 ? renderEmptySection('Store', 'No pending seller applications.') : (
        <div className="grid gap-4">
          {requests.map(r => (
            <div key={r.id} className="bg-white border border-pink-100 p-6 rounded-[2rem] flex items-center justify-between">
              <div className="flex items-center gap-4">
                <div className="w-12 h-12 bg-pink-50 rounded-2xl flex items-center justify-center font-bold text-pink-600">{r.user?.name?.[0]}</div>
                <div>
                  <p className="font-bold">{r.user?.name}</p>
                  <p className="text-xs text-gray-400">{r.user?.email} • {r.user?.campus}</p>
                </div>
              </div>
              <div className="flex gap-2">
                <button onClick={() => handleAction(r.id, 'APPROVE')} className="bg-emerald-500 text-white px-6 py-2.5 rounded-xl font-bold text-xs uppercase">Approve</button>
                <button onClick={() => handleAction(r.id, 'REJECT')} className="bg-red-50 text-red-500 px-6 py-2.5 rounded-xl font-bold text-xs uppercase">Reject</button>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}

function VerificationModeration() {
  const [requests, setRequests] = useState<any[]>([]);
  const fetchRequests = async () => { const r = await GET('/api/admin/verifications/pending'); setRequests(r.data.requests); };
  useEffect(() => { fetchRequests(); }, []);
  const handleAction = async (id: string, action: 'APPROVE' | 'REJECT') => {
    await PUT(`/api/admin/verifications/${id}/respond`, { action });
    fetchRequests();
  };
  return (
    <div className="space-y-6">
      <h2 className="text-2xl font-black">Badge Verification Queue</h2>
      {requests.length === 0 ? renderEmptySection('ShieldCheck', 'No pending verification requests.') : (
        <div className="grid gap-4">
          {requests.map(r => (
            <div key={r.id} className="bg-white border border-blue-100 p-6 rounded-[2rem] flex items-center justify-between">
              <div className="flex items-center gap-4">
                 <div className="w-12 h-12 bg-blue-50 rounded-2xl flex items-center justify-center"><ShieldCheck className="w-6 h-6 text-blue-500" /></div>
                 <div>
                    <p className="font-bold">{r.user?.name} {r.user?.role === 'SELLER' && <span className="text-[10px] bg-indigo-100 text-indigo-600 px-2 rounded-full font-black uppercase ml-2">Seller</span>}</p>
                    <p className="text-xs text-gray-400">Request ID: {r.id.slice(-8).toUpperCase()}</p>
                 </div>
              </div>
              <button onClick={() => handleAction(r.id, 'APPROVE')} className="bg-blue-600 text-white px-8 py-3 rounded-2xl font-black text-[10px] uppercase tracking-widest shadow-lg shadow-blue-500/20">Grant Badge</button>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}

function PayoutModeration() {
  const [requests, setRequests] = useState<any[]>([]);
  const fetchRequests = async () => { const r = await GET('/api/admin/payouts/pending'); setRequests(r.data.requests); };
  useEffect(() => { fetchRequests(); }, []);
  const handleAction = async (id: string, action: 'COMPLETE' | 'FAIL') => {
    await PUT(`/api/admin/payouts/${id}/respond`, { action });
    fetchRequests();
  };
  return (
    <div className="space-y-6">
      <h2 className="text-2xl font-black">Withdrawal Requests</h2>
      {requests.length === 0 ? renderEmptySection('DollarSign', 'All payouts processed.') : (
        <div className="grid gap-4">
          {requests.map(r => (
            <div key={r.id} className="bg-white border border-green-100 p-6 rounded-[2rem] flex items-center justify-between">
              <div>
                <p className="text-[10px] font-black text-gray-400 uppercase tracking-widest mb-1">Send to {r.phone}</p>
                <p className="text-2xl font-black text-gray-900 leading-none">KSH {r.amount.toLocaleString()}</p>
                <p className="text-xs text-gray-500 mt-2 font-medium">Recipient: {r.user?.name}</p>
              </div>
              <div className="flex gap-2">
                <button onClick={() => handleAction(r.id, 'COMPLETE')} className="bg-gray-900 text-white px-6 py-3 rounded-xl font-bold text-xs uppercase">Mark Paid</button>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}

function FlashSaleManagement() {
  const [sales, setSales] = useState<any[]>([]);
  const fetchSales = async () => { const r = await GET('/api/admin/flash-sales/all'); setSales(r.data.sales); };
  useEffect(() => { fetchSales(); }, []);
  const handleAction = async (id: string, action: 'CANCEL') => {
    await PUT(`/api/admin/flash-sales/${id}/moderate`, { action });
    fetchSales();
  };
  return (
    <div className="space-y-6">
       <h2 className="text-2xl font-black">Active Flash Sales</h2>
       <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
         {sales.map(s => (
           <div key={s.id} className="bg-white border border-rose-100 p-5 rounded-[2.5rem] relative overflow-hidden group">
             <div className="flex items-center gap-4 mb-4">
               <div className="w-16 h-16 rounded-2xl bg-rose-50 overflow-hidden"><img src={s.bannerImage} className="w-full h-full object-cover"/></div>
               <div className="flex-1">
                 <p className="font-bold text-sm truncate">{s.product?.name}</p>
                 <p className="text-rose-600 font-black">KSH {s.flashPrice.toLocaleString()}</p>
               </div>
             </div>
             <button onClick={() => handleAction(s.id, 'CANCEL')} className="w-full py-3 bg-red-50 text-red-500 rounded-2xl font-black text-[10px] uppercase tracking-widest opacity-0 group-hover:opacity-100 transition-opacity">Abort Sale</button>
           </div>
         ))}
       </div>
    </div>
  );
}

function renderEmptySection(icon: string, text: string) {
  const Icon = icon === 'Store' ? Store : icon === 'ShieldCheck' ? ShieldCheck : icon === 'DollarSign' ? DollarSign : Database;
  return (
    <div className="py-20 bg-gray-50 border-2 border-dashed border-gray-200 rounded-[3rem] flex flex-col items-center justify-center text-center">
      <Icon className="w-12 h-12 text-gray-200 mb-4" />
      <p className="text-gray-400 font-bold uppercase tracking-widest text-xs">{text}</p>
    </div>
  );
}

function HousingModeration() {
  const [properties, setProperties] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);

  const fetchProperties = async () => {
    setLoading(true);
    try {
      const res = await GET('/api/properties');
      setProperties(res.data.properties);
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchProperties();
  }, []);

  const handleModerate = async (id: string, status: string, verified: boolean) => {
    try {
      await PUT(`/api/admin/properties/${id}/moderate`, { status, verified });
      fetchProperties();
    } catch (err) {
      console.error(err);
    }
  };

  return (
    <div className="space-y-8 animate-in fade-in slide-in-from-bottom-4 duration-700">
      <div className="flex justify-between items-end">
        <div>
          <h1 className="text-3xl font-black text-gray-900 tracking-tight flex items-center gap-3">
            <Home className="w-8 h-8 text-pink-500" /> Housing Moderation
          </h1>
          <p className="text-gray-500 mt-2">Approve listings, verify locations, and manage global inventory.</p>
        </div>
        <div className="flex bg-white border border-pink-100 rounded-2xl p-1 shadow-sm">
           <button className="px-4 py-2 bg-pink-500 text-white rounded-xl text-xs font-bold shadow-lg">Pending Review</button>
           <button className="px-4 py-2 text-gray-500 text-xs font-bold hover:bg-gray-50 rounded-xl">All Listings</button>
        </div>
      </div>

      {loading ? (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {[1, 2, 3, 4].map(i => <div key={i} className="h-64 bg-pink-50 rounded-[2.5rem] animate-pulse"></div>)}
        </div>
      ) : properties.length === 0 ? (
        <div className="bg-pink-50 border border-pink-200 rounded-[3rem] p-20 flex flex-col items-center justify-center text-center">
           <div className="w-20 h-20 bg-pink-100 rounded-[2rem] flex items-center justify-center mb-6">
             <ShieldCheck className="w-10 h-10 text-pink-500" />
           </div>
           <h3 className="text-2xl font-black text-gray-900 mb-2">Queue and Clear</h3>
           <p className="text-gray-500 max-w-sm">No properties require moderation at this time. All campus homes are verified.</p>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {properties.map(p => (
            <div key={p.id} className="bg-white border border-pink-100 rounded-[2.5rem] overflow-hidden shadow-sm hover:shadow-xl transition-all group p-4">
              <div className="relative aspect-[16/9] rounded-[2rem] overflow-hidden mb-4">
                 <img src={p.images?.[0]?.url} className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-700" />
                 <div className="absolute top-4 left-4 flex gap-2">
                    <span className={`px-3 py-1 rounded-full text-[10px] font-black shadow-lg border ${p.verified ? 'bg-emerald-500 text-white border-emerald-400' : 'bg-amber-500 text-white border-amber-400'}`}>
                      {p.verified ? 'VERIFIED' : 'PENDING GEO-SCAN'}
                    </span>
                 </div>
              </div>

              <div className="px-2">
                <div className="flex justify-between items-start mb-2">
                  <h3 className="font-bold text-gray-900 uppercase tracking-tight">{p.title}</h3>
                  <span className="font-black text-pink-500">KSH {p.price.toLocaleString()}</span>
                </div>
                
                <div className="flex items-center gap-2 text-gray-400 text-xs mb-4">
                   <MapPin className="w-3 h-3 text-pink-500" />
                   <span className="font-medium truncate">{p.address} • {p.campus}</span>
                </div>

                {p.lat && p.lng && (
                  <div className="mb-4 rounded-2xl overflow-hidden border border-pink-100 h-24">
                     <MapView center={[p.lat, p.lng]} zoom={15} height="100px" markers={[{ id: p.id, lat: p.lat, lng: p.lng, title: p.title, type: 'PROPERTY' }]} />
                  </div>
                )}

                <div className="bg-gray-50 rounded-2xl p-4 mb-4 grid grid-cols-2 gap-2">
                  <div className="flex items-center gap-2">
                    <History className="w-3.5 h-3.5 text-gray-400" />
                    <span className="text-[10px] font-bold text-gray-500 truncate">POSTED: {new Date(p.createdAt).toLocaleDateString()}</span>
                  </div>
                  <div className="flex items-center gap-2 justify-end">
                    <Users className="w-3.5 h-3.5 text-gray-400" />
                    <span className="text-[10px] font-bold text-gray-500 uppercase">{p.type}</span>
                  </div>
                </div>

                <div className="flex gap-2">
                  {!p.verified && (
                    <button 
                      onClick={() => handleModerate(p.id, 'AVAILABLE', true)}
                      className="flex-1 bg-emerald-500 text-white py-3 rounded-2xl font-black text-[10px] uppercase tracking-widest flex items-center justify-center gap-2 shadow-lg hover:bg-emerald-600 transition-colors"
                    >
                      <CheckCircle className="w-4 h-4" /> Approve & Verify
                    </button>
                  )}
                  <button 
                    onClick={() => handleModerate(p.id, 'OCCUPIED', p.verified)}
                    className="flex-1 border border-pink-200 text-pink-500 py-3 rounded-2xl font-black text-[10px] uppercase tracking-widest flex items-center justify-center gap-2 hover:bg-pink-50 transition-colors"
                  >
                    <XCircle className="w-4 h-4" /> Reject/Hide
                  </button>
                </div>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}

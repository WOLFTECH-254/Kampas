import React, { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { Mail, Lock, ArrowRight, User, Phone, MapPin, AlertCircle, Map as MapIcon, CheckCircle2 } from 'lucide-react';
import { useAuth } from '../../context/AuthContext';
import { useLocation } from '../../context/LocationContext';

export default function SignUp() {
  const navigate   = useNavigate();
  const { signup } = useAuth();
  const { location, requestLocation, updateLocationOnServer } = useLocation();
  const [locationSuccess, setLocationSuccess] = useState(false);

  const [formData, setFormData] = useState({
    name: '', email: '', phone: '', campus: '', password: '', role: 'BUYER' as 'BUYER' | 'SELLER',
  });
  const [error,   setError]   = useState('');
  const [loading, setLoading] = useState(false);

  const handleRequestLocation = async () => {
    try {
      await requestLocation();
      setLocationSuccess(true);
      setTimeout(() => setLocationSuccess(false), 3000);
    } catch (err: any) {
      setError(err.message || 'Failed to capture location');
    }
  };

  const handleSignUp = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!location) {
      setError('Please verify your location to proceed.');
      return;
    }
    setError('');
    setLoading(true);
    try {
      await signup(formData);
      await updateLocationOnServer(location);
      navigate('/explore');
    } catch (err: any) {
      setError(err.message || 'Signup failed. Please try again.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-white text-gray-900 flex items-center justify-center p-4 relative overflow-hidden py-12">
      <div className="absolute top-0 left-0 w-full h-full bg-[url('https://www.transparenttextures.com/patterns/carbon-fibre.png')] opacity-20 pointer-events-none"></div>
      <div className="absolute top-1/4 right-0 w-[500px] h-[500px] bg-pink-500/10 rounded-full blur-[120px] pointer-events-none"></div>

      <div className="w-full max-w-lg bg-pink-50 border border-pink-200 rounded-3xl p-8 md:p-10 relative z-10 shadow-2xl">
        <div className="text-center mb-8">
          <Link to="/" className="inline-flex items-center gap-2 mb-6">
            <div className="w-10 h-10 rounded-xl bg-pink-500 flex items-center justify-center font-bold text-gray-900 text-2xl leading-none">K</div>
          </Link>
          <h1 className="text-2xl font-bold mb-2">Create Your Kampas Profile</h1>
          <p className="text-gray-600 text-sm">Join the ultimate student ecosystem today.</p>
        </div>

        {error && (
          <div className="mb-4 p-3 bg-red-50 border border-red-200 rounded-xl flex items-center gap-2 text-red-600 text-sm">
            <AlertCircle className="w-4 h-4 flex-shrink-0" />
            {error}
          </div>
        )}

        {locationSuccess && (
          <div className="mb-4 p-3 bg-emerald-50 border border-emerald-200 rounded-xl flex items-center gap-2 text-emerald-600 text-sm animate-bounce">
            <CheckCircle2 className="w-4 h-4 flex-shrink-0" />
            Nearby Experiences Activated
          </div>
        )}

        <form onSubmit={handleSignUp} className="space-y-4">
          {/* Role selector */}
          <div>
            <label className="block text-xs font-semibold text-gray-600 uppercase tracking-wider mb-2">I want to</label>
            <div className="grid grid-cols-2 gap-3">
              {(['BUYER', 'SELLER'] as const).map(r => (
                <button key={r} type="button" onClick={() => setFormData({ ...formData, role: r })}
                  className={`py-2.5 rounded-xl text-sm font-semibold border transition-all ${formData.role === r ? 'bg-pink-500 border-pink-500 text-white' : 'bg-white border-pink-200 text-gray-700 hover:border-pink-400'}`}>
                  {r === 'BUYER' ? '🛍️ Buy Items' : '🏪 Sell Items'}
                </button>
              ))}
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-semibold text-gray-600 uppercase tracking-wider mb-2">Full Name</label>
              <div className="relative">
                <User className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-500" />
                <input type="text" value={formData.name} onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                  placeholder="BRANDON JUNIOR" required
                  className="w-full bg-white border border-pink-200 rounded-xl py-3 pl-10 pr-4 text-sm focus:outline-none focus:border-pink-500 transition-colors placeholder:text-gray-600" />
              </div>
            </div>
            <div>
              <label className="block text-xs font-semibold text-gray-600 uppercase tracking-wider mb-2">Phone Number</label>
              <div className="relative">
                <Phone className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-500" />
                <input type="tel" value={formData.phone} onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                  placeholder="07XX XXX XXX" required
                  className="w-full bg-white border border-pink-200 rounded-xl py-3 pl-10 pr-4 text-sm focus:outline-none focus:border-pink-500 transition-colors placeholder:text-gray-600" />
              </div>
            </div>
          </div>

          <div>
            <label className="block text-xs font-semibold text-gray-600 uppercase tracking-wider mb-2">Email Address</label>
            <div className="relative">
              <Mail className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-500" />
              <input type="email" value={formData.email} onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                placeholder="name@email.com" required
                className="w-full bg-white border border-pink-200 rounded-xl py-3 pl-10 pr-4 text-sm focus:outline-none focus:border-pink-500 transition-colors placeholder:text-gray-600" />
            </div>
          </div>

          <div>
            <label className="block text-xs font-semibold text-gray-600 uppercase tracking-wider mb-2">Campus / Location</label>
            <div className="relative">
              <MapPin className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-500" />
              <input type="text" value={formData.campus} onChange={(e) => setFormData({ ...formData, campus: e.target.value })}
                placeholder="E.g. EGERTON Main Campus" required
                className="w-full bg-white border border-pink-200 rounded-xl py-3 pl-10 pr-4 text-sm focus:outline-none focus:border-pink-500 transition-colors placeholder:text-gray-600" />
            </div>
          </div>

          <div>
            <label className="block text-xs font-semibold text-gray-600 uppercase tracking-wider mb-2">Password</label>
            <div className="relative">
              <Lock className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-500" />
              <input type="password" value={formData.password} onChange={(e) => setFormData({ ...formData, password: e.target.value })}
                placeholder="••••••••" required
                className="w-full bg-white border border-pink-200 rounded-xl py-3 pl-10 pr-4 text-sm focus:outline-none focus:border-pink-500 transition-colors placeholder:text-gray-600" />
            </div>
          </div>

          <div>
            <label className="block text-xs font-semibold text-gray-600 uppercase tracking-wider mb-2">Location Verification (Mandatory)</label>
            <div className={`p-4 rounded-xl border flex items-center justify-between transition-all ${
              location ? 'bg-emerald-50 border-emerald-200' : 'bg-white border-pink-200 hover:border-pink-400'
            }`}>
              <div className="flex items-center gap-3">
                <div className={`w-8 h-8 rounded-lg flex items-center justify-center ${location ? 'bg-emerald-500 text-white' : 'bg-pink-100 text-pink-500'}`}>
                  {location ? <CheckCircle2 className="w-5 h-5" /> : <MapIcon className="w-5 h-5" />}
                </div>
                <div>
                  <p className="text-sm font-bold text-gray-800">{location ? 'Location Verified' : 'Verify Location'}</p>
                  <p className="text-[10px] text-gray-500">
                    {location ? `${location.lat.toFixed(4)}, ${location.lng.toFixed(4)}` : 'Campus GPS coordinates required'}
                  </p>
                </div>
              </div>
              {!location && (
                <button type="button" onClick={handleRequestLocation}
                  className="bg-pink-500 text-gray-900 text-[10px] font-black px-3 py-1.5 rounded-lg hover:bg-pink-600 transition-all uppercase tracking-wider">
                  Verify Now
                </button>
              )}
            </div>
          </div>

          <button type="submit" disabled={loading}
            className="w-full bg-pink-500 text-gray-900 font-bold py-3 mt-6 rounded-xl hover:bg-pink-600 transition-all shadow-[0_0_15px_rgba(236,72,153,0.2)] hover:shadow-[0_0_25px_rgba(236,72,153,0.4)] flex items-center justify-center gap-2 group disabled:opacity-60 disabled:cursor-not-allowed">
            {loading ? 'Creating profile...' : (<>Create Profile <ArrowRight className="w-5 h-5 group-hover:translate-x-1 transition-transform" /></>)}
          </button>
        </form>

        <div className="mt-8 text-center text-sm text-gray-600">
          Already have an account? <Link to="/login" className="text-pink-600 hover:text-pink-700 font-semibold ml-1">Log In</Link>
        </div>
      </div>
    </div>
  );
}

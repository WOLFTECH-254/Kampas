import React, { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { Mail, Lock, ArrowRight, AlertCircle, Map as MapIcon, CheckCircle2 } from 'lucide-react';
import { useAuth } from '../../context/AuthContext';
import { useLocation } from '../../context/LocationContext';

export default function Login() {
  const navigate  = useNavigate();
  const { login } = useAuth();
  const { location, requestLocation, updateLocationOnServer } = useLocation();
  const [locationSuccess, setLocationSuccess] = useState(false);

  const [email,    setEmail]    = useState('');
  const [password, setPassword] = useState('');
  const [error,    setError]    = useState('');
  const [loading,  setLoading]  = useState(false);

  const handleRequestLocation = async () => {
    try {
      await requestLocation();
      setLocationSuccess(true);
      setTimeout(() => setLocationSuccess(false), 3000);
    } catch (err: any) {
      setError(err.message || 'Failed to capture location');
    }
  };

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!location) {
      setError('Please verify your location to proceed.');
      return;
    }
    setError('');
    setLoading(true);

    try {
      await login(email, password);
      await updateLocationOnServer(location);
      // Route based on role
      const stored = localStorage.getItem('kampas_token');
      if (stored) {
        const payload = JSON.parse(atob(stored.split('.')[1]));
        if (payload.role === 'ADMIN') navigate('/admin');
        else if (payload.role === 'SELLER') navigate('/dashboard/seller');
        else navigate('/explore');
      }
    } catch (err: any) {
      setError(err.message || 'Login failed. Please try again.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-white text-gray-900 flex items-center justify-center p-4 relative overflow-hidden">
      <div className="absolute top-0 left-0 w-full h-full bg-[url('https://www.transparenttextures.com/patterns/carbon-fibre.png')] opacity-20 pointer-events-none"></div>
      <div className="absolute top-1/4 -left-32 w-96 h-96 bg-pink-500/10 rounded-full blur-[100px] pointer-events-none"></div>
      <div className="absolute bottom-1/4 -right-32 w-96 h-96 bg-pink-600/5 rounded-full blur-[100px] pointer-events-none"></div>

      <div className="w-full max-w-md bg-pink-50 border border-pink-200 rounded-3xl p-8 relative z-10 shadow-2xl">
        <div className="text-center mb-8">
          <Link to="/" className="inline-flex items-center gap-2 mb-6">
            <div className="w-10 h-10 rounded-xl bg-pink-500 flex items-center justify-center font-bold text-gray-900 text-2xl leading-none">K</div>
          </Link>
          <h1 className="text-2xl font-bold mb-2">Welcome Back to Kampas</h1>
          <p className="text-gray-600 text-sm">Enter your details to access your dashboard.</p>
        </div>

        {error && (
          <div className="mb-4 p-3 bg-red-50 border border-red-200 rounded-xl flex items-center gap-2 text-red-600 text-sm">
            <AlertCircle className="w-4 h-4 flex-shrink-0" />
            {error}
          </div>
        )}

        {locationSuccess && (
          <div className="mb-4 p-3 bg-emerald-50 border border-emerald-200 rounded-xl flex items-center gap-2 text-emerald-600 text-sm animate-bounce">
            <CheckCircle2 className="w-4 h-4 flex-shrink-0" />
            Nearby Experiences Activated
          </div>
        )}

        <form onSubmit={handleLogin} className="space-y-4">
          <div>
            <label className="block text-xs font-semibold text-gray-600 uppercase tracking-wider mb-2">Email Address</label>
            <div className="relative">
              <Mail className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-500" />
              <input
                type="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="student@university.ac.ke"
                required
                className="w-full bg-white border border-pink-200 rounded-xl py-3 pl-10 pr-4 text-sm focus:outline-none focus:border-pink-500 transition-colors placeholder:text-gray-600"
              />
            </div>
          </div>

          <div>
            <div className="flex items-center justify-between mb-2">
              <label className="block text-xs font-semibold text-gray-600 uppercase tracking-wider">Password</label>
              <Link to="/forgot-password" university-ac-ke className="text-xs text-pink-600 hover:text-pink-700 font-medium">Forgot Password?</Link>
            </div>
            <div className="relative">
              <Lock className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-500" />
              <input
                type="password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                placeholder="••••••••"
                required
                className="w-full bg-white border border-pink-200 rounded-xl py-3 pl-10 pr-4 text-sm focus:outline-none focus:border-pink-500 transition-colors placeholder:text-gray-600"
              />
            </div>
          </div>

          <div className="mb-4">
            <label className="block text-xs font-semibold text-gray-600 uppercase tracking-wider mb-2">Login Verification (Mandatory)</label>
            <div className={`p-4 rounded-xl border flex items-center justify-between transition-all ${
              location ? 'bg-emerald-50 border-emerald-200' : 'bg-white border-pink-200 hover:border-pink-400'
            }`}>
              <div className="flex items-center gap-3">
                <div className={`w-8 h-8 rounded-lg flex items-center justify-center ${location ? 'bg-emerald-500 text-white' : 'bg-pink-100 text-pink-500'}`}>
                  {location ? <CheckCircle2 className="w-5 h-5" /> : <MapIcon className="w-5 h-5" />}
                </div>
                <div>
                  <p className="text-sm font-bold text-gray-800">{location ? 'Location Verified' : 'Verify Location'}</p>
                  <p className="text-[10px] text-gray-500">
                    {location ? `${location.lat.toFixed(4)}, ${location.lng.toFixed(4)}` : 'Campus access requires GPS'}
                  </p>
                </div>
              </div>
              {!location && (
                <button type="button" onClick={handleRequestLocation}
                  className="bg-pink-500 text-gray-900 text-[10px] font-black px-3 py-1.5 rounded-lg hover:bg-pink-600 transition-all uppercase tracking-wider">
                  Verify
                </button>
              )}
            </div>
          </div>

          <button
            type="submit"
            disabled={loading}
            className="w-full bg-pink-500 text-gray-900 font-bold py-3 mt-4 rounded-xl hover:bg-pink-600 transition-all shadow-[0_0_15px_rgba(236,72,153,0.2)] hover:shadow-[0_0_25px_rgba(236,72,153,0.4)] flex items-center justify-center gap-2 group disabled:opacity-60 disabled:cursor-not-allowed"
          >
            {loading ? 'Logging in...' : (<>Log In to Dashboard <ArrowRight className="w-5 h-5 group-hover:translate-x-1 transition-transform" /></>)}
          </button>
        </form>

        <div className="mt-8 text-center text-sm text-gray-600">
          Don't have an account? <Link to="/signup" className="text-pink-600 hover:text-pink-700 font-semibold ml-1">Sign Up</Link>
        </div>
      </div>
    </div>
  );
}

import React, { useState, useEffect, useRef, useMemo } from 'react';
import { Send, MapPin, Info, Sparkles, MessageSquare, Clock } from 'lucide-react';
import { socket } from '../lib/socket';
import { useAuth } from '../context/AuthContext';

interface Message {
  id: number;
  text: string;
  senderId: string;
  timestamp: string;
}

export default function Chats() {
  const { user } = useAuth();
  const isSeller = user?.role === 'SELLER';
  
  const [messages, setMessages] = useState<Message[]>([]);
  const [messageText, setMessageText] = useState('');
  const [isPeerOnline, setIsPeerOnline] = useState(true);
  const [lastSeen, setLastSeen] = useState('Today, 2:45 PM');
  const messagesEndRef = useRef<HTMLDivElement>(null);

  // Guidance logic
  const guidance = useMemo(() => {
    if (!isSeller) return null;
    
    // Find the last message from the buyer
    const lastBuyerMsg = [...messages].reverse().find(m => m.senderId !== socket.id);
    if (!lastBuyerMsg) return {
      title: 'Seller Reply Guide',
      tip: 'Always respond politely and professionally to buyers.'
    };

    const text = lastBuyerMsg.text.toLowerCase();
    if (text.includes('available') || text.includes('stock') || text.includes('have it')) {
      return { title: 'Availability Tip', tip: 'Confirm product availability clearly and mention if it\'s ready for pickup.' };
    }
    if (text.includes('price') || text.includes('cost') || text.includes('how much') || text.includes('negotiable')) {
      return { title: 'Pricing Tip', tip: 'State price accurately and mention if negotiable or fixed.' };
    }
    if (text.includes('deliver') || text.includes('pickup') || text.includes('meet') || text.includes('where')) {
      return { title: 'Logistics Tip', tip: 'Provide delivery or pickup details. Suggest safe campus meeting spots.' };
    }
    if (text.includes('!') || text.includes('rude') || text.includes('scam')) {
      return { title: 'Support Tip', tip: 'Stay calm and respectful. Professionalism wins trust even with tough buyers.' };
    }

    return {
      title: 'Seller Reply Guide',
      tip: 'Respond professionally. Mention product benefits to close the sale faster.'
    };
  }, [messages, isSeller]);

  useEffect(() => {
    socket.on('newMessage', (message: Message) => {
      setMessages((prev) => [...prev, message]);
      
      // Functional status: when we get a message, peer was just online
      if (message.senderId !== socket.id) {
        setIsPeerOnline(true);
        setLastSeen('Just now');
      }
    });

    // Simulate status fluctuation
    const interval = setInterval(() => {
      if (Math.random() > 0.8) {
        setIsPeerOnline(false);
        const now = new Date();
        setLastSeen(`Today, ${now.getHours()}:${now.getMinutes().toString().padStart(2, '0')}`);
      } else {
        setIsPeerOnline(true);
      }
    }, 15000);
    
    return () => {
      socket.off('newMessage');
      clearInterval(interval);
    };
  }, []);

  useEffect(() => {
    if (messagesEndRef.current) {
      messagesEndRef.current.scrollIntoView({ behavior: 'smooth' });
    }
  }, [messages]);

  const sendMessage = (e: React.FormEvent) => {
    e.preventDefault();
    if (!messageText.trim()) return;
    
    socket.emit('sendMessage', {
      text: messageText,
      senderId: socket.id
    });
    
    setMessageText('');
  };

  return (
    <div className="flex h-full max-h-[calc(100vh-4rem)] p-4 md:p-8 max-w-6xl mx-auto gap-6">
      {/* Sidebar - Chat List */}
      <div className="w-1/3 bg-pink-50 border border-pink-200 rounded-2xl p-4 hidden md:flex flex-col">
          <h2 className="text-xl font-bold mb-4">Messages</h2>
          <div className="space-y-4 overflow-y-auto">
             <div className="p-3 bg-white border-l-2 border-pink-500 rounded-lg flex items-center justify-between cursor-pointer">
               <div className="flex items-center gap-3">
                   <div className="w-10 h-10 bg-gray-200 rounded-full overflow-hidden flex-shrink-0">
                      <img src="https://images.unsplash.com/photo-1595950653106-6c9ebd614d3a?w=100&q=80" />
                   </div>
                   <div className="min-w-0">
                     <p className="font-semibold text-sm truncate">Drip Kings UoN</p>
                     <p className="text-xs text-gray-600 truncate">Are the Jordans still available?</p>
                   </div>
                </div>
                <div className="text-[10px] text-pink-600 flex-shrink-0 flex flex-col items-end">
                   <span>Now</span>
                   <span className="w-2 h-2 bg-pink-500 rounded-full mt-1"></span>
                </div>
             </div>
          </div>
      </div>
      
      {/* Main Chat Area */}
      <div className="flex-1 bg-pink-50 border border-pink-200 rounded-2xl flex flex-col h-[70vh] md:h-auto relative overflow-hidden">
        {/* Chat Header */}
        <div className="p-4 border-b border-pink-200 bg-white/50 flex items-center gap-4">
           <div className="w-10 h-10 bg-gray-200 rounded-full overflow-hidden flex-shrink-0 relative">
              <img src="https://images.unsplash.com/photo-1595950653106-6c9ebd614d3a?w=100&q=80" />
              {isPeerOnline && <div className="absolute bottom-0 right-0 w-3 h-3 bg-green-500 border-2 border-white rounded-full"></div>}
           </div>
           <div>
              <h2 className="font-bold flex items-center gap-2">Drip Kings UoN</h2>
              <div className="flex items-center gap-2">
                {isPeerOnline ? (
                   <p className="text-[10px] font-black text-green-600 bg-green-50 px-2 py-0.5 rounded-full uppercase tracking-widest flex items-center gap-1">
                     <span className="w-1.5 h-1.5 bg-green-500 rounded-full animate-pulse"></span> ONLINE
                   </p>
                ) : (
                   <p className="text-[10px] font-black text-gray-400 bg-gray-100 px-2 py-0.5 rounded-full uppercase tracking-widest">OFFLINE</p>
                )}
                <p className="text-[10px] text-gray-400 font-bold uppercase tracking-widest flex items-center gap-1">
                   <Clock className="w-2.5 h-2.5" /> Last seen: {lastSeen}
                </p>
              </div>
              <p className="text-[10px] text-gray-500 flex items-center gap-1 mt-0.5"><MapPin className="w-2.5 h-2.5 text-pink-500" /> UoN Main Campus • Product inquiry</p>
           </div>
        </div>

        {/* Chat Messages */}
        <div className="flex-1 overflow-y-auto p-4 space-y-4 bg-[url('https://www.transparenttextures.com/patterns/carbon-fibre.png')]">
          {messages.length === 0 ? (
             <div className="h-full flex items-center justify-center text-gray-400 text-xs font-bold uppercase tracking-widest">
                <div className="flex flex-col items-center gap-2">
                   <MessageSquare className="w-8 h-8 opacity-20" />
                   No messages yet
                </div>
             </div>
          ) : (
            messages.map((msg, i) => {
              const isMine = msg.senderId === socket.id;
              return (
                <div key={i} className={`flex ${isMine ? 'justify-end' : 'justify-start'}`}>
                  <div className={`max-w-[85%] md:max-w-[70%] p-3 rounded-2xl ${isMine ? 'bg-pink-500 text-white rounded-tr-sm shadow-sm' : 'bg-white border border-pink-100 text-gray-900 rounded-tl-sm shadow-sm'}`}>
                    <p className={`text-sm ${isMine ? 'font-medium' : ''}`}>{msg.text}</p>
                    <p className={`text-[9px] mt-1 text-right font-bold uppercase tracking-tighter ${isMine ? 'text-pink-100' : 'text-gray-400'}`}>
                      {new Date(msg.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                    </p>
                  </div>
                </div>
              );
            })
          )}
          <div ref={messagesEndRef} />
        </div>
        
        {/* Seller Reply Guidance Panel */}
        {isSeller && guidance && (
           <div className="mx-4 mb-2 p-3 bg-blue-50 border border-blue-100 rounded-2xl flex items-start gap-3 shadow-sm animate-in slide-in-from-bottom-2 duration-300">
              <div className="w-8 h-8 rounded-full bg-blue-100 flex items-center justify-center flex-shrink-0">
                 <Sparkles className="w-4 h-4 text-blue-600" />
              </div>
              <div className="flex-1 min-w-0">
                 <div className="flex items-center justify-between mb-0.5">
                    <p className="text-[10px] font-black text-blue-900 uppercase tracking-widest">AI {guidance.title}</p>
                    <Info className="w-3 h-3 text-blue-300" />
                 </div>
                 <p className="text-xs text-blue-700 font-medium leading-tight">
                    {guidance.tip}
                 </p>
              </div>
           </div>
        )}
        
        {/* Chat Input */}
        <form onSubmit={sendMessage} className="p-4 bg-white border-t border-pink-200 flex items-center gap-2">
           <input 
             type="text" 
             value={messageText} 
             onChange={(e) => setMessageText(e.target.value)}
             placeholder="Type a message..." 
             className="flex-1 bg-pink-50 border border-pink-200 rounded-full px-4 py-3 text-sm focus:outline-none focus:border-pink-500 transition-colors"
           />
           <button 
             type="submit" 
             disabled={!messageText.trim()}
             className="w-12 h-12 rounded-full bg-pink-500 text-gray-900 flex items-center justify-center hover:bg-pink-600 disabled:opacity-50 disabled:hover:bg-pink-500 transition-colors flex-shrink-0"
           >
              <Send className="w-5 h-5 ml-1" />
           </button>
        </form>
      </div>
    </div>
  );
}

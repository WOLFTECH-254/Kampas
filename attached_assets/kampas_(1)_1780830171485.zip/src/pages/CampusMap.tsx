import React, { useState, useEffect } from 'react';
import MapView, { MapViewType } from '../components/MapView';
import { useLocation } from '../context/LocationContext';
import { GET } from '../lib/api';
import { Search, MapPin, Navigation, ShoppingBag, Calendar, Home, Sparkles, Layers, Map as MapIcon, ChevronRight, Globe, Box, Compass, TrendingUp } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { getAiRecommendations, Recommendation } from '../lib/recommendations';

export default function CampusMap() {
  const { location } = useLocation();
  const [items, setItems] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [selectedItem, setSelectedItem] = useState<any>(null);
  const [provider, setProvider] = useState<'OSM' | 'GOOGLE'>('OSM');
  const [viewType, setViewType] = useState<MapViewType>('STREET');
  const [tilt, setTilt] = useState(0);
  const [filter, setFilter] = useState<'ALL' | 'PRODUCT' | 'EVENT' | 'PROPERTY'>('ALL');
  const [aiRecs, setAiRecs] = useState<Recommendation[]>([]);
  const [showRecs, setShowRecs] = useState(false);

  const fetchItems = async () => {
    setLoading(true);
    try {
      const [productsRes, eventsRes, propertiesRes] = await Promise.all([
        GET('/api/products'),
        GET('/api/events'),
        GET('/api/properties')
      ]);
      const allItems = [
        ...productsRes.data.products.map((p: any) => ({ ...p, type: 'PRODUCT' })),
        ...eventsRes.data.events.map((e: any) => ({ ...e, type: 'EVENT' })),
        ...propertiesRes.data.properties.map((h: any) => ({ ...h, type: 'PROPERTY' }))
      ];
      setItems(allItems);

      // Enhanced AI Recommendations
      const recommendations = await getAiRecommendations({
        location,
        campus: 'JKUAT', // Hardcoded for demo, would be from user profile
        category: 'ALL'
      });
      setAiRecs(recommendations);

    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchItems();
  }, []);

  const filteredItems = filter === 'ALL' ? items : items.filter(i => i.type === filter);

  const markers = [
    ...(location ? [{ id: 'user', lat: location.lat, lng: location.lng, title: 'You Are Here', type: 'USER' as const }] : []),
    ...filteredItems.filter(i => i.lat && i.lng).map(i => ({
      id: i.id,
      lat: i.lat,
      lng: i.lng,
      title: i.title,
      type: i.type as any,
      data: i
    }))
  ];

  return (
    <div className="h-[calc(100vh-4rem)] md:h-screen flex flex-col relative bg-white overflow-hidden">
      {/* Dynamic Map Layer */}
      <div className="flex-1">
        <MapView 
          provider={provider}
          viewType={viewType}
          tilt={tilt}
          markers={markers} 
          height="100%" 
          center={location ? [location.lat, location.lng] : [-1.286389, 36.817223]}
          zoom={15}
          onMarkerClick={(m) => m.type !== 'USER' && setSelectedItem(m.data || m)}
        />
      </div>

      {/* Primary Discovery Hub Overlay */}
      <div className="absolute top-4 left-4 right-4 z-[1001] max-w-lg md:left-6 md:right-auto md:w-96 space-y-4">
        <div className="bg-white/95 backdrop-blur-xl rounded-[2.5rem] shadow-[0_20px_50px_rgba(0,0,0,0.15)] border border-white p-6">
          <div className="flex justify-between items-start mb-6">
            <div className="flex items-center gap-3">
              <div className="w-12 h-12 rounded-[1.5rem] bg-gray-900 flex items-center justify-center text-white shadow-xl rotate-3">
                <MapPin className="w-6 h-6" />
              </div>
              <div>
                <h1 className="text-sm font-black text-gray-900 leading-tight uppercase tracking-tight">KAMPAS RADIUS</h1>
                <p className="text-[9px] text-pink-500 font-black uppercase tracking-[0.2em] mt-1">Unified Discovery</p>
              </div>
            </div>
            <div className="flex gap-2">
               <button onClick={() => setShowRecs(!showRecs)} className={`p-3 rounded-xl transition-all ${showRecs ? 'bg-pink-500 text-gray-900' : 'bg-gray-100 text-gray-400 opacity-50'}`}>
                 <Sparkles className="w-4 h-4" />
               </button>
               <div className="hidden sm:flex bg-gray-100 p-1 rounded-xl border border-gray-200">
                  <button onClick={() => setProvider('OSM')} className={`px-3 py-1.5 rounded-lg text-[9px] font-black uppercase transition-all ${provider === 'OSM' ? 'bg-white text-gray-900 shadow-sm' : 'text-gray-400 opacity-50'}`}>OSM</button>
                  <button onClick={() => setProvider('GOOGLE')} className={`px-3 py-1.5 rounded-lg text-[9px] font-black uppercase transition-all ${provider === 'GOOGLE' ? 'bg-white text-gray-900 shadow-sm' : 'text-gray-400 opacity-50'}`}>Google</button>
               </div>
            </div>
          </div>

          <div className="relative mb-6">
            <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
            <input type="text" placeholder="Search sellers, homes, events..." className="w-full bg-gray-50 border border-gray-100 rounded-2xl py-4 pl-12 pr-4 text-xs font-medium focus:outline-none focus:border-pink-500 transition-all shadow-inner" />
          </div>

          <div className="flex gap-2 overflow-x-auto scrollbar-hide py-1">
             <FilterBtn active={filter === 'ALL'} onClick={() => setFilter('ALL')} label="All" />
             <FilterBtn active={filter === 'PROPERTY'} onClick={() => setFilter('PROPERTY')} label="Housing" icon={Home} />
             <FilterBtn active={filter === 'EVENT'} onClick={() => setFilter('EVENT')} label="Events" icon={Calendar} />
             <FilterBtn active={filter === 'PRODUCT'} onClick={() => setFilter('PRODUCT')} label="Sellers" icon={ShoppingBag} />
          </div>
        </div>

        {/* AI Recommendations */}
        <AnimatePresence>
          {showRecs && (
            <motion.div 
              initial={{ opacity: 0, y: -20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -20 }}
              className="bg-gray-900/95 backdrop-blur-xl rounded-[2rem] p-6 text-white shadow-2xl border border-gray-800 max-h-[50vh] overflow-y-auto scrollbar-hide"
            >
              <div className="flex items-center justify-between mb-5">
                <div className="flex items-center gap-2">
                  <Sparkles className="w-4 h-4 text-pink-500 animate-pulse" />
                  <h2 className="text-[10px] font-black uppercase tracking-widest text-gray-400">AI Local Pulse</h2>
                </div>
                <div className="flex items-center gap-2 text-[8px] font-bold text-emerald-500 bg-emerald-500/10 px-2 py-1 rounded-full uppercase tracking-tighter">
                  <TrendingUp className="w-3 h-3" /> Trending Near You
                </div>
              </div>
              <div className="space-y-4">
                 {aiRecs.map((rec) => (
                   <button key={`${rec.type}-${rec.id}`} onClick={() => setSelectedItem(rec)} className="w-full flex items-center gap-4 p-2 rounded-2xl hover:bg-white/5 transition-all group border border-transparent hover:border-white/10">
                     <div className="w-12 h-12 rounded-xl overflow-hidden border-2 border-white/10 flex-shrink-0">
                        <img src={rec.image} className="w-full h-full object-cover group-hover:scale-110 transition-transform" />
                     </div>
                     <div className="flex-1 text-left min-w-0">
                        <p className="text-[11px] font-bold text-white truncate">{rec.title}</p>
                        <p className="text-[9px] text-gray-500 font-bold uppercase tracking-tight mt-1">
                          {rec.type} • {rec.distance ? `${(rec.distance / 1000).toFixed(1)}km` : rec.campus}
                        </p>
                     </div>
                     <ChevronRight className="w-4 h-4 text-gray-700 group-hover:text-pink-500 transition-colors" />
                   </button>
                 ))}
                 {aiRecs.length === 0 && (
                   <div className="text-center py-10">
                     <p className="text-xs text-gray-500">Discovering local hotspots...</p>
                   </div>
                 )}
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </div>

      {/* Control Tools (Right Side) */}
      <div className="absolute bottom-24 right-4 md:top-6 md:right-6 z-[1001] flex flex-col gap-4">
         <div className="bg-white/95 backdrop-blur-xl rounded-[2rem] p-2 shadow-2xl border border-white flex flex-row md:flex-col gap-2">
            <ViewToggleBtn active={viewType === 'STREET'} onClick={() => setViewType('STREET')} icon={MapIcon} label="Standard" />
            <ViewToggleBtn active={viewType === 'SATELLITE'} onClick={() => setViewType('SATELLITE')} icon={Globe} label="Satellite Map" />
            <ViewToggleBtn active={tilt > 0} onClick={() => setTilt(tilt > 0 ? 0 : 45)} icon={Box} label={tilt > 0 ? "2D Mode" : "3D Perspective"} />
         </div>

         {location && (
           <div className="hidden md:flex bg-white/95 rounded-2xl p-4 shadow-2xl border border-white items-center gap-3">
              <div className="w-10 h-10 rounded-full bg-pink-500 flex items-center justify-center text-white shadow-lg animate-bounce">
                <Navigation className="w-5 h-5 fill-current" />
              </div>
              <div>
                <p className="text-[8px] font-black text-gray-400 uppercase tracking-widest">Active Radar</p>
                <p className="text-[10px] font-bold text-gray-900">JKUAT Main Campus</p>
              </div>
           </div>
         )}
      </div>

      {/* Footer Navigation Utilities */}
      <div className="absolute bottom-8 left-4 md:left-8 z-[1001] flex items-center gap-4">
          <MapUtilBtn icon={Layers} label="Smart Clustering" active={true} />
          <MapUtilBtn icon={Compass} label="Auto Bearing" active={false} />
      </div>

      {/* Details Slide-In */}
      <AnimatePresence>
        {selectedItem && (
          <motion.div initial={{ x: 400, opacity: 0 }} animate={{ x: 0, opacity: 1 }} exit={{ x: 400, opacity: 0 }} className="absolute inset-y-0 right-0 w-full md:w-[450px] bg-white shadow-[-20px_0_50px_rgba(0,0,0,0.1)] z-[2000] border-l border-gray-100 flex flex-col overflow-hidden">
             <div className="relative h-[40vh]">
                <img src={selectedItem.images?.[0]?.url || selectedItem.image} className="w-full h-full object-cover" />
                <button onClick={() => setSelectedItem(null)} className="absolute top-6 right-6 w-12 h-12 bg-white/20 backdrop-blur-md rounded-full flex items-center justify-center text-white hover:bg-white/40 transition-all border border-white/50">
                  <X className="w-6 h-6" />
                </button>
             </div>
             <div className="p-8 flex-1 overflow-y-auto">
                <div className="flex items-center gap-3 mb-4">
                  <span className="px-3 py-1 bg-pink-100 text-pink-600 rounded-full text-[10px] font-black uppercase tracking-widest">{selectedItem.type}</span>
                  {selectedItem.verified && <span className="px-3 py-1 bg-emerald-100 text-emerald-600 rounded-full text-[10px] font-black uppercase tracking-widest">Verified</span>}
                </div>
                <h2 className="text-3xl font-black text-gray-900 leading-tight mb-4 tracking-tight">{selectedItem.title}</h2>
                <div className="flex items-center gap-2 text-gray-400 mb-8">
                  <MapPin className="w-5 h-5 text-pink-500" />
                  <span className="text-sm font-bold uppercase tracking-widest leading-none">{selectedItem.campus}</span>
                </div>

                <div className="bg-pink-50 rounded-[2rem] p-6 mb-8 border border-pink-100 flex justify-between items-center">
                  <div>
                    <p className="text-[10px] font-black text-pink-400 uppercase tracking-widest mb-1">Price Point</p>
                    <p className="text-3xl font-black text-gray-900">KSH {selectedItem.price?.toLocaleString() || 'FREE'}</p>
                  </div>
                  <button className="bg-gray-900 text-white px-8 py-4 rounded-2xl font-black text-[10px] uppercase tracking-widest hover:bg-pink-600 transition-all shadow-xl">Contact</button>
                </div>

                <p className="text-gray-500 leading-relaxed font-medium mb-8">
                  {selectedItem.description || 'No detailed description provided for this listing yet. Visit the location for more details.'}
                </p>

                <div className="grid grid-cols-2 gap-4">
                   <button onClick={() => {
                        const url = `https://www.google.com/maps/dir/?api=1&destination=${selectedItem.lat},${selectedItem.lng}`;
                        window.open(url, '_blank');
                    }} className="flex items-center justify-center gap-3 bg-gray-100 py-5 rounded-2xl font-black text-[10px] uppercase tracking-widest hover:bg-gray-200 transition-all">
                     <Navigation className="w-4 h-4" /> Directions
                   </button>
                   <button className="flex items-center justify-center gap-3 bg-gray-100 py-5 rounded-2xl font-black text-[10px] uppercase tracking-widest hover:bg-gray-200 transition-all">
                     <Heart className="w-4 h-4" /> Wishlist
                   </button>
                </div>
             </div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}

const FilterBtn = ({ active, onClick, label, icon: Icon }: any) => (
  <button onClick={onClick} className={`flex items-center gap-2 px-6 py-3 rounded-2xl text-[10px] font-black uppercase transition-all border ${active ? 'bg-pink-500 text-gray-900 border-pink-400 shadow-xl' : 'bg-white text-gray-400 border-gray-100 hover:border-pink-200'}`}>
    {Icon && <Icon className="w-4 h-4" />}
    {label}
  </button>
);

const ViewToggleBtn = ({ active, onClick, icon: Icon, label }: any) => (
  <button onClick={onClick} className={`w-12 h-12 rounded-2xl flex items-center justify-center transition-all group relative ${active ? 'bg-gray-900 text-pink-500 shadow-2xl scale-110' : 'text-gray-400 hover:bg-gray-50'}`}>
    <Icon className="w-6 h-6" />
    <span className="absolute right-full mr-4 px-3 py-2 bg-gray-900 text-white text-[10px] font-black uppercase tracking-widest rounded-xl opacity-0 group-hover:opacity-100 pointer-events-none transition-all scale-95 group-hover:scale-100 origin-right whitespace-nowrap shadow-2xl">{label}</span>
  </button>
);

const MapUtilBtn = ({ icon: Icon, label, active }: any) => (
  <div className="group relative flex items-center gap-3 cursor-pointer">
     <div className={`w-14 h-14 rounded-2xl flex items-center justify-center transition-all shadow-2xl border border-white/50 backdrop-blur-md ${active ? 'bg-gray-900 text-pink-500' : 'bg-white/80 text-gray-400 hover:text-pink-500'}`}>
        <Icon className="w-7 h-7" />
     </div>
     <div className="absolute left-full ml-4 opacity-0 group-hover:opacity-100 transition-all bg-gray-900 text-white text-[10px] font-black px-4 py-3 rounded-2xl whitespace-nowrap uppercase tracking-widest shadow-2xl scale-90 group-hover:scale-100 origin-left">{label}</div>
  </div>
);

const X = ({ className }: { className?: string }) => (
  <svg className={className} xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="3" strokeLinecap="round" strokeLinejoin="round"><line x1="18" y1="6" x2="6" y2="18"></line><line x1="6" y1="6" x2="18" y2="18"></line></svg>
);

const Heart = ({ className }: { className?: string }) => (
  <svg className={className} xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M19 14c1.49-1.46 3-3.21 3-5.5A5.5 5.5 0 0 0 16.5 3c-1.76 0-3 .5-4.5 2-1.5-1.5-2.74-2-4.5-2A5.5 5.5 0 0 0 2 8.5c0 2.3 1.5 4.05 3 5.5l7 7Z"></path></svg>
);

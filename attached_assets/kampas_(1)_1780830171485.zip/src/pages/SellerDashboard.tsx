
import {
  Package, TrendingUp, DollarSign, Users, ShoppingCart, Megaphone,
  Plus, LayoutDashboard, Store, Settings, Wallet, ArrowUpRight,
  Edit2, Trash2, ToggleLeft, ToggleRight, CheckCircle, XCircle,
  RefreshCw, AlertCircle, ChevronRight, Eye, EyeOff, LogOut,
  MapPin, Star, X, Save, Truck, Clock, ShoppingBag, Hammer, Zap, UserCheck, Info, Sparkles
} from 'lucide-react';
import { ResponsiveContainer, AreaChart, Area, XAxis, YAxis, Tooltip, CartesianGrid } from 'recharts';
import { useState, useEffect } from 'react';
import React from 'react';
import { useAuth } from '../context/AuthContext';
import { GET, POST, PUT, DEL } from '../lib/api';
import { useNavigate } from 'react-router-dom';
import ImageRefiner from '../components/ImageRefiner';

type Tab = 'overview' | 'products' | 'services' | 'orders' | 'wallet' | 'flash-sales' | 'business' | 'verification' | 'ads' | 'tos' | 'referrals';

const STATUS_FLOW: Record<string, string> = {
  ORDER_REQUESTED:  'CONFIRMED',
  PENDING:          'CONFIRMED',
  CONFIRMED:        'PROCESSING',
  PROCESSING:       'OUT_FOR_DELIVERY',
  OUT_FOR_DELIVERY: 'DELIVERED',
};

const STATUS_LABEL: Record<string, string> = {
  ORDER_REQUESTED:  'Confirm Request (COD)',
  PENDING:          'Confirm Order',
  CONFIRMED:        'Process',
  PROCESSING:       'Ship',
  OUT_FOR_DELIVERY: 'Mark Delivered',
  DELIVERED:        'Delivered',
  CANCELLED:        'Cancelled',
};

const STATUS_COLOR: Record<string, string> = {
  ORDER_REQUESTED:  'bg-orange-100 text-orange-700',
  PENDING:          'bg-yellow-100 text-yellow-700',
  CONFIRMED:        'bg-blue-100 text-blue-700',
  PROCESSING:       'bg-indigo-100 text-indigo-700',
  OUT_FOR_DELIVERY: 'bg-pink-100 text-pink-600',
  DELIVERED:        'bg-green-100 text-green-700',
  CANCELLED:        'bg-red-100 text-red-600',
};

const CONDITIONS = ['NEW', 'SLIGHTLY_USED', 'USED', 'THRIFTED'];

export default function SellerDashboard() {
  const { user, logout } = useAuth();
  const navigate = useNavigate();
  const [tab, setTab] = useState<Tab>('overview');

  // Analytics
  const [analytics,  setAnalytics]  = useState<any>(null);
  const [salesData,  setSalesData]  = useState<any[]>([]);
  const [loadingAna, setLoadingAna] = useState(true);

  // Products
  const [products,    setProducts]    = useState<any[]>([]);
  const [loadingProd, setLoadingProd] = useState(false);
  const [showProdForm,setShowProdForm]= useState(false);
  const [editProduct, setEditProduct] = useState<any>(null);
  const [prodForm,    setProdForm]    = useState({ name: '', description: '', price: '', originalPrice: '', campus: user?.campus || '', condition: 'NEW', stock: '1', isActive: true, images: [''] });
  const [savingProd,  setSavingProd]  = useState(false);

  // AI Image Lab States
  const [processingImg, setProcessingImg] = useState(false);
  const [aiAnalysis,    setAiAnalysis]    = useState<any>(null);
  const [viewProcessed, setViewProcessed] = useState(true);
  
  // New: Refinement Modal States
  const [showRefiner, setShowRefiner] = useState(false);
  const [refineMask, setRefineMask] = useState<string | null>(null); // base64 mask

  // Orders
  const [orders,     setOrders]     = useState<any[]>([]);
  const [orderFilter,setOrderFilter]= useState('');
  const [loadingOrd, setLoadingOrd] = useState(false);
  const [updatingOrd,setUpdatingOrd]= useState<string | null>(null);

  // Services
  const [services,     setServices]     = useState<any[]>([]);
  const [loadingServ,  setLoadingServ]  = useState(false);
  const [showServForm, setShowServForm] = useState(false);
  const [editService,  setEditService]  = useState<any>(null);
  const [serviceForm,  setServiceForm]  = useState({ name: '', category: 'Salon', description: '', price: '', location: '', contactNumber: user?.phone || '', email: user?.email || '', availabilitySchedule: 'Mon-Sat: 9am-6pm', images: [] as string[] });

  // Flash Sales
  const [flashSales,   setFlashSales]   = useState<any[]>([]);
  const [showFlashForm,setShowFlashForm]= useState(false);
  const [flashForm,    setFlashForm]    = useState({ productId: '', flashPrice: '', startTime: '', endTime: '', bannerImage: '' });

  // Verification
  const [verifying,    setVerifying]    = useState(false);

  // Business Info (merged from profile/store)
  const [businessForm, setBusinessForm] = useState({
    businessName: user?.businessName || '',
    businessDescription: user?.businessDescription || '',
    businessLogo: user?.businessLogo || '',
    businessContact: user?.businessContact || user?.phone || '',
    businessEmail: user?.businessEmail || user?.email || '',
    location: user?.location || user?.campus || '',
  });
  const [savingBusiness, setSavingBusiness] = useState(false);
  const [payoutPhone, setPayoutPhone] = useState(user?.phone || '');
  const [payoutAmt,   setPayoutAmt]   = useState('');
  const [payingOut,   setPayingOut]   = useState(false);
  const [payoutMsg,   setPayoutMsg]   = useState('');
  const [wallet,      setWallet]      = useState<any>(null);

  // Store
  const [store,      setStore]      = useState<any>(null);
  const [storeForm,  setStoreForm]  = useState<any>({});
  const [savingStore,setSavingStore]= useState(false);
  const [storeMsg,   setStoreMsg]   = useState('');

  // Ads
  const [ads,       setAds]       = useState<any[]>([]);
  const [adAnalytics,setAdAnalytics]=useState<any>(null);
  const [showAdForm, setShowAdForm]= useState(false);
  const [adForm,    setAdForm]    = useState({ title: '', description: '', targetCampus: '', budget: '' });
  const [savingAd,  setSavingAd]  = useState(false);

  // Referrals
  const [referralsData, setReferralsData] = useState<any>(null);
  const [loadingRef, setLoadingRef] = useState(false);
  const [copied, setCopied] = useState(false);
  const [hideBalance, setHideBalance] = useState(false);

  // Toast
  const [toast, setToast] = useState<{ msg: string; type: 'success' | 'error' } | null>(null);

  const showToast = (msg: string, type: 'success' | 'error' = 'success') => {
    setToast({ msg, type });
    setTimeout(() => setToast(null), 3500);
  };

  useEffect(() => { fetchAnalytics(); }, []);
  useEffect(() => { if (tab === 'products')    fetchProducts(); }, [tab]);
  useEffect(() => { if (tab === 'services')    fetchServices(); }, [tab]);
  useEffect(() => { if (tab === 'orders')      fetchOrders(); }, [tab, orderFilter]);
  useEffect(() => { if (tab === 'wallet')      fetchWallet(); }, [tab]);
  useEffect(() => { if (tab === 'flash-sales') fetchFlashSales(); }, [tab]);
  useEffect(() => { if (tab === 'ads')         fetchAds(); }, [tab]);
  useEffect(() => { if (tab === 'referrals')   fetchReferrals(); }, [tab]);

  const fetchAnalytics = async () => {
    setLoadingAna(true);
    try {
      const [anaRes, salesRes] = await Promise.all([
        GET('/api/seller/analytics'),
        GET('/api/seller/analytics/sales?days=7'),
      ]);
      setAnalytics(anaRes.data);
      setSalesData(salesRes.data.salesData);
    } catch (e) { console.error(e); }
    finally { setLoadingAna(false); }
  };

  const fetchServices = async () => {
    setLoadingServ(true);
    try { const r = await GET('/api/seller/services'); setServices(r.data.services); }
    catch (e) { console.error(e); } finally { setLoadingServ(false); }
  };

  const fetchFlashSales = async () => {
    try { const r = await GET('/api/seller/flash-sales'); setFlashSales(r.data.sales); }
    catch (e) { console.error(e); }
  };

  const saveService = async () => {
    setLoadingServ(true);
    try {
      if (editService) await PUT(`/api/seller/services/${editService.id}`, serviceForm);
      else             await POST('/api/seller/services', serviceForm);
      showToast(editService ? 'Service updated' : 'Service listed');
      setShowServForm(false);
      fetchServices();
    } catch (e: any) { showToast(e.message, 'error'); }
    finally { setLoadingServ(false); }
  };

  const saveFlashSale = async () => {
    try {
      await POST('/api/seller/flash-sales', flashForm);
      showToast('Flash sale created!');
      setShowFlashForm(false);
      fetchFlashSales();
    } catch (e: any) { showToast(e.message, 'error'); }
  };

  const saveBusinessInfo = async () => {
    setSavingBusiness(true);
    try {
      await PUT('/api/auth/update', businessForm);
      showToast('Business information updated!');
    } catch (e: any) { showToast(e.message, 'error'); }
    finally { setSavingBusiness(false); }
  };

  const requestVerification = async () => {
    setVerifying(true);
    try {
      await POST('/api/seller/verify', {});
      showToast('Verification request sent to Admin');
    } catch (e: any) { showToast(e.message, 'error'); }
    finally { setVerifying(false); }
  };

  const fetchProducts = async () => {
    setLoadingProd(true);
    try { const r = await GET('/api/seller/products'); setProducts(r.data.products); }
    catch (e) { console.error(e); } finally { setLoadingProd(false); }
  };

  const fetchOrders = async () => {
    setLoadingOrd(true);
    try {
      const url = orderFilter ? `/api/seller/orders?status=${orderFilter}` : '/api/seller/orders';
      const r = await GET(url);
      setOrders(r.data.orders);
    } catch (e) { console.error(e); } finally { setLoadingOrd(false); }
  };

  const fetchWallet = async () => {
    try { const r = await GET('/api/seller/wallet'); setWallet(r.data); } catch (e) { console.error(e); }
  };

  const fetchStore = async () => {
    try {
      const r = await GET('/api/seller/store');
      setStore(r.data.store);
      setStoreForm(r.data.store);
    } catch (e) { console.error(e); }
  };

  const fetchAds = async () => {
    try {
      const [adsRes, anaRes] = await Promise.all([GET('/api/seller/ads'), GET('/api/seller/ads/analytics')]);
      setAds(adsRes.data.ads);
      setAdAnalytics(anaRes.data);
    } catch (e) { console.error(e); }
  };

  const fetchReferrals = async () => {
    setLoadingRef(true);
    try {
      const r = await GET('/api/seller/referrals');
      setReferralsData(r.data);
    } catch (e) { console.error(e); }
    finally { setLoadingRef(false); }
  };

  // ── Product handlers ──────────────────────────────────────────────────────
  const openAddProduct = () => {
    setEditProduct(null);
    setProdForm({ 
      name: '', 
      description: '', 
      price: '', 
      originalPrice: '',
      campus: user?.campus || '', 
      condition: 'NEW', 
      stock: '1', 
      isActive: true, 
      images: [''] 
    });
    setShowProdForm(true);
  };

  const openEditProduct = (p: any) => {
    setEditProduct(p);
    setProdForm({ 
      name: p.name, 
      description: p.description || '', 
      price: String(p.price), 
      originalPrice: p.originalPrice ? String(p.originalPrice) : '',
      campus: p.campus, 
      condition: p.condition, 
      stock: String(p.stock), 
      isActive: p.isActive, 
      images: p.images?.length ? p.images : [''] 
    });
    setShowProdForm(true);
  };

  const saveProduct = async () => {
    setSavingProd(true);
    try {
      const images = prodForm.images.filter(i => i);

      const body = { 
        ...prodForm, 
        price: parseFloat(prodForm.price), 
        originalPrice: prodForm.originalPrice ? parseFloat(prodForm.originalPrice) : null,
        stock: parseInt(prodForm.stock), 
        images
      };
      if (editProduct) { await PUT(`/api/seller/products/${editProduct.id}`, body); showToast('Product updated!'); }
      else             { await POST('/api/seller/products', body); showToast('Product created!'); }
      setShowProdForm(false);
      fetchProducts();
    } catch (err: any) { showToast(err.message || 'Failed to save product', 'error'); }
    finally { setSavingProd(false); }
  };

  const toggleProduct = async (p: any) => {
    try {
      await PUT(`/api/seller/products/${p.id}`, { isActive: !p.isActive });
      fetchProducts();
      showToast(p.isActive ? 'Product hidden from marketplace' : 'Product visible on marketplace');
    } catch (err: any) { showToast(err.message, 'error'); }
  };

  const deleteProduct = async (id: string) => {
    if (!confirm('Remove this product from the marketplace?')) return;
    try { await DEL(`/api/seller/products/${id}`); fetchProducts(); showToast('Product removed'); }
    catch (err: any) { showToast(err.message, 'error'); }
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onloadend = () => {
      const base64 = reader.result as string;
      setProdForm(p => ({ ...p, images: [{ url: base64, isPrimary: true }] }));
      setAiAnalysis(null);
    };
    reader.readAsDataURL(file);
  };

  const handleRefineImage = async (maskData: string) => {
    const imgUrl = prodForm.images[0]?.url;
    if (!imgUrl) return;
    setProcessingImg(true);
    setShowRefiner(false);
    try {
      const res = await POST('/api/marketplace/refine-image', { image: imgUrl, mask: maskData });
      if (res.data.processedUrl) {
        setProdForm(p => ({ ...p, images: [{ url: res.data.processedUrl, isPrimary: true }] }));
        showToast('AI Refinement successful!');
        // Trigger analysis on the new image
        handleAIProcess(res.data.processedUrl);
      }
    } catch (err) {
      showToast('AI Refinement failed', 'error');
    } finally {
      setProcessingImg(false);
    }
  };

  const handleAIProcess = async (overriddenImg?: string) => {
    const imgUrl = overriddenImg || prodForm.images[0]?.url;
    if (!imgUrl) return;
    setProcessingImg(true);
    setAiAnalysis(null);
    try {
      const res = await POST('/api/marketplace/process-image', { image: imgUrl });
      setAiAnalysis(res.data.analysis);
      if (res.data.analysis.isAppropriate && res.data.analysis.isGoodQuality) {
        showToast('AI Enhancement complete!');
        // Update name and category if empty
        setProdForm(prev => ({
          ...prev,
          name: prev.name || res.data.analysis.suggestedTitle,
          category: (prev as any).category || res.data.analysis.suggestedCategory
        }));
      } else {
        showToast(res.data.analysis.feedback || 'Potential issues detected', 'error');
      }
    } catch (err) {
      showToast('AI Lab failed to process image', 'error');
    } finally {
      setProcessingImg(false);
    }
  };

  const removeBackground = async () => {
    const imgUrl = prodForm.images[0]?.url;
    if (!imgUrl) return;
    setProcessingImg(true);
    try {
      const res = await POST('/api/marketplace/remove-bg', { image: imgUrl });
      if (res.data.processedUrl) {
         setProdForm(p => ({ ...p, images: [{ url: res.data.processedUrl, isPrimary: true }] }));
         showToast('Background removal successful!');
      }
    } catch (err) {
      showToast('Background removal failed', 'error');
    } finally {
      setProcessingImg(false);
    }
  };

  // ── Order handlers ────────────────────────────────────────────────────────
  const updateOrderStatus = async (orderId: string, currentStatus: string) => {
    const nextStatus = STATUS_FLOW[currentStatus];
    if (!nextStatus) return;
    setUpdatingOrd(orderId);
    try {
      await PUT(`/api/seller/orders/${orderId}/status`, { status: nextStatus });
      fetchOrders();
      fetchAnalytics();
      showToast(`Order marked as ${nextStatus.replace(/_/g, ' ')}`);
    } catch (err: any) { showToast(err.message, 'error'); }
    finally { setUpdatingOrd(null); }
  };

  const cancelOrder = async (orderId: string) => {
    const reason = prompt('Reason for cancellation:');
    if (!reason) return;
    try {
      await PUT(`/api/seller/orders/${orderId}/cancel`, { reason });
      fetchOrders();
      showToast('Order cancelled and buyer refunded');
    } catch (err: any) { showToast(err.message, 'error'); }
  };

  // ── Payout handler ────────────────────────────────────────────────────────
  const requestPayout = async () => {
    const amt = parseFloat(payoutAmt);
    if (!amt || amt < 100) { setPayoutMsg('Minimum payout is KSH 100'); return; }
    setPayingOut(true);
    try {
      await POST('/api/seller/wallet/withdraw', { amount: amt, phone: payoutPhone });
      setPayoutMsg(`KSH ${amt.toLocaleString()} payout requested! Processing in 1-2 days.`);
      setPayoutAmt('');
      fetchWallet();
    } catch (err: any) { setPayoutMsg(err.message); }
    finally { setPayingOut(false); }
  };

  // ── Store save ────────────────────────────────────────────────────────────
  const saveStore = async () => {
    setSavingStore(true);
    try {
      await PUT('/api/seller/store', storeForm);
      setStoreMsg('Store updated successfully!');
      setTimeout(() => setStoreMsg(''), 3000);
    } catch (err: any) { setStoreMsg(err.message); }
    finally { setSavingStore(false); }
  };

  // ── Create Ad ─────────────────────────────────────────────────────────────
  const createAd = async () => {
    setSavingAd(true);
    try {
      await POST('/api/seller/ads', { ...adForm, budget: parseFloat(adForm.budget) });
      showToast('Ad submitted for review!');
      setShowAdForm(false);
      fetchAds();
    } catch (err: any) { showToast(err.message, 'error'); }
    finally { setSavingAd(false); }
  };

  const navItems: { id: Tab; icon: any; label: string }[] = [
    { id: 'overview',     icon: LayoutDashboard, label: 'Overview' },
    { id: 'products',     icon: Package,         label: 'Products' },
    { id: 'services',     icon: Hammer,          label: 'Services' },
    { id: 'flash-sales',  icon: Zap,             label: 'Flash Sale' },
    { id: 'orders',       icon: ShoppingCart,    label: 'Orders' },
    { id: 'wallet',       icon: Wallet,          label: 'Wallet' },
    { id: 'business',     icon: Store,           label: 'Business' },
    { id: 'verification', icon: CheckCircle,     label: 'Verify' },
    { id: 'referrals',   icon: Users,           label: 'Referrals' },
    { id: 'ads',          icon: Megaphone,       label: 'Ads' },
    { id: 'tos',          icon: Info,            label: 'TOS' },
  ];

  return (
    <div className="min-h-screen bg-white">

      {/* Toast */}
      {toast && (
        <div className={`fixed top-4 right-4 z-50 px-4 py-3 rounded-xl shadow-lg text-sm font-medium flex items-center gap-2 max-w-sm ${toast.type === 'success' ? 'bg-green-500 text-white' : 'bg-red-500 text-white'}`}>
          {toast.type === 'success' ? <CheckCircle className="w-4 h-4" /> : <AlertCircle className="w-4 h-4" />}
          {toast.msg}
        </div>
      )}

      {/* Header */}
      <div className="sticky top-0 z-30 bg-white border-b border-pink-100 px-4 md:px-8 py-3">
        <div className="max-w-7xl mx-auto flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-9 h-9 rounded-xl bg-pink-500 flex items-center justify-center">
              <Store className="w-5 h-5 text-white" />
            </div>
            <div>
              <p className="font-bold text-sm text-gray-900">{user?.name}</p>
              <p className="text-xs text-gray-400">{user?.campus}</p>
            </div>
          </div>

          {/* Nav tabs */}
          <div className="hidden md:flex items-center gap-1 bg-pink-50 border border-pink-100 rounded-xl p-1">
            {navItems.map(n => (
              <button key={n.id} onClick={() => setTab(n.id)}
                className={`px-3 py-1.5 rounded-lg text-xs font-bold flex items-center gap-1.5 transition-all ${tab === n.id ? 'bg-white shadow-sm text-pink-600' : 'text-gray-500 hover:text-gray-800'}`}>
                <n.icon className="w-3.5 h-3.5" /> {n.label}
              </button>
            ))}
          </div>

          <div className="flex items-center gap-2">
            <span className="hidden md:block text-xs font-bold text-green-600 bg-green-50 border border-green-200 px-2.5 py-1 rounded-lg">
              KSH {(analytics?.revenue?.total ?? 0).toLocaleString()}
            </span>
            <button onClick={() => { logout(); navigate('/login'); }} className="p-2 text-gray-400 hover:text-red-500 transition-colors">
              <LogOut className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* Mobile tabs */}
        <div className="md:hidden flex gap-1 mt-2 overflow-x-auto pb-1">
          {navItems.map(n => (
            <button key={n.id} onClick={() => setTab(n.id)}
              className={`flex-shrink-0 px-3 py-1.5 rounded-xl text-xs font-bold flex items-center gap-1 transition-all ${tab === n.id ? 'bg-pink-500 text-white' : 'bg-pink-50 text-gray-600 border border-pink-200'}`}>
              <n.icon className="w-3 h-3" /> {n.label}
            </button>
          ))}
        </div>
      </div>

      <div className="p-4 md:p-8 max-w-7xl mx-auto">

        {/* Detail Modals */}
        {showRefiner && prodForm.images[0]?.url && (
           <ImageRefiner 
             image={prodForm.images[0].url}
             onCancel={() => setShowRefiner(false)}
             onConfirm={handleRefineImage}
           />
        )}

        {/* ══ OVERVIEW ════════════════════════════════════════════════════════ */}
        {tab === 'overview' && (
          <div className="space-y-6">
            <div className="flex items-center justify-between">
              <div>
                <h1 className="text-2xl font-bold">Overview</h1>
                <p className="text-gray-400 text-sm mt-0.5">
                  {analytics?.orders?.pending > 0 ? `⚠️ ${analytics.orders.pending} orders need attention` : 'All caught up!'}
                </p>
              </div>
              <button onClick={() => { setTab('products'); openAddProduct(); }}
                className="bg-pink-500 text-white px-4 py-2 rounded-xl text-sm font-bold hover:bg-pink-600 transition-colors flex items-center gap-2">
                <Plus className="w-4 h-4" /> Add Product
              </button>
            </div>

            {/* Stats */}
            {loadingAna ? (
              <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
                {Array.from({length:4}).map((_,i)=><div key={i} className="h-28 bg-pink-50 rounded-2xl animate-pulse border border-pink-100" />)}
              </div>
            ) : (
              <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
                {[
                  { label: 'Total Revenue',    value: `KSH ${(analytics?.revenue?.total ?? 0).toLocaleString()}`,    icon: DollarSign, color: 'text-green-600',  sub: `KSH ${(analytics?.revenue?.month ?? 0).toLocaleString()} this month` },
                  { label: 'Active Products',  value: analytics?.products?.active ?? 0,                                  icon: Package,    color: 'text-pink-600',   sub: `${analytics?.products?.total ?? 0} total` },
                  { label: 'Total Orders',     value: analytics?.orders?.total ?? 0,                                     icon: ShoppingCart,color:'text-blue-600',   sub: `${analytics?.orders?.pending ?? 0} pending` },
                  { label: 'Customers',        value: analytics?.customers ?? 0,                                         icon: Users,      color: 'text-purple-600', sub: `${analytics?.orders?.delivered ?? 0} completed` },
                ].map((s, i) => (
                  <div key={i} className="bg-pink-50 border border-pink-100 p-5 rounded-2xl">
                    <div className="flex justify-between items-start mb-3">
                      <div className="p-2 bg-white rounded-lg"><s.icon className={`w-4 h-4 ${s.color}`} /></div>
                    </div>
                    <p className="text-2xl font-bold text-gray-900">{s.value}</p>
                    <p className="text-xs text-gray-500 mt-1">{s.label}</p>
                    <p className="text-[11px] text-gray-400 mt-0.5">{s.sub}</p>
                  </div>
                ))}
              </div>
            )}

            <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
              {/* Sales chart */}
              <div className="lg:col-span-2 bg-pink-50 border border-pink-100 rounded-2xl p-5">
                <h3 className="font-bold mb-4">Sales — Last 7 Days</h3>
                {salesData.length === 0 ? (
                  <div className="h-52 flex items-center justify-center text-gray-400 text-sm">No sales data yet</div>
                ) : (
                  <div className="h-52">
                    <ResponsiveContainer width="100%" height="100%">
                      <AreaChart data={salesData} margin={{ top: 5, right: 5, left: -20, bottom: 0 }}>
                        <defs>
                          <linearGradient id="grad" x1="0" y1="0" x2="0" y2="1">
                            <stop offset="5%"  stopColor="#ec4899" stopOpacity={0.3} />
                            <stop offset="95%" stopColor="#ec4899" stopOpacity={0} />
                          </linearGradient>
                        </defs>
                        <CartesianGrid strokeDasharray="3 3" stroke="#fbcfe8" vertical={false} />
                        <XAxis dataKey="date" stroke="#ec4899" tick={{ fill: '#ec4899', fontSize: 11 }} axisLine={false} tickLine={false} tickFormatter={d => d.slice(5)} />
                        <YAxis stroke="#ec4899" tick={{ fill: '#ec4899', fontSize: 11 }} axisLine={false} tickLine={false} tickFormatter={v => `${v/1000}k`} />
                        <Tooltip contentStyle={{ backgroundColor: '#fff', borderColor: '#fbcfe8', borderRadius: '8px' }} formatter={(v: any) => [`KSH ${v.toLocaleString()}`, 'Revenue']} />
                        <Area type="monotone" dataKey="revenue" stroke="#ec4899" strokeWidth={2} fill="url(#grad)" />
                      </AreaChart>
                    </ResponsiveContainer>
                  </div>
                )}
              </div>

              {/* Pending orders */}
              <div className="bg-pink-50 border border-pink-100 rounded-2xl p-5">
                <div className="flex items-center justify-between mb-4">
                  <h3 className="font-bold">Pending Orders</h3>
                  {analytics?.orders?.pending > 0 && (
                    <span className="bg-orange-100 text-orange-600 text-[10px] font-bold px-2 py-0.5 rounded-full">{analytics.orders.pending} new</span>
                  )}
                </div>
                {(analytics?.recentOrders ?? []).filter((o: any) => o.status === 'PENDING').slice(0, 4).map((order: any) => (
                  <div key={order.id} className="bg-white border border-pink-100 p-3 rounded-xl flex items-center gap-3 mb-2 hover:border-pink-300 transition-colors">
                    <div className="w-10 h-10 bg-pink-50 rounded-lg overflow-hidden flex-shrink-0">
                      {order.items?.[0]?.product?.images?.[0]
                        ? <img src={order.items[0].product.images[0]} className="w-full h-full object-cover" />
                        : <Package className="w-5 h-5 text-pink-300 m-auto mt-2.5" />}
                    </div>
                    <div className="flex-1 min-w-0">
                      <p className="font-bold text-xs truncate">{order.items?.[0]?.product?.name}</p>
                      <p className="text-[10px] text-gray-400">#{order.id.slice(-6).toUpperCase()} · KSH {order.total.toLocaleString()}</p>
                    </div>
                    <button onClick={() => setTab('orders')} className="bg-pink-500 text-white text-[10px] font-bold px-2 py-1 rounded-lg hover:bg-pink-600">
                      View
                    </button>
                  </div>
                ))}
                {(analytics?.orders?.pending ?? 0) === 0 && (
                  <div className="text-center py-6 text-gray-400 text-sm">No pending orders</div>
                )}
                <button onClick={() => setTab('orders')} className="w-full mt-3 py-2 border-2 border-dashed border-pink-200 rounded-xl text-xs font-bold text-pink-500 hover:bg-pink-50 transition-colors">
                  View All Orders →
                </button>
              </div>
            </div>

            {/* Top products */}
            {analytics?.topProducts?.length > 0 && (
              <div className="bg-pink-50 border border-pink-100 rounded-2xl p-5">
                <h3 className="font-bold mb-4">Top Products</h3>
                <div className="space-y-3">
                  {analytics.topProducts.map((tp: any, i: number) => (
                    <div key={i} className="flex items-center gap-4 bg-white border border-pink-100 rounded-xl p-3">
                      <span className="text-sm font-bold text-gray-400 w-5">#{i+1}</span>
                      <div className="w-10 h-10 rounded-lg overflow-hidden bg-pink-50 flex-shrink-0">
                        {tp.product?.images?.[0]
                          ? <img src={tp.product.images[0]} className="w-full h-full object-cover" />
                          : <Package className="w-5 h-5 text-pink-300 m-auto mt-2.5" />}
                      </div>
                      <div className="flex-1 min-w-0">
                        <p className="font-semibold text-sm truncate">{tp.product?.name}</p>
                        <p className="text-xs text-gray-400">{tp._sum?.quantity} sold</p>
                      </div>
                      <p className="font-bold text-sm text-pink-600">KSH {(tp._sum?.price ?? 0).toLocaleString()}</p>
                    </div>
                  ))}
                </div>
              </div>
            )}
          </div>
        )}

        {/* ══ PRODUCTS ════════════════════════════════════════════════════════ */}
        {tab === 'products' && (
          <div className="space-y-5">
            <div className="flex items-center justify-between">
              <h2 className="text-xl font-bold">Products</h2>
              <button onClick={openAddProduct}
                className="bg-pink-500 text-white px-4 py-2 rounded-xl text-sm font-bold hover:bg-pink-600 transition-colors flex items-center gap-2">
                <Plus className="w-4 h-4" /> Add Product
              </button>
            </div>

            {loadingProd ? (
              <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
                {Array.from({length:8}).map((_,i)=><div key={i} className="h-52 bg-pink-50 rounded-2xl animate-pulse border border-pink-100" />)}
              </div>
            ) : products.length === 0 ? (
              <div className="text-center py-20 bg-pink-50 rounded-2xl border border-pink-100">
                <Package className="w-12 h-12 text-pink-200 mx-auto mb-3" />
                <p className="text-gray-500 font-semibold">No products yet</p>
                <button onClick={openAddProduct} className="mt-4 bg-pink-500 text-white text-sm font-bold px-6 py-2 rounded-xl hover:bg-pink-600 transition-colors">
                  Add Your First Product
                </button>
              </div>
            ) : (
              <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
                {products.map(p => (
                  <div key={p.id} className={`bg-white border rounded-2xl overflow-hidden transition-all ${p.isActive ? 'border-pink-100' : 'border-gray-200 opacity-60'}`}>
                    <div className="relative aspect-square bg-pink-50 overflow-hidden">
                      {p.images?.[0]
                        ? <img src={p.images[0]} className="w-full h-full object-cover" />
                        : <div className="w-full h-full flex items-center justify-center"><Package className="w-10 h-10 text-pink-200" /></div>}
                      <div className="absolute top-2 left-2">
                        <span className={`text-[10px] font-bold px-1.5 py-0.5 rounded-md ${p.stock === 0 ? 'bg-red-100 text-red-600' : p.stock <= 3 ? 'bg-yellow-100 text-yellow-700' : 'bg-green-100 text-green-700'}`}>
                          {p.stock === 0 ? 'Out of Stock' : `Stock: ${p.stock}`}
                        </span>
                      </div>
                    </div>
                    <div className="p-3">
                      <p className="font-semibold text-sm truncate">{p.name}</p>
                      <div className="flex flex-col mt-0.5">
                        {p.originalPrice && p.originalPrice > p.price && (
                          <div className="flex items-center gap-2">
                             <span className="text-[10px] text-gray-400 line-through leading-none">WAS KSH {p.originalPrice.toLocaleString()}</span>
                             <span className="bg-rose-100 text-rose-600 text-[9px] font-black px-1.5 py-0.5 rounded uppercase">
                               {Math.round((1 - p.price / p.originalPrice) * 100)}% OFF
                             </span>
                          </div>
                        )}
                        <p className="font-bold text-pink-500 text-sm">NOW KSH {p.price.toLocaleString()}</p>
                      </div>
                      <div className="flex items-center gap-1 mt-2">
                        <button onClick={() => openEditProduct(p)} className="flex-1 py-1.5 rounded-lg bg-pink-50 border border-pink-200 text-xs font-semibold text-gray-700 hover:bg-pink-100 flex items-center justify-center gap-1">
                          <Edit2 className="w-3 h-3" /> Edit
                        </button>
                        <button onClick={() => toggleProduct(p)} className={`p-1.5 rounded-lg border transition-colors ${p.isActive ? 'bg-green-50 border-green-200 text-green-600' : 'bg-gray-50 border-gray-200 text-gray-400'}`} title={p.isActive ? 'Hide' : 'Show'}>
                          {p.isActive ? <Eye className="w-3.5 h-3.5" /> : <EyeOff className="w-3.5 h-3.5" />}
                        </button>
                        <button onClick={() => deleteProduct(p.id)} className="p-1.5 rounded-lg bg-red-50 border border-red-200 text-red-400 hover:bg-red-100 transition-colors">
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            )}

            {/* Product Form Modal */}
            {showProdForm && (
              <div className="fixed inset-0 z-50 bg-black/50 flex items-center justify-center p-4" onClick={() => setShowProdForm(false)}>
                <div className="bg-white rounded-2xl shadow-2xl w-full max-w-lg max-h-[90vh] overflow-y-auto" onClick={e => e.stopPropagation()}>
                  <div className="flex items-center justify-between p-5 border-b border-pink-100">
                    <h3 className="font-bold text-lg">{editProduct ? 'Edit Product' : 'Add Product'}</h3>
                    <button onClick={() => setShowProdForm(false)}><X className="w-5 h-5 text-gray-400" /></button>
                  </div>
                  <div className="p-5 space-y-4">
                    <div>
                      <label className="block text-xs font-semibold text-gray-500 uppercase tracking-wide mb-1">Product Name</label>
                      <input type="text" value={prodForm.name} placeholder="e.g. Air Jordan 4 Retro"
                        onChange={e => setProdForm(prev => ({ ...prev, name: e.target.value }))}
                        className="w-full bg-pink-50 border border-pink-200 rounded-xl py-2.5 px-3 text-sm focus:outline-none focus:border-pink-500" />
                    </div>

                    <div className="grid grid-cols-2 gap-4">
                      <div>
                        <label className="block text-xs font-semibold text-gray-500 uppercase tracking-wide mb-1">Now Price (NOW)</label>
                        <input type="number" value={prodForm.price} placeholder="0"
                          onChange={e => setProdForm(prev => ({ ...prev, price: e.target.value }))}
                          className="w-full bg-pink-50 border border-pink-200 rounded-xl py-2.5 px-3 text-sm focus:outline-none focus:border-pink-500" />
                      </div>
                      <div>
                        <label className="block text-xs font-semibold text-gray-500 uppercase tracking-wide mb-1">Was Price (Optional)</label>
                        <input type="number" value={prodForm.originalPrice} placeholder="e.g. 1000"
                          onChange={e => setProdForm(prev => ({ ...prev, originalPrice: e.target.value }))}
                          className="w-full bg-pink-50 border border-pink-200 rounded-xl py-2.5 px-3 text-sm focus:outline-none focus:border-pink-500" />
                      </div>
                    </div>

                    {[
                      { key: 'stock',       label: 'Stock Quantity', type: 'number', placeholder: '1' },
                      { key: 'campus',      label: 'Campus',         type: 'text',   placeholder: 'e.g. JKUAT Main' },
                    ].map(f => (
                      <div key={f.key}>
                        <label className="block text-xs font-semibold text-gray-500 uppercase tracking-wide mb-1">{f.label}</label>
                        <input type={f.type} value={(prodForm as any)[f.key]} placeholder={f.placeholder}
                          onChange={e => setProdForm(prev => ({ ...prev, [f.key]: e.target.value }))}
                          className="w-full bg-pink-50 border border-pink-200 rounded-xl py-2.5 px-3 text-sm focus:outline-none focus:border-pink-500" />
                      </div>
                    ))}

                    <div>
                      <label className="block text-xs font-semibold text-gray-500 uppercase tracking-wide mb-1">Condition</label>
                      <div className="grid grid-cols-4 gap-2">
                        {CONDITIONS.map(c => (
                          <button key={c} onClick={() => setProdForm(p => ({ ...p, condition: c }))}
                            className={`py-2 rounded-xl text-xs font-bold border transition-all ${prodForm.condition === c ? 'bg-pink-500 border-pink-500 text-white' : 'bg-white border-pink-200 text-gray-600'}`}>
                            {c.replace('_', ' ')}
                          </button>
                        ))}
                      </div>
                    </div>

                    <div>
                      <label className="block text-xs font-semibold text-gray-500 uppercase tracking-wide mb-1">Description</label>
                      <textarea value={prodForm.description} rows={3}
                        onChange={e => setProdForm(p => ({ ...p, description: e.target.value }))}
                        placeholder="Describe your product..."
                        className="w-full bg-pink-50 border border-pink-200 rounded-xl py-2.5 px-3 text-sm focus:outline-none focus:border-pink-500 resize-none" />
                    </div>

                    <div>
                      <label className="block text-xs font-semibold text-gray-500 uppercase tracking-wide mb-1">Product Images</label>
                      <div className="flex flex-col gap-3">
                        <div className="flex gap-2">
                           <div className="flex-1 relative">
                            <input type="text" value={prodForm.images[0]?.url?.startsWith('data:') ? 'Image uploaded...' : prodForm.images[0]?.url || ''}
                              onChange={e => {
                                setProdForm(p => ({ ...p, images: [{ url: e.target.value, isPrimary: true }] }));
                                setAiAnalysis(null);
                              }}
                              placeholder="Paste image URL..."
                              className="w-full bg-pink-50 border border-pink-200 rounded-xl py-2.5 px-3 text-sm focus:outline-none focus:border-pink-500" />
                            <div className="absolute right-2 top-1/2 -translate-y-1/2 flex items-center gap-2">
                               <label className="cursor-pointer p-1.5 hover:bg-pink-100 rounded-lg transition-colors text-pink-500">
                                 <Plus className="w-4 h-4" />
                                 <input type="file" accept="image/*" className="hidden" onChange={handleFileChange} />
                               </label>
                            </div>
                           </div>
                          <button 
                            type="button"
                            disabled={!prodForm.images[0]?.url || processingImg}
                            onClick={() => handleAIProcess()}
                            className="bg-pink-500 text-white px-4 rounded-xl font-bold text-xs hover:bg-pink-600 disabled:opacity-50 flex items-center gap-2"
                          >
                            {processingImg ? <RefreshCw className="w-3 h-3 animate-spin"/> : <RefreshCw className="w-3 h-3" />}
                            AI Lab
                          </button>
                        </div>
                        
                         {prodForm.images[0]?.url && !processingImg && (
                           <div className="grid grid-cols-2 gap-2">
                             <button 
                               onClick={() => setShowRefiner(true)}
                               className="flex items-center justify-center gap-2 py-2 bg-gray-900 text-white rounded-xl text-[10px] font-black uppercase tracking-widest hover:bg-pink-600 transition-all border border-gray-800"
                             >
                               <Edit2 className="w-3.5 h-3.5" /> Mask Parts
                             </button>
                             <button 
                               onClick={removeBackground}
                               className="flex items-center justify-center gap-2 py-2 bg-pink-50 text-pink-600 rounded-xl text-[10px] font-black uppercase tracking-widest hover:bg-pink-100 transition-all border border-pink-200"
                             >
                               <Sparkles className="w-3.5 h-3.5" /> Remove BG
                             </button>
                           </div>
                         )}
                      </div>

                      {processingImg && (
                        <div className="mt-4 p-4 bg-pink-50 rounded-2xl border border-pink-200 animate-pulse">
                          <div className="flex items-center gap-3">
                            <div className="w-8 h-8 rounded-full bg-pink-200 flex items-center justify-center">
                              <RefreshCw className="w-4 h-4 text-pink-500 animate-spin" />
                            </div>
                            <div className="flex-1">
                              <p className="text-xs font-bold text-pink-600">AI AGENT PROCESSING...</p>
                              <div className="h-1 bg-pink-200 rounded-full mt-2 overflow-hidden">
                                <div className="h-full bg-pink-500 w-1/2 animate-[progress_2s_ease-in-out_infinite]"></div>
                              </div>
                            </div>
                          </div>
                        </div>
                      )}

                      {aiAnalysis && (
                        <div className={`mt-4 rounded-2xl border p-4 transition-all ${aiAnalysis.isAppropriate && aiAnalysis.isGoodQuality ? 'bg-emerald-50 border-emerald-200' : 'bg-red-50 border-red-200'}`}>
                           <div className="flex items-center justify-between mb-3">
                            <div className="flex items-center gap-2">
                              {aiAnalysis.isGoodQuality ? <CheckCircle className="w-4 h-4 text-emerald-500" /> : <AlertCircle className="w-4 h-4 text-red-500" />}
                              <span className="text-xs font-bold uppercase tracking-wider">{aiAnalysis.isGoodQuality ? 'AI Quality Verified' : 'Action Required'}</span>
                            </div>
                            <button onClick={() => setViewProcessed(!viewProcessed)} className="text-[10px] font-black underline uppercase text-gray-500 hover:text-pink-600">
                              View {viewProcessed ? 'Original' : 'AI Enhanced'}
                            </button>
                           </div>
                           
                           <div className="flex gap-4">
                              <div className="relative w-24 h-24 rounded-xl overflow-hidden border border-white shadow-sm flex-shrink-0">
                                <img 
                                  src={prodForm.images[0].url} 
                                  className={`w-full h-full object-cover transition-all duration-500 ${viewProcessed ? 'brightness-110 contrast-110' : ''}`}
                                />
                                {viewProcessed && <div className="absolute inset-0 bg-white/10 backdrop-blur-[0.5px]"></div>}
                                <div className="absolute top-1 left-1 bg-black/60 text-white text-[8px] px-1 rounded uppercase font-black">
                                  {viewProcessed ? 'ENHANCED' : 'RAW'}
                                </div>
                              </div>
                              <div className="flex-1 min-w-0">
                                <p className="text-xs font-medium text-gray-700 leading-relaxed">
                                  {aiAnalysis.feedback}
                                </p>
                                <div className="mt-2 flex flex-wrap gap-1">
                                  {aiAnalysis.suggestedTitle && (
                                    <span className="text-[9px] bg-white border border-gray-100 px-1.5 py-0.5 rounded font-bold text-gray-500">
                                      SUGGESTED TITLE: {aiAnalysis.suggestedTitle}
                                    </span>
                                  )}
                                  {aiAnalysis.suggestedCategory && (
                                    <span className="text-[9px] bg-pink-100 border border-pink-200 px-1.5 py-0.5 rounded font-bold text-pink-600">
                                      CAT: {aiAnalysis.suggestedCategory}
                                    </span>
                                  )}
                                </div>
                              </div>
                           </div>

                           {!aiAnalysis.isAppropriate && (
                             <div className="mt-3 p-2 bg-red-500 text-white rounded-lg text-[10px] font-bold flex items-center gap-2">
                               <AlertCircle className="w-3 h-3" />
                               IMAGE REJECTED: DOES NOT COMPLY WITH SAFETY POLICIES
                             </div>
                           )}
                        </div>
                      )}

                      {!processingImg && !aiAnalysis && prodForm.images[0]?.url && (
                        <div className="mt-2 group relative h-40 rounded-2xl overflow-hidden border border-pink-100 bg-pink-50">
                          <img src={prodForm.images[0].url} className="w-full h-full object-cover" />
                          <div className="absolute inset-0 bg-black/20 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center">
                            <span className="bg-white/90 backdrop-blur px-3 py-1.5 rounded-xl text-[10px] font-black text-pink-600 flex items-center gap-2">
                              <RefreshCw className="w-3 h-3" /> CLICK AI LAB TO ENHANCE
                            </span>
                          </div>
                        </div>
                      )}
                    </div>

                    <button onClick={saveProduct} disabled={savingProd || !prodForm.title || !prodForm.price}
                      className="w-full bg-pink-500 text-white font-bold py-3 rounded-xl hover:bg-pink-600 transition-colors flex items-center justify-center gap-2 disabled:opacity-60">
                      {savingProd ? <RefreshCw className="w-4 h-4 animate-spin" /> : <Save className="w-4 h-4" />}
                      {savingProd ? 'Saving...' : editProduct ? 'Update Product' : 'Create Product'}
                    </button>
                  </div>
                </div>
              </div>
            )}
          </div>
        )}

        {/* ══ ORDERS ══════════════════════════════════════════════════════════ */}
        {tab === 'orders' && (
          <div className="space-y-5">
            <div className="flex items-center justify-between flex-wrap gap-3">
              <h2 className="text-xl font-bold">Orders</h2>
              <div className="flex gap-2 flex-wrap">
                {['', 'PENDING', 'CONFIRMED', 'PROCESSING', 'OUT_FOR_DELIVERY', 'DELIVERED', 'CANCELLED'].map(s => (
                  <button key={s} onClick={() => setOrderFilter(s)}
                    className={`px-3 py-1.5 rounded-xl text-xs font-bold border transition-all ${orderFilter === s ? 'bg-pink-500 text-white border-pink-500' : 'bg-white border-pink-200 text-gray-600 hover:border-pink-400'}`}>
                    {s || 'All'}
                  </button>
                ))}
              </div>
            </div>

            {loadingOrd ? (
              <div className="space-y-3">{Array.from({length:5}).map((_,i)=><div key={i} className="h-20 bg-pink-50 rounded-2xl animate-pulse border border-pink-100" />)}</div>
            ) : orders.length === 0 ? (
              <div className="text-center py-20 bg-pink-50 rounded-2xl border border-pink-100">
                <ShoppingCart className="w-12 h-12 text-pink-200 mx-auto mb-3" />
                <p className="text-gray-500 font-semibold">No orders {orderFilter ? `with status ${orderFilter}` : 'yet'}</p>
              </div>
            ) : (
              <div className="space-y-3">
                {orders.map(order => (
                  <div key={order.id} className="bg-white border border-pink-100 rounded-2xl p-4 hover:border-pink-300 transition-colors">
                    <div className="flex items-start justify-between gap-4">
                      <div className="flex items-center gap-3 flex-1 min-w-0">
                        <div className="w-12 h-12 rounded-xl overflow-hidden bg-pink-50 flex-shrink-0">
                          {order.items?.[0]?.product?.images?.[0]?.url
                            ? <img src={order.items[0].product.images[0].url} className="w-full h-full object-cover" />
                            : <Package className="w-6 h-6 text-pink-300 m-auto mt-3" />}
                        </div>
                        <div className="min-w-0 flex-1">
                          <div className="flex items-center gap-2 flex-wrap mb-1">
                            <span className="font-bold text-sm">#{order.id.slice(-6).toUpperCase()}</span>
                            <span className={`text-[10px] font-bold px-2 py-0.5 rounded-full ${STATUS_COLOR[order.status]}`}>{order.status.replace(/_/g,' ')}</span>
                            <span className="text-[9px] font-black text-pink-500 uppercase tracking-widest ml-auto">{order.paymentMethod || 'WALLET'}</span>
                          </div>
                          <p className="text-xs text-gray-500 truncate">{order.buyer?.name} · {order.items?.length} item{order.items?.length !== 1 ? 's' : ''}</p>
                          {order.shippingAddress && (
                            <div className="mt-1 flex items-start gap-1.5 p-1.5 bg-gray-50 rounded-lg border border-gray-100">
                               <MapPin className="w-3 h-3 text-pink-500 mt-0.5 flex-shrink-0" />
                               <p className="text-[10px] text-gray-600 leading-tight">{order.shippingAddress}</p>
                            </div>
                          )}
                          <p className="text-xs text-gray-400">{new Date(order.createdAt).toLocaleDateString('en-KE')}</p>
                        </div>
                      </div>
                      <div className="flex flex-col items-end gap-2 flex-shrink-0">
                        <p className="font-bold text-sm text-pink-600">KSH {order.total.toLocaleString()}</p>
                        <div className="flex gap-1">
                          {STATUS_FLOW[order.status] && (
                            <button
                              onClick={() => updateOrderStatus(order.id, order.status)}
                              disabled={updatingOrd === order.id}
                              className="bg-pink-500 text-white text-xs font-bold px-3 py-1.5 rounded-lg hover:bg-pink-600 transition-colors flex items-center gap-1 disabled:opacity-60">
                              {updatingOrd === order.id ? <RefreshCw className="w-3 h-3 animate-spin" /> : <Truck className="w-3 h-3" />}
                              {STATUS_LABEL[order.status]}
                            </button>
                          )}
                          {['PENDING', 'CONFIRMED'].includes(order.status) && (
                            <button onClick={() => cancelOrder(order.id)}
                              className="bg-red-50 border border-red-200 text-red-500 text-xs font-bold px-2 py-1.5 rounded-lg hover:bg-red-100 transition-colors">
                              <XCircle className="w-3.5 h-3.5" />
                            </button>
                          )}
                        </div>
                      </div>
                    </div>
                    {order.items?.length > 1 && (
                      <div className="mt-2 flex gap-1 flex-wrap">
                        {order.items.slice(1).map((item: any, i: number) => (
                          <span key={i} className="text-[10px] bg-pink-50 border border-pink-100 px-2 py-0.5 rounded-full text-gray-500">{item.product?.title}</span>
                        ))}
                      </div>
                    )}
                  </div>
                ))}
              </div>
            )}
          </div>
        )}

        {/* ══ SERVICES ══════════════════════════════════════════════════════════ */}
        {tab === 'services' && (
          <div className="space-y-6">
            <div className="flex items-center justify-between">
              <h2 className="text-xl font-bold">Services</h2>
              <button 
                onClick={() => { setEditService(null); setServiceForm({ name: '', category: 'Salon', description: '', price: '', location: '', contactNumber: user?.phone || '', email: user?.email || '', availabilitySchedule: 'Mon-Sat: 9am-6pm', images: [] }); setShowServForm(true); }}
                className="bg-pink-500 text-white px-4 py-2 rounded-xl text-sm font-bold flex items-center gap-2"
              >
                <Plus className="w-4 h-4" /> Add Service
              </button>
            </div>

            {loadingServ ? (
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                {Array.from({length:3}).map((_,i)=><div key={i} className="h-40 bg-pink-50 rounded-2xl animate-pulse" />)}
              </div>
            ) : services.length === 0 ? (
              <div className="text-center py-20 bg-pink-50 rounded-2xl border border-pink-100">
                <Hammer className="w-12 h-12 text-pink-200 mx-auto mb-3" />
                <p className="text-gray-500 font-semibold">No services offered yet</p>
              </div>
            ) : (
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                {services.map(s => (
                  <div key={s.id} className="bg-white border border-pink-100 p-4 rounded-2xl shadow-sm hover:shadow-md transition-all">
                    <div className="flex justify-between items-start mb-4">
                      <div>
                        <span className="text-[10px] font-black uppercase bg-pink-100 text-pink-600 px-2 py-0.5 rounded-full">{s.category}</span>
                        <h3 className="font-bold text-lg mt-1">{s.name}</h3>
                      </div>
                      <p className="font-black text-pink-600">KSH {s.price.toLocaleString()}</p>
                    </div>
                    <p className="text-xs text-gray-500 line-clamp-2 mb-4">{s.description}</p>
                    <div className="flex items-center justify-between pt-4 border-t border-pink-50">
                      <div className="flex items-center gap-2">
                        <button onClick={() => { setEditService(s); setServiceForm(s); setShowServForm(true); }} className="p-2 text-gray-400 hover:text-pink-500">
                          <Edit2 className="w-4 h-4" />
                        </button>
                        <button className="p-2 text-gray-400 hover:text-red-500">
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </div>
                      <button className="text-xs font-bold text-gray-400 flex items-center gap-1">Manage Bookings <ChevronRight className="w-3 h-3" /></button>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        )}

        {/* ══ FLASH SALES ═════════════════════════════════════════════════════════ */}
        {tab === 'flash-sales' && (
          <div className="space-y-6">
            <div className="flex items-center justify-between">
              <h2 className="text-xl font-bold">Flash Sales</h2>
              <button 
                onClick={() => setShowFlashForm(true)}
                className="bg-rose-600 text-white px-4 py-2 rounded-xl text-sm font-bold flex items-center gap-2 shadow-lg shadow-rose-500/20"
              >
                <Zap className="w-4 h-4" /> Create Flash Sale
              </button>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {flashSales.map(sale => (
                <div key={sale.id} className="bg-white border border-rose-100 p-5 rounded-3xl flex gap-4 overflow-hidden relative group">
                  <div className="w-24 h-24 rounded-2xl bg-rose-50 overflow-hidden flex-shrink-0">
                    <img src={sale.bannerImage || sale.product?.images?.[0]?.url} className="w-full h-full object-cover" />
                  </div>
                  <div className="flex-1">
                    <div className="flex items-center gap-2 mb-1">
                      <span className="text-[10px] font-black uppercase bg-rose-100 text-rose-600 px-2 py-0.5 rounded-full">Active</span>
                      <h3 className="font-bold text-gray-900 truncate">{sale.product?.name}</h3>
                    </div>
                    <div className="flex items-baseline gap-2 mb-2">
                      <p className="text-lg font-black text-rose-600">KSH {sale.flashPrice.toLocaleString()}</p>
                      <p className="text-xs text-gray-400 line-through">KSH {sale.product?.price.toLocaleString()}</p>
                    </div>
                    <div className="flex items-center gap-3 text-[10px] font-bold text-gray-400 uppercase tracking-widest">
                       <span className="flex items-center gap-1"><Clock className="w-3 h-3" /> Ends in 4h 20m</span>
                    </div>
                  </div>
                </div>
              ))}
              {flashSales.length === 0 && (
                <div className="md:col-span-2 text-center py-20 bg-rose-50 rounded-3xl border border-rose-100/50">
                  <Zap className="w-12 h-12 text-rose-200 mx-auto mb-3" />
                  <p className="text-rose-900/40 font-semibold uppercase tracking-widest text-xs">No active flash sales</p>
                </div>
              )}
            </div>
          </div>
        )}

        {/* ══ BUSINESS INFO ═══════════════════════════════════════════════════════ */}
        {tab === 'business' && (
          <div className="max-w-2xl mx-auto space-y-8">
            <div>
              <h2 className="text-2xl font-black text-gray-900 mb-2">Business Storefront</h2>
              <p className="text-gray-500 text-sm">Update your public profile and storefront details</p>
            </div>

            <div className="bg-pink-50 border border-pink-100 p-8 rounded-[40px] space-y-6">
              <div className="flex flex-col items-center gap-4 mb-8">
                <div className="relative group">
                  <div className="w-24 h-24 rounded-3xl bg-white border-2 border-pink-200 p-1 flex items-center justify-center overflow-hidden">
                    {businessForm.businessLogo ? (
                      <img src={businessForm.businessLogo} className="w-full h-full object-cover rounded-2xl" />
                    ) : (
                      <Store className="w-10 h-10 text-pink-300" />
                    )}
                  </div>
                  <label className="absolute bottom-1 right-1 w-8 h-8 rounded-xl bg-pink-500 text-white flex items-center justify-center cursor-pointer shadow-lg hover:scale-110 transition-transform">
                    <Plus className="w-4 h-4" />
                    <input type="file" className="hidden" />
                  </label>
                </div>
                <div className="text-center">
                  <p className="font-black text-gray-900 uppercase tracking-widest">{businessForm.businessName || 'My Store'}</p>
                  <p className="text-xs text-gray-400 font-medium">{businessForm.location}</p>
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <label className="text-[10px] font-black text-gray-400 uppercase tracking-widest mb-1.5 block">Business Name</label>
                  <input 
                    value={businessForm.businessName} 
                    onChange={e => setBusinessForm({...businessForm, businessName: e.target.value})}
                    className="w-full bg-white border border-pink-200 rounded-2xl py-3 px-4 text-sm focus:outline-none focus:border-pink-500" 
                  />
                </div>
                <div>
                  <label className="text-[10px] font-black text-gray-400 uppercase tracking-widest mb-1.5 block">Location / Campus</label>
                  <input 
                    value={businessForm.location} 
                    onChange={e => setBusinessForm({...businessForm, location: e.target.value})}
                    className="w-full bg-white border border-pink-200 rounded-2xl py-3 px-4 text-sm focus:outline-none focus:border-pink-500" 
                  />
                </div>
                <div className="md:col-span-2">
                  <label className="text-[10px] font-black text-gray-400 uppercase tracking-widest mb-1.5 block">Business Bio</label>
                  <textarea 
                    value={businessForm.businessDescription} 
                    onChange={e => setBusinessForm({...businessForm, businessDescription: e.target.value})}
                    rows={3} 
                    className="w-full bg-white border border-pink-200 rounded-2xl py-3 px-4 text-sm focus:outline-none focus:border-pink-500 resize-none" 
                  />
                </div>
                <div>
                  <label className="text-[10px] font-black text-gray-400 uppercase tracking-widest mb-1.5 block">Contact Phone</label>
                  <input 
                    value={businessForm.businessContact} 
                    onChange={e => setBusinessForm({...businessForm, businessContact: e.target.value})}
                    className="w-full bg-white border border-pink-200 rounded-2xl py-3 px-4 text-sm focus:outline-none focus:border-pink-500" 
                  />
                </div>
                <div>
                  <label className="text-[10px] font-black text-gray-400 uppercase tracking-widest mb-1.5 block">Store Email</label>
                  <input 
                    value={businessForm.businessEmail} 
                    onChange={e => setBusinessForm({...businessForm, businessEmail: e.target.value})}
                    className="w-full bg-white border border-pink-200 rounded-2xl py-3 px-4 text-sm focus:outline-none focus:border-pink-500" 
                  />
                </div>
              </div>

              <button 
                onClick={saveBusinessInfo}
                disabled={savingBusiness}
                className="w-full bg-gray-900 text-white font-black py-4 rounded-2xl flex items-center justify-center gap-2 hover:bg-pink-600 transition-all uppercase tracking-widest disabled:opacity-50"
              >
                {savingBusiness ? <RefreshCw className="w-5 h-5 animate-spin"/> : <Save className="w-5 h-5" />}
                Save Storefront
              </button>
            </div>
          </div>
        )}

        {/* ══ VERIFICATION ════════════════════════════════════════════════════════ */}
        {tab === 'verification' && (
          <div className="max-w-xl mx-auto py-10">
            <div className="text-center mb-10">
              <div className={`w-24 h-24 rounded-full mx-auto mb-6 flex items-center justify-center border-4 ${user?.isVerified ? 'bg-blue-50 border-blue-200' : user?.verificationRequested ? 'bg-orange-50 border-orange-200' : 'bg-pink-50 border-pink-200'}`}>
                {user?.isVerified ? (
                  <CheckCircle className="w-12 h-12 text-blue-500 fill-current" />
                ) : user?.verificationRequested ? (
                  <Clock className="w-12 h-12 text-orange-400" />
                ) : (
                  <UserCheck className="w-12 h-12 text-pink-400" />
                )}
              </div>
              <h2 className="text-3xl font-black text-gray-900 mb-3">Verification Badge</h2>
              <p className="text-gray-500 max-w-sm mx-auto leading-relaxed">
                Build trust across the marketplace with a blue verification badge on your profile and listings.
              </p>
            </div>

            <div className="bg-white border border-pink-100 p-8 rounded-[40px] shadow-sm">
               <div className="space-y-6 mb-8">
                 {[
                   { label: 'Trust Marker', desc: 'Sellers with badges have 4x higher CTR.' },
                   { label: 'Verified Status', desc: 'Appears on Search, Chat, and Stories.' },
                   { label: 'Priority Support', desc: 'Direct line to KAMPAS merchant team.' }
                 ].map((feat, i) => (
                   <div key={i} className="flex gap-4">
                     <div className="w-10 h-10 rounded-xl bg-blue-50 text-blue-500 flex items-center justify-center flex-shrink-0">
                        <CheckCircle className="w-5 h-5" />
                     </div>
                     <div>
                       <p className="text-sm font-black text-gray-900 uppercase tracking-tight">{feat.label}</p>
                       <p className="text-xs text-gray-400">{feat.desc}</p>
                     </div>
                   </div>
                 ))}
               </div>

               <div className="pt-8 border-t border-pink-50">
                 <div className="flex items-center justify-between mb-8">
                   <div>
                     <p className="text-[10px] font-black text-gray-400 uppercase tracking-widest">Verification Fee</p>
                     <p className="text-2xl font-black text-gray-900">FREE <span className="text-sm text-gray-400 line-through">KES 100</span></p>
                   </div>
                   <div className="bg-pink-100 text-pink-600 text-[10px] font-black px-3 py-1.5 rounded-full uppercase tracking-widest">
                     Early Launch Promo
                   </div>
                 </div>

                 {user?.isVerified ? (
                   <div className="bg-blue-50 border border-blue-200 text-blue-700 p-4 rounded-2xl flex items-center gap-3">
                     <CheckCircle className="w-5 h-5 fill-current" />
                     <p className="text-sm font-bold">Your account is verified. Badge active.</p>
                   </div>
                 ) : user?.verificationRequested ? (
                   <div className="bg-orange-50 border border-orange-200 text-orange-700 p-4 rounded-2xl flex items-center gap-3">
                     <Clock className="w-5 h-5" />
                     <p className="text-sm font-bold">Request pending. Admin review in progress.</p>
                   </div>
                 ) : (
                   <button 
                     onClick={requestVerification}
                     disabled={verifying}
                     className="w-full bg-blue-500 text-white font-black py-4 rounded-2xl flex items-center justify-center gap-3 hover:bg-blue-600 transition-all uppercase tracking-widest shadow-xl shadow-blue-500/20"
                   >
                     {verifying ? <RefreshCw className="w-5 h-5 animate-spin" /> : <UserCheck className="w-5 h-5" />}
                     Request Badge Now
                   </button>
                 )}
               </div>
            </div>
          </div>
        )}

        {/* ══ SERVICES ═══════════════════════════════════════════════════════ */}
        {tab === 'services' && (
          <div className="space-y-6">
            <div className="flex items-center justify-between">
              <h2 className="text-xl font-bold">Services</h2>
              <button onClick={() => { setEditService(null); setServiceForm({ name: '', category: 'Salon', description: '', price: '', location: '', contactNumber: user?.phone || '', email: user?.email || '', availabilitySchedule: 'Mon-Sat: 9am-6pm', images: [] }); setShowServForm(true); }}
                className="bg-pink-500 text-white px-4 py-2 rounded-xl text-sm font-bold hover:bg-pink-600 transition-colors flex items-center gap-2">
                <Plus className="w-4 h-4" /> List Service
              </button>
            </div>

            {loadingServ ? (
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {Array.from({length:4}).map((_,i)=><div key={i} className="h-40 bg-pink-50 rounded-2xl animate-pulse" />)}
              </div>
            ) : services.length === 0 ? (
              <div className="text-center py-20 bg-pink-50 rounded-2xl border border-pink-100">
                <Hammer className="w-12 h-12 text-pink-200 mx-auto mb-3" />
                <p className="text-gray-500 font-semibold">No services listed yet</p>
              </div>
            ) : (
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {services.map(s => (
                  <div key={s.id} className="bg-white border border-pink-100 p-5 rounded-2xl flex gap-4">
                    <div className="w-20 h-20 bg-pink-50 rounded-xl overflow-hidden flex-shrink-0">
                      {s.images?.[0] ? <img src={s.images[0]} className="w-full h-full object-cover" /> : <Hammer className="w-8 h-8 text-pink-200 m-auto mt-6" />}
                    </div>
                    <div className="flex-1">
                      <div className="flex justify-between items-start">
                        <h3 className="font-bold text-gray-900">{s.name}</h3>
                        <p className="font-bold text-pink-500 text-sm">KSH {s.price.toLocaleString()}</p>
                      </div>
                      <p className="text-xs text-gray-400 mt-1 line-clamp-1">{s.category} · {s.location}</p>
                      <div className="flex items-center gap-2 mt-3">
                        <button onClick={() => { setEditService(s); setServiceForm(s); setShowServForm(true); }} className="text-xs font-bold text-gray-500 hover:text-pink-500 transition-colors">Edit</button>
                        <button onClick={async () => { if(confirm('Delete?')) { await DEL(`/api/seller/services/${s.id}`); fetchServices(); } }} className="text-xs font-bold text-red-400 hover:text-red-500 transition-colors">Delete</button>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            )}

            {/* Service Form Modal */}
            {showServForm && (
              <div className="fixed inset-0 z-50 bg-black/50 flex items-center justify-center p-4" onClick={() => setShowServForm(false)}>
                <div className="bg-white rounded-2xl shadow-2xl w-full max-w-lg max-h-[90vh] overflow-y-auto" onClick={e => e.stopPropagation()}>
                   <div className="flex items-center justify-between p-5 border-b border-pink-100">
                     <h3 className="font-bold">{editService ? 'Edit Service' : 'List Service'}</h3>
                     <button onClick={() => setShowServForm(false)}><X className="w-5 h-5 text-gray-400" /></button>
                   </div>
                   <div className="p-5 space-y-4">
                      <div>
                        <label className="block text-xs font-semibold text-gray-500 uppercase mb-1">Service Name</label>
                        <input type="text" value={serviceForm.name} onChange={e => setServiceForm({...serviceForm, name: e.target.value})} className="w-full bg-pink-50 border border-pink-200 rounded-xl py-2.5 px-3 text-sm focus:outline-none focus:border-pink-500" />
                      </div>
                      <div className="grid grid-cols-2 gap-4">
                        <div>
                          <label className="block text-xs font-semibold text-gray-500 uppercase mb-1">Price (KSH)</label>
                          <input type="number" value={serviceForm.price} onChange={e => setServiceForm({...serviceForm, price: e.target.value})} className="w-full bg-pink-50 border border-pink-200 rounded-xl py-2.5 px-3 text-sm focus:outline-none focus:border-pink-500" />
                        </div>
                        <div>
                          <label className="block text-xs font-semibold text-gray-500 uppercase mb-1">Category</label>
                          <select value={serviceForm.category} onChange={e => setServiceForm({...serviceForm, category: e.target.value})} className="w-full bg-pink-50 border border-pink-200 rounded-xl py-2.5 px-3 text-sm focus:outline-none focus:border-pink-500">
                            <option value="Salon">Salon & Beauty</option>
                            <option value="Tech">Tech Support</option>
                            <option value="Tutorials">Tutorials</option>
                            <option value="Cleaning">Cleaning & Errands</option>
                            <option value="Creative">Design & Creative</option>
                          </select>
                        </div>
                      </div>
                      <div>
                        <label className="block text-xs font-semibold text-gray-500 uppercase mb-1">Location / Working Hours</label>
                        <input type="text" value={serviceForm.location} onChange={e => setServiceForm({...serviceForm, location: e.target.value})} className="w-full bg-pink-50 border border-pink-200 rounded-xl py-2.5 px-3 text-sm focus:outline-none focus:border-pink-500" />
                      </div>
                      <div>
                        <label className="block text-xs font-semibold text-gray-500 uppercase mb-1">Image URL</label>
                        <input type="url" value={serviceForm.images[0] || ''} onChange={e => setServiceForm({...serviceForm, images: [e.target.value]})} className="w-full bg-pink-50 border border-pink-200 rounded-xl py-2.5 px-3 text-sm focus:outline-none focus:border-pink-500" />
                      </div>
                      <button onClick={saveService} className="w-full bg-pink-500 text-white font-bold py-3 rounded-xl hover:bg-pink-600 transition-colors">
                        {editService ? 'Update Service' : 'List Service'}
                      </button>
                   </div>
                </div>
              </div>
            )}
          </div>
        )}

        {/* ══ FLASH SALES ═════════════════════════════════════════════════════ */}
        {tab === 'flash-sales' && (
          <div className="space-y-6">
            <div className="flex items-center justify-between">
              <h2 className="text-xl font-bold">Flash Sales</h2>
              <button onClick={() => setShowFlashForm(true)}
                className="bg-rose-500 text-white px-4 py-2 rounded-xl text-sm font-bold hover:bg-rose-600 transition-colors flex items-center gap-2">
                <Zap className="w-4 h-4" /> Create Flash Sale
              </button>
            </div>

            {flashSales.length === 0 ? (
              <div className="text-center py-20 bg-rose-50 rounded-2xl border border-rose-100">
                <Zap className="w-12 h-12 text-rose-200 mx-auto mb-3" />
                <p className="text-gray-500 font-semibold">No active flash sales</p>
                <p className="text-xs text-gray-400 mt-1">Boost products by offering limited-time deals</p>
              </div>
            ) : (
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                {flashSales.map(fs => (
                  <div key={fs.id} className="bg-white border-2 border-rose-500/20 rounded-2xl overflow-hidden relative group">
                    <div className="aspect-video bg-rose-50 relative">
                       <img src={fs.bannerImage || products.find(p=>p.id===fs.productId)?.images?.[0]?.url} className="w-full h-full object-cover" />
                       <div className="absolute inset-0 bg-gradient-to-t from-rose-900/60 to-transparent" />
                       <div className="absolute top-2 right-2 bg-rose-500 text-white text-[10px] font-black px-2 py-0.5 rounded-lg shadow-lg flex items-center gap-1 animate-pulse">
                         <Zap className="w-3 h-3 fill-current" /> ACTIVE
                       </div>
                    </div>
                    <div className="p-4">
                      <h3 className="font-bold text-gray-900">{products.find(p=>p.id===fs.productId)?.title || 'Flash Deal'}</h3>
                      <div className="flex items-center gap-3 mt-1">
                        <p className="font-black text-rose-600">KSH {fs.flashPrice.toLocaleString()}</p>
                        <p className="text-xs text-gray-400 line-through">KSH {products.find(p=>p.id===fs.productId)?.price.toLocaleString()}</p>
                      </div>
                      <div className="mt-3 flex items-center justify-between text-[10px] text-gray-400 font-bold">
                        <span>Starts: {new Date(fs.startTime).toLocaleDateString()}</span>
                        <span>Ends: {new Date(fs.endTime).toLocaleDateString()}</span>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            )}

            {showFlashForm && (
              <div className="fixed inset-0 z-50 bg-black/50 flex items-center justify-center p-4" onClick={() => setShowFlashForm(false)}>
                <div className="bg-white rounded-2xl shadow-2xl w-full max-w-md" onClick={e => e.stopPropagation()}>
                  <div className="flex items-center justify-between p-5 border-b">
                    <h3 className="font-bold flex items-center gap-2"><Zap className="w-4 h-4 text-rose-500" /> Create Flash Sale</h3>
                    <button onClick={() => setShowFlashForm(false)}><X className="w-5 h-5 text-gray-400" /></button>
                  </div>
                  <div className="p-5 space-y-4">
                    <div>
                      <label className="block text-xs font-semibold text-gray-500 mb-1 uppercase tracking-widest">Select Product</label>
                      <select value={flashForm.productId} onChange={e => setFlashForm({...flashForm, productId: e.target.value})} className="w-full bg-rose-50 border border-rose-100 rounded-xl py-3 px-4 text-sm focus:outline-none focus:border-rose-500 shadow-inner">
                        <option value="">Choose a product...</option>
                        {products.map(p => <option key={p.id} value={p.id}>{p.title} (Currently KSH {p.price})</option>)}
                      </select>
                    </div>
                    <div>
                      <label className="block text-xs font-semibold text-gray-500 mb-1 uppercase tracking-widest">Flash Sale Price (KSH)</label>
                      <input type="number" value={flashForm.flashPrice} onChange={e => setFlashForm({...flashForm, flashPrice: e.target.value})} className="w-full bg-rose-50 border border-rose-100 rounded-xl py-3 px-4 text-sm focus:outline-none focus:border-rose-500" />
                    </div>
                    <div>
                      <label className="block text-xs font-semibold text-gray-500 mb-1 uppercase tracking-widest">Banner Image URL</label>
                      <input type="text" value={flashForm.bannerImage} onChange={e => setFlashForm({...flashForm, bannerImage: e.target.value})} placeholder="e.g. https://..." className="w-full bg-rose-50 border border-rose-100 rounded-xl py-3 px-4 text-sm focus:outline-none focus:border-rose-500" />
                    </div>
                    <div className="grid grid-cols-2 gap-4">
                      <div>
                        <label className="block text-xs font-semibold text-gray-500 mb-1 uppercase tracking-widest text-[9px]">Start Time</label>
                        <input type="datetime-local" value={flashForm.startTime} onChange={e => setFlashForm({...flashForm, startTime: e.target.value})} className="w-full bg-rose-50 border border-rose-100 rounded-xl py-2 px-3 text-xs focus:outline-none focus:border-rose-500" />
                      </div>
                      <div>
                        <label className="block text-xs font-semibold text-gray-500 mb-1 uppercase tracking-widest text-[9px]">End Time</label>
                        <input type="datetime-local" value={flashForm.endTime} onChange={e => setFlashForm({...flashForm, endTime: e.target.value})} className="w-full bg-rose-50 border border-rose-100 rounded-xl py-2 px-3 text-xs focus:outline-none focus:border-rose-500" />
                      </div>
                    </div>
                    <button onClick={saveFlashSale} className="w-full bg-rose-500 text-white font-black py-4 rounded-xl hover:bg-rose-600 transition-all uppercase tracking-widest shadow-lg shadow-rose-500/20">
                      Activate Deal
                    </button>
                  </div>
                </div>
              </div>
            )}
          </div>
        )}

        {/* ══ ORDERS ══════════════════════════════════════════════════════════ */}
        {tab === 'orders' && (
          <div className="space-y-6">
            <div className="flex items-center justify-between">
              <h2 className="text-xl font-bold">Orders</h2>
              <div className="flex gap-2">
                {['', 'PENDING', 'PROCESSING', 'DELIVERED', 'CANCELLED'].map(s => (
                  <button key={s} onClick={() => setOrderFilter(s)}
                    className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-all ${orderFilter === s ? 'bg-pink-500 text-white' : 'bg-pink-50 text-pink-600 border border-pink-100'}`}>
                    {s || 'All'}
                  </button>
                ))}
              </div>
            </div>

            {loadingOrd ? (
              <div className="space-y-4">
                {Array.from({length:5}).map((_,i)=><div key={i} className="h-24 bg-pink-50 rounded-2xl animate-pulse" />)}
              </div>
            ) : orders.length === 0 ? (
              <div className="text-center py-20 bg-pink-50 rounded-2xl border border-pink-100">
                <ShoppingCart className="w-12 h-12 text-pink-200 mx-auto mb-3" />
                <p className="text-gray-500 font-semibold">No orders yet</p>
              </div>
            ) : (
              <div className="space-y-4">
                {orders.map(o => (
                  <div key={o.id} className="bg-white border border-pink-100 p-5 rounded-2xl flex flex-col md:flex-row gap-4">
                    <div className="flex-1 flex gap-4">
                      <div className="w-16 h-16 bg-pink-50 rounded-xl overflow-hidden flex-shrink-0">
                        {o.items?.[0]?.product?.images?.[0]?.url && <img src={o.items[0].product.images[0].url} className="w-full h-full object-cover" />}
                      </div>
                      <div className="min-w-0">
                        <div className="flex items-center gap-2">
                          <p className="font-bold text-sm">Order #{o.id.slice(-6).toUpperCase()}</p>
                          <span className={`text-[9px] font-black px-2 py-0.5 rounded-full uppercase ${STATUS_COLOR[o.status]}`}>{o.status.replace(/_/g, ' ')}</span>
                        </div>
                        <p className="text-xs text-gray-500 mt-1 capitalize">{o.items?.map((i:any)=>i.product?.name).join(', ')}</p>
                        <p className="text-[10px] text-gray-400 border-t border-pink-50 pt-1 mt-1 font-medium">Buyer: {o.buyer?.name} ({o.buyer?.campus})</p>
                      </div>
                    </div>
                    <div className="flex items-center justify-between md:flex-col md:items-end md:justify-center gap-4 border-t md:border-t-0 md:border-l border-pink-100 pt-4 md:pt-0 md:pl-6">
                      <div className="text-right">
                        <p className="font-black text-pink-500 text-lg">KSH {o.total.toLocaleString()}</p>
                        <p className="text-[9px] font-bold text-gray-400 tracking-widest uppercase">{o.paymentMethod || 'WALLET'}</p>
                      </div>
                      <div className="flex gap-2">
                        {o.status !== 'DELIVERED' && o.status !== 'CANCELLED' && (
                          <>
                            <button 
                              onClick={() => updateOrderStatus(o.id, o.status)}
                              disabled={!!updatingOrd}
                              className="bg-gray-900 text-white px-4 py-2 rounded-xl text-xs font-bold hover:bg-pink-600 transition-all flex items-center gap-2 whitespace-nowrap"
                            >
                              {updatingOrd === o.id ? <RefreshCw className="w-3 h-3 animate-spin"/> : <ChevronRight className="w-3 h-3" />}
                              {STATUS_LABEL[o.status]}
                            </button>
                            <button onClick={() => cancelOrder(o.id)} className="p-2 text-red-500 hover:bg-red-50 rounded-xl transition-colors">
                              <XCircle className="w-5 h-5" />
                            </button>
                          </>
                        )}
                        {o.status === 'DELIVERED' && <div className="text-emerald-500 flex items-center gap-1 font-bold text-xs"><CheckCircle className="w-4 h-4" /> COMPLETED</div>}
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        )}

        {/* ══ WALLET ══════════════════════════════════════════════════════════ */}
        {tab === 'wallet' && (
          <div className="space-y-5 max-w-2xl">
            <h2 className="text-xl font-bold">Seller Wallet</h2>

            {/* Balance cards */}
            <div className="grid grid-cols-2 gap-4">
              <div className="bg-gradient-to-br from-green-50 to-white border border-green-200 rounded-2xl p-5 relative group">
                <div className="flex justify-between items-start mb-1">
                  <p className="text-xs text-gray-500 font-semibold uppercase tracking-wide">Available Balance</p>
                  <button onClick={() => setHideBalance(!hideBalance)} className="p-1 hover:bg-green-100 rounded-lg transition-colors text-green-600">
                    {hideBalance ? <Eye className="w-3.5 h-3.5" /> : <EyeOff className="w-3.5 h-3.5" />}
                  </button>
                </div>
                <p className="text-3xl font-bold text-green-600 truncate">
                  {hideBalance ? '••••••' : `KSH ${(wallet?.balance ?? 0).toLocaleString()}`}
                </p>
                <p className="text-xs text-gray-400 mt-1">Ready to withdraw</p>
              </div>
              <div className="bg-gradient-to-br from-pink-50 to-white border border-pink-200 rounded-2xl p-5">
                <p className="text-xs text-gray-500 font-semibold uppercase tracking-wide mb-1">Total Earned</p>
                <p className="text-3xl font-bold text-pink-600 truncate">
                  {hideBalance ? '••••••' : `KSH ${(analytics?.revenue?.total ?? 0).toLocaleString()}`}
                </p>
                <p className="text-xs text-gray-400 mt-1">All time</p>
              </div>
            </div>

            {/* Payout form */}
            <div className="bg-pink-50 border border-pink-100 rounded-[2.5rem] p-8 space-y-6">
              <div className="flex items-center gap-3">
                 <div className="w-12 h-12 bg-emerald-500 rounded-2xl flex items-center justify-center text-white shadow-lg">
                    <Wallet className="w-6 h-6" />
                 </div>
                 <div>
                    <h3 className="font-black text-gray-900 leading-none">REQUEST PAYOUT</h3>
                    <p className="text-[10px] text-gray-400 font-bold uppercase tracking-widest mt-1">Direct to M-PESA</p>
                 </div>
              </div>

              <div className="space-y-4">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <label className="text-[10px] font-black text-gray-400 uppercase tracking-widest mb-1.5 block ml-1">Amount (KSH)</label>
                    <input type="number" value={payoutAmt} onChange={e => setPayoutAmt(e.target.value)} placeholder="Min 100"
                      className="w-full bg-white border border-pink-200 rounded-2xl py-3.5 px-4 text-sm font-bold focus:outline-none focus:border-emerald-500 shadow-inner" />
                  </div>
                  <div>
                    <label className="text-[10px] font-black text-gray-400 uppercase tracking-widest mb-1.5 block ml-1">M-Pesa Phone</label>
                    <input type="tel" value={payoutPhone} onChange={e => setPayoutPhone(e.target.value)} placeholder="07XX..."
                      className="w-full bg-white border border-pink-200 rounded-2xl py-3.5 px-4 text-sm font-bold focus:outline-none focus:border-emerald-500 shadow-inner" />
                  </div>
                </div>

                <div className="p-4 bg-white border border-pink-100 rounded-2xl">
                   <p className="text-[10px] font-black text-gray-400 uppercase tracking-widest mb-2">Payout Terms</p>
                   <div className="space-y-2">
                      <div className="flex items-center gap-2 text-xs font-medium text-gray-600">
                         <CheckCircle className="w-3 h-3 text-emerald-500" /> 
                         <span>Process time: 1-2 Campus working days.</span>
                      </div>
                      <div className="flex items-center gap-2 text-xs font-medium text-gray-600">
                         <CheckCircle className="w-3 h-3 text-emerald-500" /> 
                         <span>KAMPAS charges 3% platform fee on each withdrawal.</span>
                      </div>
                      <div className="flex items-center gap-2 text-xs font-medium text-gray-600">
                         <CheckCircle className="w-3 h-3 text-emerald-500" /> 
                         <span>Ensure M-Pesa number is correct. Reversal is not possible.</span>
                      </div>
                   </div>
                </div>

                <div className="flex items-start gap-2 p-1">
                   <input type="checkbox" id="tos" className="mt-1 accent-emerald-500" />
                   <label htmlFor="tos" className="text-[10px] text-gray-500 leading-tight">
                      I agree to the <b>Seller Payout Terms</b> and confirm that my provided business details are accurate.
                   </label>
                </div>
              </div>

              {payoutMsg && (
                <div className={`p-4 rounded-2xl text-xs font-bold border ${payoutMsg.includes('requested') ? 'bg-emerald-50 border-emerald-200 text-emerald-600' : 'bg-red-50 border-red-200 text-red-600'}`}>
                   {payoutMsg}
                </div>
              )}

              <button onClick={requestPayout} disabled={payingOut || !payoutAmt}
                className="w-full bg-emerald-500 text-white font-black py-4 rounded-2xl hover:bg-emerald-600 transition-all flex items-center justify-center gap-3 disabled:opacity-50 shadow-xl shadow-emerald-500/20 active:scale-95 uppercase tracking-widest">
                {payingOut ? <RefreshCw className="w-5 h-5 animate-spin" /> : <ArrowUpRight className="w-5 h-5" />}
                {payingOut ? 'Sending Request...' : 'Initiate Withdrawal'}
              </button>
            </div>

            {/* Transactions */}
            <div className="bg-pink-50 border border-pink-200 rounded-3xl overflow-hidden">
              <div className="p-5 border-b border-pink-100 flex items-center justify-between bg-white">
                <h3 className="font-black text-xs uppercase tracking-widest text-gray-900">Transaction History</h3>
                <RefreshCw onClick={fetchWallet} className="w-4 h-4 text-pink-500 cursor-pointer hover:rotate-180 transition-transform duration-500" />
              </div>
              {wallet?.transactions?.length === 0 ? (
                <div className="text-center py-16 text-gray-400 text-sm">
                   <div className="w-16 h-16 bg-white rounded-full flex items-center justify-center mx-auto mb-4 border border-pink-50 shadow-sm">
                      <Clock className="w-8 h-8 text-pink-100" />
                   </div>
                   No transactions found.
                </div>
              ) : (
                <div className="divide-y divide-pink-100">
                  {wallet?.transactions?.map((tx: any) => (
                    <div key={tx.id} className="flex items-center justify-between px-6 py-4 bg-white/50 hover:bg-white transition-colors">
                      <div className="flex items-center gap-4">
                        <div className={`p-2 rounded-xl ${tx.amount > 0 ? 'bg-emerald-50 text-emerald-500' : 'bg-rose-50 text-rose-500'}`}>
                           {tx.amount > 0 ? <Plus className="w-4 h-4" /> : <ArrowUpRight className="w-4 h-4" />}
                        </div>
                        <div>
                          <p className="text-sm font-bold text-gray-900 uppercase tracking-tight">{tx.description || tx.type.replace(/_/g, ' ')}</p>
                          <p className="text-[10px] text-gray-400 font-bold">{new Date(tx.createdAt).toLocaleString()}</p>
                        </div>
                      </div>
                      <span className={`font-black text-sm ${tx.amount > 0 ? 'text-emerald-600' : 'text-rose-600'}`}>
                        {tx.amount > 0 ? '+' : ''}KSH {Math.abs(tx.amount).toLocaleString()}
                      </span>
                    </div>
                  ))}
                </div>
              )}
            </div>
          </div>
        )}

        {/* ══ TOS ═════════════════════════════════════════════════════════════ */}
        {tab === 'tos' && (
          <div className="max-w-3xl mx-auto space-y-8 py-8">
            <div className="text-center mb-10">
              <div className="w-20 h-20 bg-pink-100 rounded-3xl flex items-center justify-center mx-auto mb-6 text-pink-600">
                 <Info className="w-10 h-10" />
              </div>
              <h2 className="text-3xl font-black text-gray-900 uppercase">Merchant Guidelines</h2>
              <p className="text-gray-500 mt-2 font-medium">Terms of Service for KAMPAS Sellers & Partners</p>
            </div>

            <div className="space-y-6">
              {[
                { title: '1. Listing Integrity', content: 'Every product listed must be physically present and accurately described. Counterfeit goods or misleading descriptions will lead to immediate account suspension and revenue forfeiture.' },
                { title: '2. Transaction Fees', content: 'KAMPAS maintains a transparent 10% commission on marketplace sales. This covers marketing, AI enhancement tools, and payment infrastructure. Payouts are subject to a 3% M-Pesa processing fee.' },
                { title: '3. Order Fulfillment', content: 'Sellers are expected to confirm orders within 12 hours. Delivery should be initiated within 24-48 hours. Orders not processed within 72 hours are subject to automatic cancellation.' },
                { title: '4. Student Safety', content: 'All meetups for deliveries should ideally happen in open campus areas. High-value transactions are monitored for student safety. Report any suspicious buyer behavior immediately.' },
                { title: '5. Return & Refunds', content: 'Sellers must honor the return policy stated on their storefront settings. In case of disputes, KAMPAS Admin meditation is final.' }
              ].map((policy, i) => (
                <div key={i} className="bg-pink-50 border border-pink-100 p-8 rounded-[2.5rem]">
                   <h3 className="text-lg font-black text-gray-900 mb-4">{policy.title}</h3>
                   <p className="text-sm text-gray-600 leading-relaxed font-medium">{policy.content}</p>
                </div>
              ))}
            </div>

            <div className="bg-gray-900 text-white p-8 rounded-[2.5rem] flex items-center justify-between">
              <div>
                <p className="text-[10px] font-black text-gray-400 uppercase tracking-widest mb-1">Last Updated</p>
                <p className="text-xs font-bold">June 1st, 2026</p>
              </div>
              <button className="bg-pink-500 text-gray-900 px-6 py-3 rounded-2xl font-black text-xs uppercase tracking-widest hover:bg-pink-600 transition-colors">
                Print Copy
              </button>
            </div>
          </div>
        )}

        {/* ══ STORE ═══════════════════════════════════════════════════════════ */}
        {tab === 'store' && (
          <div className="space-y-5 max-w-2xl">
            <h2 className="text-xl font-bold">Store Settings</h2>
            {storeMsg && <div className={`p-3 rounded-xl text-sm font-medium ${storeMsg.includes('success') ? 'bg-green-50 border border-green-200 text-green-700' : 'bg-red-50 border border-red-200 text-red-600'}`}>{storeMsg}</div>}
            {store && (
              <div className="space-y-4">
                {[
                  { key: 'name',           label: 'Store Name',        type: 'text',     placeholder: 'Your Store Name' },
                  { key: 'description',    label: 'Store Description', type: 'textarea', placeholder: 'What do you sell?' },
                  { key: 'banner',         label: 'Banner Image URL',  type: 'url',      placeholder: 'https://...' },
                  { key: 'logo',           label: 'Logo Image URL',    type: 'url',      placeholder: 'https://...' },
                  { key: 'returnPolicy',   label: 'Return Policy',     type: 'textarea', placeholder: 'e.g. No returns after 24hrs' },
                  { key: 'deliveryPolicy', label: 'Delivery Policy',   type: 'textarea', placeholder: 'e.g. Delivery within campus only' },
                ].map(f => (
                  <div key={f.key}>
                    <label className="block text-xs font-semibold text-gray-500 uppercase tracking-wide mb-1.5">{f.label}</label>
                    {f.type === 'textarea' ? (
                      <textarea value={storeForm[f.key] || ''} rows={3} placeholder={f.placeholder}
                        onChange={e => setStoreForm((p: any) => ({ ...p, [f.key]: e.target.value }))}
                        className="w-full bg-pink-50 border border-pink-200 rounded-xl py-2.5 px-3 text-sm focus:outline-none focus:border-pink-500 resize-none" />
                    ) : (
                      <input type={f.type} value={storeForm[f.key] || ''} placeholder={f.placeholder}
                        onChange={e => setStoreForm((p: any) => ({ ...p, [f.key]: e.target.value }))}
                        className="w-full bg-pink-50 border border-pink-200 rounded-xl py-2.5 px-3 text-sm focus:outline-none focus:border-pink-500" />
                    )}
                  </div>
                ))}

                <div className="flex items-center justify-between bg-pink-50 border border-pink-100 rounded-xl p-4">
                  <div>
                    <p className="text-sm font-semibold">Store Status</p>
                    <p className="text-xs text-gray-400">{storeForm.vacationMode ? 'On vacation — store hidden' : 'Open for business'}</p>
                  </div>
                  <button onClick={() => setStoreForm((p: any) => ({ ...p, vacationMode: !p.vacationMode }))}
                    className={`relative w-12 h-6 rounded-full transition-colors ${storeForm.vacationMode ? 'bg-gray-300' : 'bg-green-500'}`}>
                    <div className={`absolute top-0.5 w-5 h-5 bg-white rounded-full shadow transition-transform ${storeForm.vacationMode ? 'left-0.5' : 'left-6'}`} />
                  </button>
                </div>

                <button onClick={saveStore} disabled={savingStore}
                  className="w-full bg-pink-500 text-white font-bold py-3 rounded-xl hover:bg-pink-600 transition-colors flex items-center justify-center gap-2 disabled:opacity-60">
                  {savingStore ? <RefreshCw className="w-4 h-4 animate-spin" /> : <Save className="w-4 h-4" />}
                  {savingStore ? 'Saving...' : 'Save Store Settings'}
                </button>
              </div>
            )}
          </div>
        )}

        {/* ══ ADS ═════════════════════════════════════════════════════════════ */}
        {tab === 'ads' && (
          <div className="space-y-6">
            {/* Hero */}
            <div className="bg-gradient-to-br from-pink-50 to-white border border-pink-200 rounded-2xl p-6 flex flex-col md:flex-row items-center justify-between gap-4 relative overflow-hidden">
              <div className="absolute -right-10 -top-10 w-40 h-40 bg-pink-300/20 rounded-full blur-3xl" />
              <div>
                <p className="text-xs font-bold text-pink-500 uppercase tracking-wider mb-2">Boost Visibility</p>
                <h2 className="text-2xl font-black text-gray-900">Reach 50,000+ Students Daily</h2>
                <p className="text-gray-500 text-sm mt-1">Target specific campuses. Get more orders.</p>
              </div>
              <button onClick={() => setShowAdForm(true)}
                className="bg-pink-500 text-white px-5 py-2.5 rounded-xl font-bold hover:bg-pink-600 transition-colors flex items-center gap-2 flex-shrink-0">
                <Plus className="w-4 h-4" /> Create Campaign
              </button>
            </div>

            {/* Analytics */}
            {adAnalytics && (
              <div className="grid grid-cols-3 gap-4">
                {[
                  { label: 'Impressions', value: adAnalytics.totals?.impressions ?? 0 },
                  { label: 'Clicks',      value: adAnalytics.totals?.clicks ?? 0 },
                  { label: 'CTR',         value: `${adAnalytics.totals?.ctr ?? '0.00'}%` },
                ].map((s, i) => (
                  <div key={i} className="bg-pink-50 border border-pink-100 rounded-2xl p-4 text-center">
                    <p className="text-2xl font-bold text-gray-900">{s.value}</p>
                    <p className="text-xs text-gray-500 mt-1">{s.label}</p>
                  </div>
                ))}
              </div>
            )}

            {/* Ads list */}
            {ads.length === 0 ? (
              <div className="text-center py-16 bg-pink-50 rounded-2xl border border-pink-100">
                <Megaphone className="w-12 h-12 text-pink-200 mx-auto mb-3" />
                <p className="text-gray-500 font-semibold">No campaigns yet</p>
                <button onClick={() => setShowAdForm(true)} className="mt-4 bg-pink-500 text-white text-sm font-bold px-6 py-2 rounded-xl hover:bg-pink-600 transition-colors">
                  Create Your First Ad
                </button>
              </div>
            ) : (
              <div className="space-y-3">
                {ads.map(ad => (
                  <div key={ad.id} className="bg-white border border-pink-100 rounded-2xl p-4 flex items-center gap-4">
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-2">
                        <p className="font-bold text-sm">{ad.title}</p>
                        <span className={`text-[10px] font-bold px-2 py-0.5 rounded-full ${ad.status === 'ACTIVE' ? 'bg-green-100 text-green-700' : ad.status === 'PENDING' ? 'bg-yellow-100 text-yellow-700' : 'bg-gray-100 text-gray-600'}`}>{ad.status}</span>
                      </div>
                      {ad.targetCampus && <p className="text-xs text-gray-400 mt-0.5">📍 {ad.targetCampus}</p>}
                      <div className="flex gap-3 mt-1 text-xs text-gray-400">
                        <span>👁 {ad.impressions}</span>
                        <span>🖱 {ad.clicks}</span>
                        <span>💰 KSH {ad.budget.toLocaleString()} budget</span>
                      </div>
                    </div>
                    <button onClick={async () => { await DEL(`/api/seller/ads/${ad.id}`); fetchAds(); }} className="p-2 text-red-400 hover:text-red-600 transition-colors">
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>
                ))}
              </div>
            )}

            {/* Ad Form Modal */}
            {showAdForm && (
              <div className="fixed inset-0 z-50 bg-black/50 flex items-center justify-center p-4" onClick={() => setShowAdForm(false)}>
                <div className="bg-white rounded-2xl shadow-2xl w-full max-w-md" onClick={e => e.stopPropagation()}>
                  <div className="flex items-center justify-between p-5 border-b border-pink-100">
                    <h3 className="font-bold">Create Ad Campaign</h3>
                    <button onClick={() => setShowAdForm(false)}><X className="w-5 h-5 text-gray-400" /></button>
                  </div>
                  <div className="p-5 space-y-4">
                    {[
                      { key: 'title',        label: 'Campaign Title',    placeholder: 'e.g. Summer Sale - Sneakers' },
                      { key: 'description',  label: 'Ad Description',    placeholder: 'What are you promoting?' },
                      { key: 'targetCampus', label: 'Target Campus',      placeholder: 'e.g. JKUAT Main (leave blank for all)' },
                      { key: 'budget',       label: 'Budget (KSH)',       placeholder: 'Min KSH 100', type: 'number' },
                    ].map(f => (
                      <div key={f.key}>
                        <label className="block text-xs font-semibold text-gray-500 uppercase tracking-wide mb-1">{f.label}</label>
                        <input type={f.type || 'text'} value={(adForm as any)[f.key]} placeholder={f.placeholder}
                          onChange={e => setAdForm(p => ({ ...p, [f.key]: e.target.value }))}
                          className="w-full bg-pink-50 border border-pink-200 rounded-xl py-2.5 px-3 text-sm focus:outline-none focus:border-pink-500" />
                      </div>
                    ))}
                    <p className="text-xs text-gray-400 bg-yellow-50 border border-yellow-200 rounded-xl p-3">
                      Budget will be deducted from your seller balance. Ads are reviewed within 24 hours.
                    </p>
                    <button onClick={createAd} disabled={savingAd || !adForm.title || !adForm.budget}
                      className="w-full bg-pink-500 text-white font-bold py-3 rounded-xl hover:bg-pink-600 transition-colors flex items-center justify-center gap-2 disabled:opacity-60">
                      {savingAd ? <RefreshCw className="w-4 h-4 animate-spin" /> : <Megaphone className="w-4 h-4" />}
                      {savingAd ? 'Submitting...' : 'Submit Campaign'}
                    </button>
                  </div>
                </div>
              </div>
            )}
          </div>
        )}

        {/* ══ REFERRALS ═══════════════════════════════════════════════════════════ */}
        {tab === 'referrals' && (
          <div className="space-y-6 max-w-2xl">
            <div className="bg-gradient-to-br from-pink-500 to-rose-600 rounded-[2.5rem] p-8 text-white shadow-2xl relative overflow-hidden">
               <div className="absolute -right-20 -top-20 w-64 h-64 bg-white/10 rounded-full blur-3xl text-white"></div>
               <div className="relative z-10">
                  <div className="flex items-center gap-3 mb-6">
                    <div className="w-12 h-12 bg-white/20 backdrop-blur-md rounded-2xl flex items-center justify-center border border-white/30">
                       <Users className="w-6 h-6" />
                    </div>
                    <div>
                      <h2 className="text-xl font-black uppercase tracking-tight">Refer a Seller</h2>
                      <p className="text-pink-100 text-[10px] font-bold uppercase tracking-widest mt-1">Lower your service fees</p>
                    </div>
                  </div>

                  <div className="bg-white/10 backdrop-blur-md rounded-3xl p-6 border border-white/20 mb-8">
                     <p className="text-xs font-bold mb-4 opacity-90 leading-relaxed">
                        Refer other student sellers to Kampas. For every referred seller boardable, you get <b>-1% off</b> your base service fee.
                     </p>
                     
                     <div className="flex gap-4 mb-4">
                        <div className="flex-1 bg-black/20 rounded-2xl p-4 text-center">
                           <p className="text-[10px] font-black uppercase tracking-widest text-pink-200 mb-1">Standard Fee</p>
                           <p className="text-2xl font-black">10%</p>
                        </div>
                        <div className="flex-1 bg-white/20 rounded-2xl p-4 text-center">
                           <p className="text-[10px] font-black uppercase tracking-widest text-pink-200 mb-1">Your Fee</p>
                           <p className="text-2xl font-black text-emerald-400">{referralsData?.currentFee ?? 10}%</p>
                        </div>
                     </div>
                  </div>

                  <div className="space-y-2">
                     <label className="text-[10px] font-black uppercase tracking-widest ml-2 opacity-70">Your Referral Link</label>
                     <div className="flex gap-2">
                        <div className="flex-1 bg-black/20 backdrop-blur border border-white/10 rounded-2xl py-4 px-4 text-xs font-bold truncate">
                           {window.location.origin}/register?ref={referralsData?.referralCode}
                        </div>
                        <button 
                          onClick={() => {
                            navigator.clipboard.writeText(`${window.location.origin}/register?ref=${referralsData?.referralCode}`);
                            setCopied(true);
                            setTimeout(() => setCopied(false), 2000);
                          }}
                          className={`px-6 rounded-2xl font-black text-[10px] uppercase tracking-widest transition-all ${copied ? 'bg-emerald-500 text-white' : 'bg-white text-gray-900 hover:bg-pink-50'}`}
                        >
                          {copied ? 'Copied!' : 'Copy'}
                        </button>
                     </div>
                  </div>
               </div>
            </div>

            <div className="bg-pink-50 border border-pink-100 rounded-3xl overflow-hidden">
               <div className="p-5 border-b border-pink-100 bg-white flex items-center justify-between">
                  <h3 className="text-[10px] font-black uppercase tracking-widest text-gray-900">Your Referred Sellers</h3>
                  <span className="bg-pink-100 text-pink-600 px-3 py-1 rounded-full text-[10px] font-black">{referralsData?.referrals?.length ?? 0}</span>
               </div>
               
               {loadingRef ? (
                 <div className="p-8 space-y-4">
                    {Array.from({length:3}).map((_,i) => <div key={i} className="h-16 bg-white/50 rounded-2xl animate-pulse"></div>)}
                 </div>
               ) : referralsData?.referrals?.length === 0 ? (
                 <div className="p-20 text-center text-gray-400">
                    <Users className="w-12 h-12 mx-auto mb-4 opacity-20" />
                    <p className="text-xs font-bold uppercase tracking-widest">No referrals yet</p>
                 </div>
               ) : (
                 <div className="divide-y divide-pink-100">
                    {referralsData?.referrals?.map((r: any, i: number) => (
                      <div key={i} className="p-5 flex items-center justify-between bg-white/50 hover:bg-white transition-colors">
                         <div className="flex items-center gap-4">
                            <div className="w-10 h-10 rounded-full bg-pink-100 flex items-center justify-center text-pink-500 font-bold">
                               {r.referredName?.[0] ?? 'S'}
                            </div>
                            <div>
                               <p className="text-sm font-bold text-gray-900 uppercase tracking-tight">{r.referredName}</p>
                               <p className="text-[10px] text-gray-400 font-bold uppercase tracking-widest">{r.referredCampus}</p>
                            </div>
                         </div>
                         <div className="text-right">
                            <p className="text-[10px] font-black text-emerald-500 uppercase tracking-tighter bg-emerald-50 px-2 py-1 rounded-lg">ACTIVE</p>
                            <p className="text-[9px] text-gray-400 mt-1">{new Date(r.createdAt).toLocaleDateString()}</p>
                         </div>
                      </div>
                    ))}
                 </div>
               )}
            </div>
          </div>
        )}
      </div>

      {/* Floating Sell Action Button */}
      <div className="fixed bottom-6 right-6 z-50">
        <button
          onClick={openAddProduct}
          type="button"
          className="flex items-center gap-2 bg-gradient-to-r from-pink-500 to-rose-600 text-white px-5 py-3.5 rounded-full shadow-2xl hover:bg-pink-600 hover:scale-105 active:scale-95 transition-all text-sm font-black uppercase tracking-wider group border border-pink-400 cursor-pointer"
          title="Sell / Add Product"
        >
          <ShoppingBag className="w-5 h-5 group-hover:rotate-12 transition-transform duration-300" />
          <span>Quick Sell</span>
        </button>
      </div>
    </div>
  );
}

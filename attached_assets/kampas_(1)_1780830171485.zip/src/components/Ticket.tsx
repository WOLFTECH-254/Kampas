import React, { useRef, useState } from 'react';
import { Download, CheckCircle, Calendar, MapPin, User, Ticket as TicketIcon, Loader2, X, Tag } from 'lucide-react';
import { motion } from 'motion/react';
import { toPng } from 'html-to-image';

interface TicketProps {
  ticket: any;
  onClose: () => void;
}

export default function Ticket({ ticket, onClose }: TicketProps) {
  const ticketRef = useRef<HTMLDivElement>(null);
  const [isDownloading, setIsDownloading] = useState(false);

  const handleDownload = async () => {
    if (!ticketRef.current) return;
    setIsDownloading(true);
    
    try {
      await new Promise(resolve => setTimeout(resolve, 500));
      const dataUrl = await toPng(ticketRef.current, {
        cacheBust: true,
        backgroundColor: '#ffffff',
      });
      
      const link = document.createElement('a');
      link.download = `Kampas-Ticket-${ticket.orderId || ticket.id}.png`;
      link.href = dataUrl;
      link.click();
    } catch (err) {
      console.error('Failed to download ticket:', err);
      window.print();
    } finally {
      setIsDownloading(false);
    }
  };

  const formatDate = (d: string) => new Date(d).toLocaleDateString('en-KE', { weekday: 'long', day: 'numeric', month: 'long', year: 'numeric' });
  const formatTime = (d: string) => new Date(d).toLocaleTimeString('en-KE', { hour: '2-digit', minute: '2-digit' });

  return (
    <div className="fixed inset-0 z-[200] bg-gray-900/90 backdrop-blur-xl flex items-center justify-center p-4 overflow-y-auto">
      <motion.div 
        initial={{ scale: 0.9, opacity: 0 }} 
        animate={{ scale: 1, opacity: 1 }}
        className="w-full max-w-lg bg-white rounded-[2.5rem] shadow-2xl overflow-hidden flex flex-col"
      >
        <div ref={ticketRef} className="bg-white">
          {/* Ticket Top - Brand */}
          <div className="bg-pink-600 p-8 text-white relative">
            <div className="absolute top-0 right-0 w-32 h-32 bg-white/10 rounded-full -mr-16 -mt-16 blur-2xl"></div>
            <div className="flex justify-between items-start relative z-10">
              <div>
                <h1 className="text-xl font-black tracking-tight">KAMPAS EVENTS</h1>
                <p className="text-[10px] font-bold uppercase tracking-[0.2em] opacity-80">Official Entry Pass</p>
              </div>
              <TicketIcon className="w-8 h-8 opacity-50" />
            </div>
            
            <div className="mt-8 relative z-10">
              <h2 className="text-2xl font-black leading-tight mb-2">{ticket.eventTitle || ticket.title}</h2>
              <div className="flex items-center gap-2 text-pink-100 text-xs font-bold uppercase tracking-widest">
                <Tag className="w-3.5 h-3.5" />
                <span>{ticket.price === 0 ? 'Free Admittance' : `KSH ${ticket.price.toLocaleString()} Standard`}</span>
              </div>
            </div>
          </div>

          {/* Ticket Body */}
          <div className="p-8 space-y-6">
            <div className="grid grid-cols-2 gap-6">
              <div className="space-y-1">
                <label className="text-[9px] font-black text-gray-400 uppercase tracking-widest block">Date</label>
                <div className="flex items-center gap-2 text-gray-900 font-bold text-xs">
                  <Calendar className="w-3.5 h-3.5 text-pink-500" />
                  <span>{formatDate(ticket.startDate)}</span>
                </div>
              </div>
              <div className="space-y-1">
                <label className="text-[9px] font-black text-gray-400 uppercase tracking-widest block">Time</label>
                <p className="text-gray-900 font-bold text-xs">{formatTime(ticket.startDate)}</p>
              </div>
            </div>

            <div className="space-y-1">
              <label className="text-[9px] font-black text-gray-400 uppercase tracking-widest block">Venue</label>
              <div className="flex items-center gap-2 text-gray-900 font-bold text-xs">
                <MapPin className="w-3.5 h-3.5 text-pink-500" />
                <span>{ticket.venue || ticket.campus}</span>
              </div>
            </div>

            <div className="border-t border-dashed border-gray-200 pt-6 mt-6 flex justify-between items-end">
              <div className="space-y-4">
                <div className="space-y-1">
                  <label className="text-[9px] font-black text-gray-400 uppercase tracking-widest block">Attendee</label>
                  <div className="flex items-center gap-2 text-gray-900 font-bold text-xs">
                    <User className="w-3.5 h-3.5 text-pink-500" />
                    <span>{ticket.buyerName || 'Kampas User'}</span>
                  </div>
                </div>
                <div className="space-y-1">
                  <label className="text-[9px] font-black text-gray-400 uppercase tracking-widest block">Ticket Number</label>
                  <p className="font-mono text-gray-900 font-bold text-xs">#{ticket.id?.slice(-8).toUpperCase() || 'TK-' + Date.now().toString().slice(-6)}</p>
                </div>
              </div>
              
              <div className="text-center">
                <img 
                  src={`https://api.qrserver.com/v1/create-qr-code/?size=150x150&data=${ticket.id || 'VALID-TICKET'}`} 
                  className="w-24 h-24 bg-white p-2 border border-gray-100 rounded-xl"
                  alt="QR Pass"
                />
                <p className="text-[8px] font-black text-gray-400 uppercase mt-2">Valid for single entry</p>
              </div>
            </div>
          </div>
        </div>

        {/* Actions */}
        <div className="p-8 bg-gray-900 flex gap-4">
           <button 
             onClick={handleDownload}
             disabled={isDownloading}
             className="flex-1 bg-white text-gray-900 py-4 rounded-2xl font-black text-[10px] uppercase tracking-widest flex items-center justify-center gap-2 hover:bg-pink-500 hover:text-white transition-all shadow-xl disabled:opacity-50"
           >
             {isDownloading ? <Loader2 className="w-4 h-4 animate-spin" /> : <Download className="w-4 h-4" />}
             {isDownloading ? 'Generating...' : 'Download Ticket'}
           </button>
           <button 
             onClick={onClose}
             className="flex-1 bg-gray-800 text-white py-4 rounded-2xl font-black text-[10px] uppercase tracking-widest flex items-center justify-center gap-2 hover:bg-gray-700 transition-all font-black"
           >
             Close
           </button>
        </div>
      </motion.div>
    </div>
  );
}

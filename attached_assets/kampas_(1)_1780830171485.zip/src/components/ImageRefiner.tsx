import React, { useRef, useState, useEffect } from 'react';
import { X, Check, Eraser, MousePointer2, Wand2, Info } from 'lucide-react';

interface ImageRefinerProps {
  image: string;
  onConfirm: (maskBase64: string) => void;
  onCancel: () => void;
}

export default function ImageRefiner({ image, onConfirm, onCancel }: ImageRefinerProps) {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const containerRef = useRef<HTMLDivElement>(null);
  const [isDrawing, setIsDrawing] = useState(false);
  const [brushSize, setBrushSize] = useState(30);
  const [hasDrawn, setHasDrawn] = useState(false);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const img = new Image();
    img.crossOrigin = "anonymous";
    img.src = image;
    img.onload = () => {
      const container = containerRef.current;
      if (!container) return;
      
      const containerWidth = container.clientWidth;
      const containerHeight = container.clientHeight;
      const imgAspect = img.width / img.height;
      
      let drawWidth = containerWidth;
      let drawHeight = containerWidth / imgAspect;
      
      if (drawHeight > containerHeight) {
        drawHeight = containerHeight;
        drawWidth = containerHeight * imgAspect;
      }
      
      canvas.width = drawWidth;
      canvas.height = drawHeight;
      ctx.drawImage(img, 0, 0, drawWidth, drawHeight);
    };
  }, [image]);

  const startDrawing = (e: React.MouseEvent | React.TouchEvent) => {
    setIsDrawing(true);
    draw(e);
  };

  const draw = (e: React.MouseEvent | React.TouchEvent) => {
    if (!isDrawing || !canvasRef.current) return;
    const canvas = canvasRef.current;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const rect = canvas.getBoundingClientRect();
    const x = ('touches' in e ? e.touches[0].clientX : e.clientX) - rect.left;
    const y = ('touches' in e ? e.touches[0].clientY : e.clientY) - rect.top;

    ctx.globalCompositeOperation = 'source-over';
    ctx.fillStyle = 'rgba(236, 72, 153, 0.4)'; // Pink highlight
    ctx.beginPath();
    ctx.arc(x, y, brushSize / 2, 0, Math.PI * 2);
    ctx.fill();
    setHasDrawn(true);
  };

  const stopDrawing = () => setIsDrawing(false);

  const handleConfirm = () => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    
    // Create a new canvas for the mask
    const maskCanvas = document.createElement('canvas');
    maskCanvas.width = canvas.width;
    maskCanvas.height = canvas.height;
    const maskCtx = maskCanvas.getContext('2d');
    if (!maskCtx) return;

    // We want the mask to be white where the user "painted" and black elsewhere
    // But our current main canvas has the image + the pink highlights.
    // Instead, I should have maintained a separate mask buffer or just clear and redraw
    // Let's just grab the current canvas as the "mask suggestion"
    // Actually, a better way is to send the base64 of what's on screen
    onConfirm(canvas.toDataURL('image/png'));
  };

  const clear = () => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;
    
    const img = new Image();
    img.src = image;
    img.onload = () => {
      ctx.clearRect(0, 0, canvas.width, canvas.height);
      ctx.drawImage(img, 0, 0, canvas.width, canvas.height);
      setHasDrawn(false);
    };
  };

  return (
    <div className="fixed inset-0 z-[100] bg-gray-900/95 backdrop-blur-xl flex flex-col items-center justify-center p-4">
      <div className="w-full max-w-4xl bg-white rounded-[2.5rem] overflow-hidden shadow-2xl flex flex-col h-[85vh]">
        
        {/* Header */}
        <div className="p-6 border-b border-gray-100 flex items-center justify-between bg-white">
          <div className="flex items-center gap-3">
             <div className="w-10 h-10 rounded-xl bg-pink-500 text-white flex items-center justify-center shadow-lg">
                <Wand2 className="w-5 h-5" />
             </div>
             <div>
               <h2 className="text-sm font-black text-gray-900 uppercase tracking-tight">AI REFINEMENT LAB</h2>
               <p className="text-[10px] text-gray-400 font-bold uppercase tracking-widest mt-0.5">Paint over parts you want to remove or fix</p>
             </div>
          </div>
          <button onClick={onCancel} className="p-2 hover:bg-gray-100 rounded-full transition-colors">
            <X className="w-6 h-6 text-gray-400" />
          </button>
        </div>

        {/* Canvas Area */}
        <div ref={containerRef} className="flex-1 bg-gray-50 flex items-center justify-center relative overflow-hidden p-8">
          <canvas
            ref={canvasRef}
            onMouseDown={startDrawing}
            onMouseMove={draw}
            onMouseUp={stopDrawing}
            onMouseLeave={stopDrawing}
            onTouchStart={startDrawing}
            onTouchMove={draw}
            onTouchEnd={stopDrawing}
            className="cursor-crosshair shadow-2xl rounded-xl bg-white max-w-full max-h-full transition-all"
          />
          
          {!hasDrawn && (
            <div className="absolute inset-x-0 bottom-12 flex justify-center pointer-events-none">
               <div className="bg-gray-900/80 backdrop-blur text-white px-6 py-3 rounded-2xl flex items-center gap-3 shadow-2xl border border-white/10 animate-bounce">
                  <MousePointer2 className="w-4 h-4 text-pink-400" />
                  <span className="text-[10px] font-black uppercase tracking-widest">Start painting to mask unwanted areas</span>
               </div>
            </div>
          )}
        </div>

        {/* Controls */}
        <div className="p-6 bg-white border-t border-gray-100 flex flex-wrap items-center justify-between gap-6">
          <div className="flex items-center gap-6">
            <div className="space-y-2">
              <label className="text-[9px] font-black text-gray-400 uppercase tracking-widest block">Brush Size: {brushSize}px</label>
              <input 
                type="range" min="10" max="100" value={brushSize} 
                onChange={(e) => setBrushSize(parseInt(e.target.value))}
                className="w-32 accent-pink-500"
              />
            </div>
            
            <button onClick={clear} className="flex items-center gap-2 px-4 py-2 hover:bg-gray-100 rounded-xl transition-colors text-xs font-bold text-gray-500">
               <Eraser className="w-4 h-4" /> Reset
            </button>
          </div>

          <div className="flex items-center gap-3">
             <div className="flex items-center gap-2 px-4 py-2 bg-pink-50 border border-pink-100 rounded-xl">
                <Info className="w-3.5 h-3.5 text-pink-500" />
                <span className="text-[10px] font-bold text-pink-600">AI will re-generate the masked areas</span>
             </div>
             <button 
               onClick={handleConfirm}
               disabled={!hasDrawn}
               className="bg-pink-500 text-white px-8 py-3 rounded-2xl font-black text-xs uppercase tracking-widest hover:bg-pink-600 transition-all shadow-xl disabled:opacity-50 flex items-center gap-2"
             >
               <Check className="w-4 h-4" /> Process Refinement
             </button>
          </div>
        </div>
      </div>
    </div>
  );
}

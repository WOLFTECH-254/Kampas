import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { X, ShoppingBag, MessageCircle, Clock, CheckCircle, ArrowRight, Zap } from 'lucide-react';
import { Product, User } from '../../types';

interface FlashSaleStoriesProps {
  sales: Product[];
}

export default function FlashSaleStories({ sales }: FlashSaleStoriesProps) {
  const [selectedSale, setSelectedSale] = useState<Product | null>(null);
  const [timeLeft, setSelectedTimeLeft] = useState<string>('');

  useEffect(() => {
    if (!selectedSale) return;
    
    const updateTime = () => {
      if (!selectedSale.flashSaleEnd) return;
      const end = new Date(selectedSale.flashSaleEnd).getTime();
      const now = new Date().getTime();
      const diff = end - now;

      if (diff <= 0) {
        setSelectedTimeLeft('EXPIRED');
        return;
      }

      const h = Math.floor(diff / 3600000);
      const m = Math.floor((diff % 3600000) / 60000);
      const s = Math.floor((diff % 60000) / 1000);
      setSelectedTimeLeft(`${h}h ${m}m ${s}s`);
    };

    updateTime();
    const interval = setInterval(updateTime, 1000);
    return () => clearInterval(interval);
  }, [selectedSale]);

  if (sales.length === 0) return null;

  return (
    <div className="w-full py-4">
      <div className="flex gap-4 overflow-x-auto pb-2 px-4 scrollbar-hide">
        {sales.map((sale) => (
          <button
            key={sale.id}
            onClick={() => setSelectedSale(sale)}
            className="flex flex-col items-center gap-1.5 flex-shrink-0 group"
          >
            <div className="relative">
              {/* Pink Story Ring */}
              <div className="w-20 h-20 rounded-full bg-gradient-to-tr from-pink-500 via-rose-500 to-amber-400 p-[3px] group-active:scale-95 transition-transform">
                <div className="w-full h-full rounded-full bg-white p-0.5">
                  <img
                    src={sale.images[0] || 'https://via.placeholder.com/150'}
                    alt={sale.name}
                    className="w-full h-full rounded-full object-cover border border-pink-100"
                  />
                </div>
              </div>
              <div className="absolute -bottom-1 left-1/2 -translate-x-1/2 bg-rose-600 text-white text-[8px] font-black px-1.5 py-0.5 rounded-full uppercase tracking-tighter">
                Sale
              </div>
            </div>
            <span className="text-[10px] font-bold text-gray-700 max-w-[80px] truncate">{sale.name}</span>
          </button>
        ))}
      </div>

      <AnimatePresence>
        {selectedSale && (
          <motion.div
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            exit={{ opacity: 0, scale: 0.9 }}
            className="fixed inset-0 z-[100] bg-black flex items-center justify-center p-4"
          >
            <div className="relative w-full max-w-md aspect-[9/16] bg-gray-900 rounded-3xl overflow-hidden shadow-2xl flex flex-col">
              {/* Progress Bar (Visual only) */}
              <div className="absolute top-4 left-4 right-4 flex gap-1 z-20">
                <div className="flex-1 h-0.5 bg-white/30 rounded-full overflow-hidden">
                  <motion.div 
                    initial={{ width: 0 }} 
                    animate={{ width: '100%' }} 
                    transition={{ duration: 15, ease: 'linear' }}
                    className="h-full bg-white"
                  />
                </div>
              </div>

              {/* Header */}
              <div className="absolute top-8 left-4 right-4 flex items-center gap-3 z-20">
                <div className="w-10 h-10 rounded-full border-2 border-pink-500 p-0.5">
                  <img src={(selectedSale as any).seller?.avatar || 'https://via.placeholder.com/50'} className="w-full h-full rounded-full object-cover" />
                </div>
                <div className="flex-1">
                  <div className="flex items-center gap-1">
                    <span className="text-white text-sm font-bold">{(selectedSale as any).seller?.name || 'Seller'}</span>
                    <CheckCircle className="w-3 h-3 text-blue-400 fill-current" />
                  </div>
                  <span className="text-white/60 text-[10px] flex items-center gap-1">
                    <Clock className="w-2.5 h-2.5" /> {timeLeft}
                  </span>
                </div>
                <button onClick={() => setSelectedSale(null)} className="p-2 text-white/80 hover:text-white">
                  <X className="w-6 h-6" />
                </button>
              </div>

              {/* Main Content */}
              <div className="flex-1 relative">
                <img src={selectedSale.images[0]} className="w-full h-full object-cover" />
                <div className="absolute inset-0 bg-gradient-to-t from-black via-transparent to-transparent" />
                
                <div className="absolute bottom-28 left-6 right-6">
                  <div className="inline-flex items-center gap-2 bg-rose-600 text-white text-[10px] font-black px-2 py-1 rounded-lg uppercase tracking-widest mb-3">
                    <Zap className="w-3 h-3 fill-current" /> Flash Sale
                  </div>
                  <h2 className="text-white text-2xl font-black leading-tight mb-2">{selectedSale.name}</h2>
                  <div className="flex items-center gap-3">
                    <span className="text-rose-500 text-2xl font-black">KSH {selectedSale.flashSalePrice?.toLocaleString()}</span>
                    <span className="text-white/40 text-lg line-through">KSH {selectedSale.price.toLocaleString()}</span>
                  </div>
                </div>
              </div>

              {/* Actions */}
              <div className="p-6 bg-black flex gap-3">
                <button 
                  onClick={() => {
                    // Logic to add to cart and go to checkout
                    setSelectedSale(null);
                    window.location.href = `/profile?buyNow=${selectedSale.id}&checkout=true`;
                  }}
                  className="flex-1 bg-white text-gray-900 font-bold py-3.5 rounded-2xl flex items-center justify-center gap-2 hover:bg-gray-100 active:scale-95 transition-all text-sm uppercase tracking-wide"
                >
                  <ShoppingBag className="w-5 h-5" /> Buy Now
                </button>
                <button 
                  onClick={() => {
                    setSelectedSale(null);
                    window.location.href = `/chats?sellerId=${selectedSale.sellerId}&productId=${selectedSale.id}`;
                  }}
                  className="w-14 h-14 bg-gray-800 text-white rounded-2xl flex items-center justify-center hover:bg-gray-700 active:scale-95 transition-all"
                >
                  <MessageCircle className="w-6 h-6" />
                </button>
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}

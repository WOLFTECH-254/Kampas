import React, { useRef } from 'react';
import { Download, CheckCircle, Package, User, MapPin, CreditCard, Calendar, Printer, Share2, Info, ShoppingBag, Loader2 } from 'lucide-react';
import { motion } from 'motion/react';
import { toPng } from 'html-to-image';

interface ReceiptProps {
  order: any;
  onClose: () => void;
}

export default function Receipt({ order, onClose }: ReceiptProps) {
  const isCOD = order.paymentMethod === 'COD';
  const receiptRef = useRef<HTMLDivElement>(null);
  const [isDownloading, setIsDownloading] = React.useState(false);
  
  const handleDownload = async () => {
    if (!receiptRef.current) return;
    setIsDownloading(true);
    
    try {
      // Small delay to ensure any fonts/images are ready
      await new Promise(resolve => setTimeout(resolve, 500));
      
      const dataUrl = await toPng(receiptRef.current, {
        cacheBust: true,
        backgroundColor: '#ffffff',
        style: {
          borderRadius: '0px',
        }
      });
      
      const link = document.createElement('a');
      link.download = `Kampas-Receipt-${order.id}.png`;
      link.href = dataUrl;
      link.click();
    } catch (err) {
      console.error('Failed to download receipt:', err);
      // Fallback to print if image generation fails
      window.print();
    } finally {
      setIsDownloading(false);
    }
  };

  return (
    <div className="fixed inset-0 z-[200] bg-gray-900/90 backdrop-blur-xl flex items-center justify-center p-4 overflow-y-auto">
      <motion.div 
        initial={{ scale: 0.9, opacity: 0 }} 
        animate={{ scale: 1, opacity: 1 }}
        className="w-full max-w-xl bg-white rounded-[2.5rem] shadow-[0_30px_100px_rgba(0,0,0,0.3)] overflow-hidden flex flex-col"
      >
        {/* Success Header */}
        <div className={`p-8 text-white text-center relative overflow-hidden ${isCOD ? 'bg-orange-500' : 'bg-pink-500'}`}>
          <div className="absolute top-0 right-0 w-32 h-32 bg-white/10 rounded-full -mr-16 -mt-16 blur-2xl"></div>
          <div className="absolute bottom-0 left-0 w-24 h-24 bg-black/10 rounded-full -ml-12 -mb-12 blur-xl"></div>
          
          <motion.div 
            initial={{ scale: 0 }} 
            animate={{ scale: 1 }} 
            transition={{ delay: 0.2, type: 'spring' }}
            className={`w-20 h-20 bg-white rounded-full flex items-center justify-center mx-auto mb-4 shadow-xl ${isCOD ? 'text-orange-500' : 'text-pink-500'}`}
          >
            {isCOD ? <Package className="w-12 h-12" /> : <CheckCircle className="w-12 h-12" />}
          </motion.div>
          
          <h2 className="text-2xl font-black uppercase tracking-tight">
            {isCOD ? 'Order Requested' : 'Order Confirmed!'}
          </h2>
          <p className="text-white/80 text-xs font-bold uppercase tracking-widest mt-1 opacity-80">
            {isCOD ? 'Payment Pending: Pay on Delivery' : `Payment Successful via ${order.paymentMethod}`}
          </p>
        </div>

        {/* Receipt Content */}
        <div ref={receiptRef} id="receipt-content" className="p-8 bg-white flex-1 space-y-8 print:p-0">
          
          <div className="flex justify-between items-start border-b border-gray-100 pb-6">
            <div>
              <h1 className="text-lg font-black text-gray-900 tracking-tight">KAMPAS RADIUS</h1>
              <p className="text-[10px] text-pink-500 font-black uppercase tracking-[0.3em] mt-1">
                {isCOD ? 'RECEIPT ORDERS' : 'OFFICIAL RECEIPT'}
              </p>
            </div>
            <div className="text-right">
              <p className="text-[10px] text-gray-400 font-bold uppercase tracking-widest">Transaction ID</p>
              <p className="font-mono text-sm font-bold text-gray-900">{order.receiptId || 'REC-' + order.id.slice(-6)}</p>
            </div>
          </div>

          {isCOD && (
            <div className="bg-orange-50 border border-orange-100 p-4 rounded-2xl flex items-center gap-3">
              <Info className="w-5 h-5 text-orange-500 flex-shrink-0" />
              <p className="text-[10px] text-orange-800 font-bold leading-tight">
                PAY UPON MEETING SELLER: Please ensure you pay the amount shown below before the seller hands over the goods.
              </p>
            </div>
          )}

          <div className="grid grid-cols-2 gap-8">
            <div className="space-y-4">
               <div className="flex items-start gap-3">
                  <div className="w-8 h-8 rounded-lg bg-pink-50 flex items-center justify-center text-pink-500 flex-shrink-0">
                     <User className="w-4 h-4" />
                  </div>
                  <div>
                     <label className="text-[9px] font-black text-gray-400 uppercase tracking-widest block mb-0.5">Purchased By</label>
                     <p className="text-xs font-bold text-gray-900">{order.buyer?.name || 'KAMPAS User'}</p>
                     <p className="text-[9px] text-gray-500 font-medium">{order.buyer?.email || 'user@kampas.radius'}</p>
                  </div>
               </div>
              <div className="flex items-start gap-3">
                 <div className="w-8 h-8 rounded-lg bg-pink-50 flex items-center justify-center text-pink-500 flex-shrink-0">
                    <Calendar className="w-4 h-4" />
                 </div>
                 <div>
                    <label className="text-[9px] font-black text-gray-400 uppercase tracking-widest block mb-0.5">Date & Time</label>
                    <p className="text-xs font-bold text-gray-900">{new Date(order.createdAt).toLocaleString()}</p>
                 </div>
              </div>
              {order.seller && (
                <div className="flex items-start gap-3">
                  <div className="w-8 h-8 rounded-lg bg-pink-50 flex items-center justify-center text-pink-500 flex-shrink-0">
                      <ShoppingBag className="w-4 h-4" />
                  </div>
                  <div>
                      <label className="text-[9px] font-black text-gray-400 uppercase tracking-widest block mb-0.5">Seller Information</label>
                      <p className="text-xs font-bold text-gray-900">{order.seller.name}</p>
                      <p className="text-[9px] text-gray-500 font-medium">{order.seller.campus}</p>
                  </div>
                </div>
              )}
            </div>

            <div className="space-y-4">
              <div className="flex items-start gap-3">
                 <div className="w-8 h-8 rounded-lg bg-pink-50 flex items-center justify-center text-pink-500 flex-shrink-0">
                    <MapPin className="w-4 h-4" />
                 </div>
                 <div>
                    <label className="text-[9px] font-black text-gray-400 uppercase tracking-widest block mb-0.5">Shipping Address</label>
                    <p className="text-xs font-bold text-gray-900 leading-tight">{order.shippingAddress || 'Campus Pick-up'}</p>
                 </div>
              </div>
              <div className="flex items-start gap-3">
                 <div className="w-8 h-8 rounded-lg bg-pink-50 flex items-center justify-center text-pink-500 flex-shrink-0">
                    <CreditCard className="w-4 h-4" />
                 </div>
                 <div>
                    <label className="text-[9px] font-black text-gray-400 uppercase tracking-widest block mb-0.5">Payment Method</label>
                    <p className="text-xs font-bold text-gray-900">{order.paymentMethod === 'COD' ? 'Pay on Delivery' : 'M-Pesa / Wallet'}</p>
                 </div>
              </div>
            </div>
          </div>

          <div className="bg-gray-50 rounded-2xl p-6 border border-gray-100">
             <div className="flex items-center gap-2 mb-4 border-b border-gray-200 pb-3">
                <Package className="w-4 h-4 text-pink-500" />
                <label className="text-[10px] font-black text-gray-900 uppercase tracking-widest">Order Items</label>
             </div>
             <div className="space-y-3">
                {order.items.map((item: any, i: number) => (
                  <div key={i} className="flex justify-between items-center text-xs">
                    <span className="font-bold text-gray-700">{item.product?.name || item.product?.title || 'Unknown Item'} <span className="text-gray-400 ml-1">x{item.quantity}</span></span>
                    <span className="font-mono font-bold text-gray-900">KSH {(item.price * item.quantity).toLocaleString()}</span>
                  </div>
                ))}
             </div>
             <div className="mt-6 pt-4 border-t border-gray-200 space-y-2">
                <div className="flex justify-between text-[10px] font-bold text-gray-500 uppercase tracking-widest">
                   <span>Subtotal</span>
                   <span className="font-mono">KSH {order.subtotal?.toLocaleString() || (order.total - 100).toLocaleString()}</span>
                </div>
                <div className="flex justify-between text-[10px] font-bold text-gray-500 uppercase tracking-widest">
                   <span>Delivery Fee</span>
                   <span className="font-mono">KSH {order.deliveryFee?.toLocaleString() || '100'}</span>
                </div>
                <div className="flex justify-between text-lg font-black text-gray-900 mt-2">
                   <span>{isCOD ? 'Amount to Pay' : 'Total Paid'}</span>
                   <span className="text-pink-500">KSH {order.total.toLocaleString()}</span>
                </div>
             </div>
          </div>
          
          <div className="text-center">
            <img src={`https://api.qrserver.com/v1/create-qr-code/?size=100x100&data=${order.id}`} className="w-20 h-20 mx-auto bg-white p-2 rounded-xl border border-gray-100 grayscale mb-2" alt="QR Verification" />
            <p className="text-[8px] font-bold text-gray-400 uppercase tracking-[0.2em]">{isCOD ? 'Pending Payment QR' : 'Payment Verification QR'}</p>
          </div>
        </div>

        {/* Footer Actions */}
        <div className="p-8 bg-gray-900 flex gap-4 print:hidden">
           <button 
             onClick={handleDownload}
             disabled={isDownloading}
             className="flex-1 bg-white text-gray-900 py-4 rounded-2xl font-black text-[10px] uppercase tracking-widest flex items-center justify-center gap-2 hover:bg-pink-500 hover:text-white transition-all shadow-xl disabled:opacity-50"
           >
             {isDownloading ? (
               <Loader2 className="w-4 h-4 animate-spin" />
             ) : (
               <Download className="w-4 h-4" />
             )}
             {isDownloading ? 'Generating...' : `Download ${isCOD ? 'Order Receipt' : 'Receipt'}`}
           </button>
           <button 
             onClick={onClose}
             className="flex-1 bg-gray-800 text-white py-4 rounded-2xl font-black text-[10px] uppercase tracking-widest flex items-center justify-center gap-2 hover:bg-gray-700 transition-all"
           >
             Close
           </button>
        </div>
      </motion.div>
    </div>
  );
}

import React, { useEffect, useState, useRef } from 'react';
import { MapContainer, TileLayer, Marker, Popup, useMap } from 'react-leaflet';
import { APIProvider, Map, AdvancedMarker, Pin } from '@vis.gl/react-google-maps';
import L from 'leaflet';
import 'leaflet/dist/leaflet.css';
import { Navigation } from 'lucide-react';

// Fix for default marker icons in Vite/React
import icon from 'leaflet/dist/images/marker-icon.png';
import iconShadow from 'leaflet/dist/images/marker-shadow.png';

let DefaultIcon = L.icon({
    iconUrl: icon,
    shadowUrl: iconShadow,
    iconSize: [25, 41],
    iconAnchor: [12, 41]
});

L.Marker.prototype.options.icon = DefaultIcon;

export type MapViewType = 'STREET' | 'SATELLITE' | 'TERRAIN' | 'HYBRID';

interface MapMarker {
  id: string;
  lat: number;
  lng: number;
  title: string;
  type: 'USER' | 'PRODUCT' | 'EVENT' | 'PROPERTY' | 'SELLER';
  data?: any;
}

interface MapViewProps {
  markers?: MapMarker[];
  center?: [number, number];
  zoom?: number;
  height?: string;
  provider?: 'OSM' | 'GOOGLE';
  viewType?: MapViewType;
  tilt?: number;
  onMarkerClick?: (marker: MapMarker) => void;
}

const TYPE_COLORS: Record<string, string> = {
  USER: '#EC4899', // pink-500
  PRODUCT: '#3B82F6', // blue-500
  EVENT: '#F59E0B', // amber-500
  PROPERTY: '#10B981', // emerald-500
  SELLER: '#8B5CF6', // violet-500
};

// Helper to update map center for Leaflet
const ChangeView = ({ center, zoom }: { center: [number, number]; zoom: number }) => {
  const map = useMap();
  useEffect(() => {
    map.setView(center, zoom);
  }, [center, zoom, map]);
  return null;
};

const API_KEY = import.meta.env.VITE_GOOGLE_MAPS_API_KEY || '';

const MapView: React.FC<MapViewProps> = ({ 
  markers = [], 
  center = [-1.286389, 36.817223], 
  zoom = 13, 
  height = '400px',
  provider = 'OSM',
  viewType = 'STREET',
  tilt = 0,
  onMarkerClick
}) => {
  const [userLocation, setUserLocation] = useState<[number, number] | null>(null);

  useEffect(() => {
    if (navigator.geolocation) {
      navigator.geolocation.getCurrentPosition(
        (pos) => setUserLocation([pos.coords.latitude, pos.coords.longitude]),
        () => console.warn('Location access denied')
      );
    }
  }, []);

  const createCustomIcon = (type: string) => {
    return L.divIcon({
      className: 'custom-marker',
      html: `
        <div class="relative group animate-in zoom-in duration-300">
          <div style="background-color: ${TYPE_COLORS[type] || '#EC4899'}; width: 16px; height: 16px; border: 3px solid white; border-radius: 50%; box-shadow: 0 4px 10px rgba(0,0,0,0.3);"></div>
          <div class="absolute -inset-1 bg-pink-500/20 rounded-full animate-ping pointer-events-none ${type !== 'USER' ? 'hidden' : ''}"></div>
        </div>
      `,
      iconSize: [16, 16],
      iconAnchor: [8, 8]
    });
  };

  const getTileUrl = () => {
    if (viewType === 'SATELLITE') {
      return 'https://server.arcgisonline.com/ArcGIS/rest/services/World_Imagery/MapServer/tile/{z}/{y}/{x}';
    }
    if (viewType === 'TERRAIN') {
      return 'https://{s}.tile.opentopomap.org/{z}/{x}/{y}.png';
    }
    return 'https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png';
  };

  // Google Maps Implementation
  if (provider === 'GOOGLE' && API_KEY) {
    return (
      <div style={{ height, width: '100%', borderRadius: '24px', overflow: 'hidden', border: '1px solid #FBCFE8', position: 'relative' }}>
        <APIProvider apiKey={API_KEY} version="weekly">
          <Map
            defaultCenter={{lat: center[0], lng: center[1]}}
            defaultZoom={zoom}
            mapId="7e6e58b9f71c4c8e"
            tilt={tilt}
            mapTypeId={viewType.toLowerCase()}
            internalUsageAttributionIds={['gmp_mcp_codeassist_v1_aistudio']}
            style={{ width: '100%', height: '100%' }}
            gestureHandling={'greedy'}
            disableDefaultUI={false}
          >
            {markers.map((m) => (
              <AdvancedMarker 
                key={m.id} 
                position={{lat: m.lat, lng: m.lng}}
                onClick={() => onMarkerClick?.(m)}
              >
                <Pin 
                  background={TYPE_COLORS[m.type]} 
                  borderColor={'#fff'} 
                  glyphColor={'#fff'}
                  scale={m.type === 'USER' ? 1.2 : 0.8}
                />
              </AdvancedMarker>
            ))}
          </Map>
        </APIProvider>
      </div>
    );
  }

  // Fallback/OSM Leaflet Implementation
  return (
    <div style={{ height, width: '100%', borderRadius: '24px', overflow: 'hidden', border: '1px solid #FBCFE8', position: 'relative' }} className="shadow-2xl">
      <MapContainer 
        center={center} 
        zoom={zoom} 
        style={{ height: '100%', width: '100%' }}
        scrollWheelZoom={true}
        className="z-0 overflow-visible"
      >
        <TileLayer
          attribution='&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'
          url={getTileUrl()}
        />
        
        <ChangeView center={center as [number, number]} zoom={zoom} />

        {markers.map((m) => (
          <Marker 
            key={`${m.type}-${m.id}`} 
            position={[m.lat, m.lng]}
            icon={createCustomIcon(m.type)}
            eventHandlers={{
              click: () => onMarkerClick?.(m)
            }}
          >
            <Popup className="kampas-popup">
              <div className="p-1 min-w-[140px]">
                <p className="font-black text-xs text-gray-900 leading-tight uppercase tracking-tight">{m.title}</p>
                <div className="flex items-center gap-2 mt-2">
                  <div className="w-2 h-2 rounded-full ring-2 ring-white shadow-sm" style={{ backgroundColor: TYPE_COLORS[m.type] }}></div>
                  <p className="text-gray-400 font-black uppercase text-[8px] tracking-[0.2em]">{m.type}</p>
                </div>
              </div>
            </Popup>
          </Marker>
        ))}
      </MapContainer>

      {/* Tilt UI Overlay (Leaflet fake tilt) */}
      <style>{`
        .leaflet-container { 
          transform: perspective(1000px) rotateX(${tilt}deg);
          transition: transform 0.5s cubic-bezier(0.4, 0, 0.2, 1);
        }
        .leaflet-marker-icon, .leaflet-popup {
          transform: rotateX(${-tilt}deg) !important;
        }
      `}</style>

      {/* Map Controls */}
      <div className="absolute bottom-6 right-6 z-[400] flex flex-col gap-3">
         <button 
          onClick={() => {
            if (userLocation) {
                 window.location.reload(); // Simple way to force recenter in this state
            }
          }}
          className="w-12 h-12 bg-white rounded-2xl shadow-xl flex items-center justify-center text-gray-900 hover:text-pink-500 transition-all active:scale-95 border border-pink-50"
         >
           <Navigation className="w-5 h-5 transition-transform group-hover:rotate-12" />
         </button>
      </div>
    </div>
  );
};

export default MapView;

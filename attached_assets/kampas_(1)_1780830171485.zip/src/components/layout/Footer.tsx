import { Mail, MessageSquare, Shield, FileText, ExternalLink, Heart } from 'lucide-react';
import { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { X } from 'lucide-react';

const PolicyModal = ({ isOpen, onClose, title, content }: { isOpen: boolean, onClose: () => void, title: string, content: string }) => (
  <AnimatePresence>
    {isOpen && (
      <div className="fixed inset-0 z-[100] flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm">
        <motion.div 
          initial={{ opacity: 0, scale: 0.95, y: 20 }}
          animate={{ opacity: 1, scale: 1, y: 0 }}
          exit={{ opacity: 0, scale: 0.95, y: 20 }}
          className="bg-white rounded-[2rem] w-full max-w-2xl max-h-[80vh] overflow-hidden shadow-2xl border border-pink-100"
        >
          <div className="p-6 border-b border-pink-50 flex items-center justify-between sticky top-0 bg-white z-10">
            <h3 className="text-xl font-black text-gray-900 uppercase tracking-tight italic">{title}</h3>
            <button onClick={onClose} className="p-2 hover:bg-pink-50 rounded-full transition-colors">
              <X className="w-5 h-5 text-gray-400" />
            </button>
          </div>
          <div className="p-8 overflow-y-auto text-sm text-gray-600 leading-relaxed max-h-[calc(80vh-80px)]">
            <div className="whitespace-pre-wrap font-medium font-sans">
              {content}
            </div>
          </div>
        </motion.div>
      </div>
    )}
  </AnimatePresence>
);

export default function Footer() {
  const [modal, setModal] = useState<{ title: string, content: string } | null>(null);

  const buyerTerms = `
1. ACCEPTANCE
By using Kampas as a buyer, you agree to these terms.
2. BUYER RESPONSIBILITIES
- Be accurate with your details.
- Respect all students and sellers on the platform.
3. PAYMENTS & ESCROW
- Payments are held in escrow until delivery is confirmed.
- Confirm delivery only after physically receiving and verifying the item.
4. DISPUTES
- Report any issues within 24 hours of scheduled delivery.
`;

  const sellerTerms = `
1. LISTING POLICIES
- No illegal items.
- Only campus-appropriate content.
2. FEES
- Transaction fees apply as per the current fee schedule.
3. DELIVERY
- Sellers are responsible for meeting buyers in safe campus zones.
4. VERIFICATION
- Sellers must be verified students to sell services.
`;

  const privacyPolicy = `
1. DATA COLLECTION
We collect your name, campus details, and transaction history to improve your experience.
2. DATA SECURITY
Your financial data is encrypted and handled by secure payment gateways.
3. SHARING
We do not sell your personal data to third parties.
`;

  return (
    <footer className="bg-white pt-16 pb-24 md:pb-12 border-t border-pink-100">
      <div className="container mx-auto px-6">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-12 mb-12">
          {/* Section 1: Brand */}
          <div className="space-y-4">
            <div className="flex items-center gap-2">
              <div className="w-10 h-10 rounded-xl bg-pink-500 flex items-center justify-center font-bold text-white text-xl shadow-lg shadow-pink-200 uppercase italic">K</div>
              <span className="font-black text-2xl tracking-tighter uppercase italic">Kampas</span>
            </div>
            <p className="text-sm text-gray-500 font-medium leading-relaxed">
              The ultimate campus marketplace. Built for students, by students.
            </p>
            <div className="pt-2">
              <p className="text-[10px] font-black text-gray-400 uppercase tracking-[0.2em] mb-1">Developed By</p>
              <p className="text-xs font-bold text-gray-900">BB Software Labs</p>
              <p className="text-[10px] font-medium text-pink-500 uppercase tracking-widest mt-0.5">In Partnership with WolfTech</p>
            </div>
          </div>

          {/* Section 2: Support */}
          <div className="space-y-4">
             <h4 className="text-[10px] font-black text-gray-400 uppercase tracking-[0.2em] mb-6">Contact Us</h4>
             <a href="mailto:support@kampas.co.ke" className="flex items-center gap-3 text-gray-600 hover:text-pink-600 transition-colors group">
               <div className="w-10 h-10 rounded-full bg-pink-50 flex items-center justify-center group-hover:bg-pink-100 transition-colors">
                 <Mail className="w-4 h-4" />
               </div>
               <div>
                  <p className="text-[10px] font-black text-gray-400 uppercase tracking-widest leading-none mb-1">Email Support</p>
                  <p className="text-sm font-bold">support@kampas.co.ke</p>
               </div>
             </a>
             <div className="flex items-center gap-3 text-gray-400">
               <div className="w-10 h-10 rounded-full bg-gray-50 flex items-center justify-center">
                 <MessageSquare className="w-4 h-4" />
               </div>
               <div>
                  <p className="text-[10px] font-black text-gray-400 uppercase tracking-widest leading-none mb-1">Live Chat</p>
                  <p className="text-sm font-bold opacity-60 italic">Coming Soon</p>
               </div>
             </div>
          </div>

          {/* Section 3: Legal */}
          <div className="space-y-4 lg:col-span-2">
            <h4 className="text-[10px] font-black text-gray-400 uppercase tracking-[0.2em] mb-6 whitespace-nowrap">Platform Policy & Legal</h4>
            <div className="flex flex-wrap gap-4">
               <button onClick={() => setModal({ title: 'Buyer Terms of Use', content: buyerTerms })}
                 className="flex-1 min-w-[150px] bg-pink-50 hover:bg-pink-100 border border-pink-100 p-4 rounded-2xl transition-all text-left">
                  <Shield className="w-5 h-5 text-pink-500 mb-2" />
                  <p className="text-xs font-black text-gray-900 uppercase tracking-tight">Buyer Terms</p>
                  <p className="text-[10px] text-gray-400 font-bold uppercase tracking-widest mt-1">Safety & Escrow</p>
               </button>
               <button onClick={() => setModal({ title: 'Seller Terms of Use', content: sellerTerms })}
                 className="flex-1 min-w-[150px] bg-blue-50 hover:bg-blue-100 border border-blue-100 p-4 rounded-2xl transition-all text-left">
                  <FileText className="w-5 h-5 text-blue-500 mb-2" />
                  <p className="text-xs font-black text-gray-900 uppercase tracking-tight">Seller Terms</p>
                  <p className="text-[10px] text-gray-400 font-bold uppercase tracking-widest mt-1">Listing Rules</p>
               </button>
               <button onClick={() => setModal({ title: 'Privacy Policy', content: privacyPolicy })}
                 className="flex-1 min-w-[150px] bg-green-50 hover:bg-green-100 border border-green-100 p-4 rounded-2xl transition-all text-left">
                  <Shield className="w-5 h-5 text-green-500 mb-2" />
                  <p className="text-xs font-black text-gray-900 uppercase tracking-tight">Privacy Policy</p>
                  <p className="text-[10px] text-gray-400 font-bold uppercase tracking-widest mt-1">Data protection</p>
               </button>
            </div>
          </div>
        </div>

        {/* Footer Bottom */}
        <div className="pt-8 border-t border-pink-50 flex flex-col md:flex-row justify-between items-center gap-6">
          <p className="text-[10px] font-black text-gray-400 uppercase tracking-[0.2em]">
            &copy; {new Date().getFullYear()} KAMPAS. ALL RIGHTS RESERVED.
          </p>
          <div className="flex items-center gap-2 text-[10px] font-black text-gray-400 uppercase tracking-widest">
            Made with <Heart className="w-3 h-3 text-pink-500 fill-pink-500" /> for Kenyan Students
          </div>
        </div>
      </div>

      <PolicyModal 
        isOpen={!!modal} 
        onClose={() => setModal(null)} 
        title={modal?.title || ''} 
        content={modal?.content || ''} 
      />
    </footer>
  );
}

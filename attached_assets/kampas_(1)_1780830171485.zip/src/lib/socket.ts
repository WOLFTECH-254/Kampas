import { io, Socket } from 'socket.io-client';

// Use current origin, socket.io automatically uses window.location
export const socket: Socket = io();

import { GET } from './api';

export interface Recommendation {
  id: string;
  type: 'PRODUCT' | 'EVENT' | 'PROPERTY' | 'SERVICE';
  title: string;
  description: string;
  price?: number;
  image: string;
  lat?: number;
  lng?: number;
  campus?: string;
  distance?: number;
  relevance?: number;
}

export async function getAiRecommendations(context: {
  location?: { lat: number; lng: number } | null;
  campus?: string;
  userId?: string;
  category?: 'MARKETPLACE' | 'HOUSING' | 'EVENTS' | 'SERVICES' | 'ALL';
}) {
  try {
    // In a real app, this would be a single AI endpoint
    // For now, we fetch relevant data and rank them using our "AI" (local logic)
    const [productsRes, eventsRes, propertiesRes] = await Promise.all([
      GET('/api/products'),
      GET('/api/events'),
      GET('/api/properties')
    ]);

    let pool: Recommendation[] = [
      ...productsRes.data.products.map((p: any) => ({
        id: p.id,
        type: 'PRODUCT',
        title: p.name,
        description: p.description,
        price: p.price,
        image: p.images?.[0] || p.image,
        lat: p.lat,
        lng: p.lng,
        campus: p.campus,
        relevance: Math.random() * 100 // Simulated AI weight
      })),
      ...eventsRes.data.events.map((e: any) => ({
        id: e.id,
        type: 'EVENT',
        title: e.title,
        description: e.description,
        price: e.price,
        image: e.image,
        lat: e.lat,
        lng: e.lng,
        campus: e.campus,
        relevance: Math.random() * 100
      })),
      ...propertiesRes.data.properties.map((h: any) => ({
        id: h.id,
        type: 'PROPERTY',
        title: h.title,
        description: h.description,
        price: h.price,
        image: h.images?.[0] || h.image,
        lat: h.lat,
        lng: h.lng,
        campus: h.campus,
        relevance: Math.random() * 100
      }))
    ];

    // Filter by category if requested
    if (context.category && context.category !== 'ALL') {
      const typeMap: Record<string, string> = {
        'MARKETPLACE': 'PRODUCT',
        'HOUSING': 'PROPERTY',
        'EVENTS': 'EVENT',
        'SERVICES': 'SERVICE'
      };
      pool = pool.filter(item => item.type === typeMap[context.category!]);
    }

    // Rank by distance if location provided
    if (context.location) {
      pool = pool.map(item => {
        if (item.lat && item.lng) {
          const dist = calculateDistance(
            context.location!.lat,
            context.location!.lng,
            item.lat,
            item.lng
          );
          return { ...item, distance: dist };
        }
        return item;
      });

      // AI Logic: Weight distance (40%) and relevance (60%)
      pool.sort((a, b) => {
        const scoreA = (a.relevance || 0) * 0.6 + (a.distance ? (1 / (a.distance + 1)) * 1000 : 0) * 0.4;
        const scoreB = (b.relevance || 0) * 0.6 + (b.distance ? (1 / (b.distance + 1)) * 1000 : 0) * 0.4;
        return scoreB - scoreA;
      });
    } else {
      // Sort by relevance only
      pool.sort((a, b) => (b.relevance || 0) - (a.relevance || 0));
    }

    return pool.slice(0, 10);
  } catch (err) {
    console.error('AI Recommendation Error:', err);
    return [];
  }
}

function calculateDistance(lat1: number, lon1: number, lat2: number, lon2: number) {
  const R = 6371e3; // meters
  const φ1 = lat1 * Math.PI / 180;
  const φ2 = lat2 * Math.PI / 180;
  const Δφ = (lat2 - lat1) * Math.PI / 180;
  const Δλ = (lon2 - lon1) * Math.PI / 180;

  const a = Math.sin(Δφ / 2) * Math.sin(Δφ / 2) +
          Math.cos(φ1) * Math.cos(φ2) *
          Math.sin(Δλ / 2) * Math.sin(Δλ / 2);
  const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));

  return R * c;
}

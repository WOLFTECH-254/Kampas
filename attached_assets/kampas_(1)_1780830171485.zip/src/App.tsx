import { BrowserRouter, Routes, Route, Navigate } from 'react-router-dom';
import { AuthProvider, useAuth } from './context/AuthContext';
import { LocationProvider } from './context/LocationContext';
import ProtectedRoute from './components/ProtectedRoute';
import RoleRoute from './components/RoleRoute';
import MainLayout from './components/layout/MainLayout';
import LandingPage from './pages/LandingPage';
import Marketplace from './pages/Marketplace';
import SellerDashboard from './pages/SellerDashboard';
import BuyerDashboard from './pages/BuyerDashboard';
import AdminDashboard from './pages/AdminDashboard';
import Events from './pages/Events';
import Housing from './pages/Housing';
import CampusMap from './pages/CampusMap';
import Chats from './pages/Chats';
import Login from './pages/Auth/Login';
import SignUp from './pages/Auth/SignUp';

function HomeRedirect() {
  const { user, loading } = useAuth();
  if (loading) return null;
  if (!user) return <Navigate to="/login" replace />;
  if (user.role === 'ADMIN')  return <Navigate to="/admin" replace />;
  if (user.role === 'SELLER') return <Navigate to="/profile?tab=dashboard" replace />;
  return <Navigate to="/explore" replace />;
}

function ProfileRedirect() {
  const { user, loading } = useAuth();
  if (loading) return null;
  if (!user) return <Navigate to="/login" replace />;
  if (user.role === 'ADMIN') return <Navigate to="/admin" replace />;
  if (user.role === 'SELLER') return <SellerDashboard />;
  return <BuyerDashboard />;
}

export default function App() {
  return (
    <AuthProvider>
      <LocationProvider>
        <BrowserRouter>
          <Routes>
          <Route path="/"       element={<LandingPage />} />
          <Route path="/login"  element={<Login />} />
          <Route path="/signup" element={<SignUp />} />
          <Route path="/home"   element={<HomeRedirect />} />

          <Route element={<ProtectedRoute><MainLayout /></ProtectedRoute>}>
            <Route path="/explore"  element={<Marketplace />} />
            <Route path="/housing"  element={<Housing />} />
            <Route path="/map"      element={<CampusMap />} />
            <Route path="/events"   element={<Events />} />
            <Route path="/chats"    element={<Chats />} />
            <Route path="/profile"  element={<ProfileRedirect />} />
            <Route path="/dashboard/buyer" element={<Navigate to="/profile" replace />} />
            <Route path="/dashboard/seller" element={<Navigate to="/profile" replace />} />
          </Route>

          <Route path="/admin/*" element={
            <ProtectedRoute>
              <RoleRoute allowedRoles={['ADMIN']} redirectTo="/explore">
                <AdminDashboard />
              </RoleRoute>
            </ProtectedRoute>
          } />

          <Route path="*" element={<Navigate to="/explore" replace />} />
        </Routes>
      </BrowserRouter>
      </LocationProvider>
    </AuthProvider>
  );
}

